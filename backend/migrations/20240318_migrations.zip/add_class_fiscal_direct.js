/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
  return knex.schema.raw('ALTER TABLE orcamentos_itens ADD COLUMN IF NOT EXISTS class_fiscal VARCHAR(20)');
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
  return knex.schema.raw('ALTER TABLE orcamentos_itens DROP COLUMN IF EXISTS class_fiscal');
}; 