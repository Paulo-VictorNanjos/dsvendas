const knex = require('./database/connection');
const productFiscalRulesService = require('./services/productFiscalRulesService');

async function testProduto() {
  try {
    // Buscar um produto qualquer
    const produto = await knex('produtos')
      .select('*')
      .limit(1)
      .first();
    
    if (!produto) {
      console.log('Nenhum produto encontrado no banco de dados');
      return;
    }
    
    console.log('Produto encontrado:', produto.codigo, produto.descricao);
    
    // Testar cálculo fiscal para São Paulo
    const impostosSP = await productFiscalRulesService.calculateIcms(
      produto,
      1, // Quantidade
      100, // Valor unitário
      { uf: 'SP' }
    );
    
    console.log('Impostos para SP:', impostosSP);
    
    // Testar cálculo fiscal para outro estado (MG)
    const impostosMG = await productFiscalRulesService.calculateIcms(
      produto,
      1, // Quantidade
      100, // Valor unitário
      { uf: 'MG' }
    );
    
    console.log('Impostos para MG:', impostosMG);
    
    return {
      produto,
      impostosSP,
      impostosMG
    };
  } catch (error) {
    console.error('Erro ao testar cálculo fiscal:', error);
  }
}

testProduto()
  .then(result => {
    if (result) {
      console.log('Teste concluído com sucesso');
    } else {
      console.log('Falha no teste');
    }
  })
  .catch(err => console.error('Erro:', err))
  .finally(() => process.exit(0)); 