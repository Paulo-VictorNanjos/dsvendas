const syncService = require('./services/syncService');

async function testSyncRegrasIcms() {
  try {
    console.log('Iniciando sincronização de regras ICMS...');
    const result = await syncService.syncRegrasIcms();
    console.log('Sincronização concluída:', result);
  } catch (err) {
    console.error('Erro na sincronização:', err);
  }
}

testSyncRegrasIcms(); 