// Script para garantir que a tabela pedidos tenha todas as colunas necessárias
const knex = require('knex');
const config = require('../knexfile').development;

const db = knex(config);

async function ensurePedidosColumns() {
  try {
    console.log('Verificando estrutura da tabela pedidos...');
    
    // Lista de colunas esperadas e seus tipos
    const expectedColumns = [
      { name: 'codigo', type: 'string', isPrimary: true },
      { name: 'orcamento_origem', type: 'string' },
      { name: 'cod_empresa', type: 'string' },
      { name: 'cod_cliente', type: 'string' },
      { name: 'cod_vendedor', type: 'string' },
      { name: 'dt_pedido', type: 'date' },
      { name: 'vl_total', type: 'decimal' },
      { name: 'vl_produtos', type: 'decimal' },
      { name: 'vl_desconto', type: 'decimal' },
      { name: 'vl_st', type: 'decimal' },
      { name: 'vl_ipi', type: 'decimal' },
      { name: 'status', type: 'string' },
      { name: 'observacoes', type: 'text' },
      { name: 'form_pagto', type: 'string' },
      { name: 'cond_pagto', type: 'string' },
      { name: 'dt_inc', type: 'date' },
      { name: 'created_at', type: 'timestamp' },
      { name: 'updated_at', type: 'timestamp' }
    ];
    
    // Verificar se a tabela existe
    const tableExists = await db.schema.hasTable('pedidos');
    
    if (!tableExists) {
      console.log('A tabela pedidos não existe. Criando tabela...');
      await db.schema.createTable('pedidos', function(table) {
        table.string('codigo').primary();
        table.string('orcamento_origem');
        table.string('cod_empresa');
        table.string('cod_cliente');
        table.string('cod_vendedor');
        table.date('dt_pedido');
        table.decimal('vl_total', 10, 2);
        table.decimal('vl_produtos', 10, 2);
        table.decimal('vl_desconto', 10, 2);
        table.decimal('vl_st', 10, 2);
        table.decimal('vl_ipi', 10, 2);
        table.string('status').defaultTo('NOVO');
        table.text('observacoes');
        table.string('form_pagto');
        table.string('cond_pagto');
        table.date('dt_inc');
        table.timestamps(true, true);
        
        // Chaves estrangeiras
        table.foreign('orcamento_origem').references('codigo').inTable('orcamentos');
        table.foreign('cod_cliente').references('codigo').inTable('clientes');
        table.foreign('cod_vendedor').references('codigo').inTable('vendedores');
      });
      console.log('Tabela pedidos criada com sucesso!');
    } else {
      // Verificar cada coluna esperada
      for (const column of expectedColumns) {
        const columnExists = await db.schema.hasColumn('pedidos', column.name);
        
        if (!columnExists) {
          console.log(`Adicionando coluna ${column.name} à tabela pedidos...`);
          
          await db.schema.table('pedidos', function(table) {
            switch (column.type) {
              case 'string':
                table.string(column.name).nullable();
                break;
              case 'text':
                table.text(column.name).nullable();
                break;
              case 'decimal':
                table.decimal(column.name, 10, 2).nullable();
                break;
              case 'date':
                table.date(column.name).nullable();
                break;
              case 'timestamp':
                table.timestamp(column.name).nullable();
                break;
              default:
                table.string(column.name).nullable();
            }
          });
          
          console.log(`Coluna ${column.name} adicionada com sucesso!`);
        } else {
          console.log(`A coluna ${column.name} já existe.`);
        }
      }
    }
    
    console.log('Verificação de estrutura da tabela pedidos concluída!');
    
  } catch (error) {
    console.error('Erro ao verificar estrutura da tabela pedidos:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
ensurePedidosColumns(); 