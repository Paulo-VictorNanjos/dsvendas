const knex = require('./database/connection');

async function adicionarColunas() {
  try {
    console.log('Verificando se as colunas já existem...');
    const colunas = await knex('clientes').columnInfo();
    const colunasExistentes = Object.keys(colunas);
    
    let alteracoes = false;
    
    // Verificar e adicionar coluna insc_est se não existir
    if (!colunasExistentes.includes('insc_est')) {
      console.log('Adicionando coluna insc_est...');
      await knex.schema.table('clientes', table => {
        table.string('insc_est', 30).nullable();
      });
      console.log('Coluna insc_est adicionada com sucesso!');
      alteracoes = true;
    } else {
      console.log('Coluna insc_est já existe.');
    }
    
    // Verificar e adicionar coluna contribuinte se não existir
    if (!colunasExistentes.includes('contribuinte')) {
      console.log('Adicionando coluna contribuinte...');
      await knex.schema.table('clientes', table => {
        table.integer('contribuinte').nullable().defaultTo(0);
      });
      console.log('Coluna contribuinte adicionada com sucesso!');
      alteracoes = true;
    } else {
      console.log('Coluna contribuinte já existe.');
    }
    
    if (alteracoes) {
      console.log('Alterações concluídas na tabela clientes.');
    } else {
      console.log('Nenhuma alteração necessária na tabela clientes.');
    }
    
    process.exit(0);
  } catch (err) {
    console.error('Erro ao modificar tabela:', err.message);
    process.exit(1);
  }
}

adicionarColunas(); 