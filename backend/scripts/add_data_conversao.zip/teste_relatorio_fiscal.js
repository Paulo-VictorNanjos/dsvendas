/**
 * Script para testar o relatório fiscal de um orçamento
 */
const db = require('./database/connection');

// ID do orçamento a ser testado
const orcamentoCodigo = '917901db-8dc6-4502-8bbe-02f564186559';

// Simular o endpoint de relatório fiscal
async function testarRelatorioFiscal() {
  try {
    console.log('Iniciando teste do relatório fiscal...');
    
    // Buscar orçamento com todas as informações necessárias
    const orcamento = await db('orcamentos')
      .where('orcamentos.codigo', orcamentoCodigo)
      .select(
        'orcamentos.*',
        'clientes.razao as cliente_nome',
        'clientes.uf as cliente_uf',
        'clientes.cod_ibge as cliente_cod_ibge',
        'clientes.municipio as cliente_municipio'
      )
      .leftJoin('clientes', 'clientes.codigo', 'orcamentos.cod_cliente')
      .first();
      
    if (!orcamento) {
      console.error('Orçamento não encontrado');
      return;
    }
    
    // Buscar itens com informações fiscais
    const itens = await db('orcamentos_itens')
      .where('orcamento_codigo', orcamentoCodigo)
      .select(
        'orcamentos_itens.*',
        'produtos.descricao as produto_descricao'
      )
      .leftJoin('produtos', 'produtos.codigo', 'orcamentos_itens.produto_codigo');
      
    // Calcular totais fiscais
    const totaisFiscais = {
      base_icms: 0,
      valor_icms: 0,
      base_icms_st: 0,
      valor_icms_st: 0,
      valor_ipi: 0,
      valor_fcp_st: 0,
      total_impostos: 0
    };
    
    // Processar cada item para totalizar valores
    itens.forEach(item => {
      totaisFiscais.base_icms += parseFloat(item.base_icms || 0);
      totaisFiscais.valor_icms += parseFloat(item.valor_icms || 0);
      totaisFiscais.base_icms_st += parseFloat(item.base_icms_st || 0);
      totaisFiscais.valor_icms_st += parseFloat(item.valor_icms_st || 0);
      totaisFiscais.valor_ipi += parseFloat(item.valor_ipi || 0);
      totaisFiscais.valor_fcp_st += parseFloat(item.valor_fcp_st || 0);
      
      // Total de impostos deste item
      const impostoItem = parseFloat(item.valor_icms || 0) + 
                        parseFloat(item.valor_icms_st || 0) + 
                        parseFloat(item.valor_ipi || 0) + 
                        parseFloat(item.valor_fcp_st || 0);
                        
      totaisFiscais.total_impostos += impostoItem;
    });
    
    // Criar objeto de resposta do relatório fiscal
    const relatorioFiscal = {
      success: true,
      data: {
        orcamento: {
          codigo: orcamento.codigo,
          data: orcamento.dt_orcamento,
          cliente: {
            codigo: orcamento.cod_cliente,
            nome: orcamento.cliente_nome,
            uf: orcamento.cliente_uf,
            cod_ibge: orcamento.cliente_cod_ibge,
            municipio: orcamento.cliente_municipio
          },
          valor_total: parseFloat(orcamento.vl_total),
          valor_produtos: parseFloat(orcamento.vl_produtos),
          valor_impostos: parseFloat(orcamento.vl_impostos)
        },
        itens: itens.map(item => ({
          codigo: item.codigo,
          produto: {
            codigo: item.produto_codigo,
            descricao: item.produto_descricao
          },
          quantidade: parseFloat(item.quantidade),
          valor_unitario: parseFloat(item.valor_unitario),
          valor_total: parseFloat(item.valor_total),
          fiscal: {
            ncm: item.ncm,
            cest: item.cest,
            origem: item.cod_origem_prod,
            situacao_tributaria: item.situacao_tributaria,
            base_icms: parseFloat(item.base_icms || 0),
            aliquota_icms: parseFloat(item.aliq_icms || 0),
            valor_icms: parseFloat(item.valor_icms || 0),
            base_icms_st: parseFloat(item.base_icms_st || 0),
            valor_icms_st: parseFloat(item.valor_icms_st || 0),
            aliquota_ipi: parseFloat(item.aliq_ipi || 0),
            valor_ipi: parseFloat(item.valor_ipi || 0),
            valor_fcp_st: parseFloat(item.valor_fcp_st || 0),
            total_impostos: parseFloat(item.valor_icms || 0) + 
                         parseFloat(item.valor_icms_st || 0) + 
                         parseFloat(item.valor_ipi || 0) + 
                         parseFloat(item.valor_fcp_st || 0)
          }
        })),
        totais_fiscais: totaisFiscais
      }
    };
    
    console.log('Relatório fiscal:', JSON.stringify(relatorioFiscal, null, 2));
    console.log('Teste concluído com sucesso.');
    
  } catch (error) {
    console.error('Erro ao gerar relatório fiscal:', error);
  } finally {
    // Fechar conexão
    await db.destroy();
  }
}

// Executar o teste
testarRelatorioFiscal(); 