-- Remover tabelas se existirem (opcional, descomente se precisar recriar)
-- DROP TABLE IF EXISTS pedidos_itens;
-- DROP TABLE IF EXISTS pedidos;

-- Criar tabela de pedidos
CREATE TABLE IF NOT EXISTS pedidos (
    codigo VARCHAR(255) PRIMARY KEY,
    dt_pedido TIMESTAMP NOT NULL,
    cod_cliente INTEGER NOT NULL,
    cod_vendedor INTEGER NOT NULL,
    observacoes TEXT,
    vl_total DECIMAL(15,2) NOT NULL,
    orcamento_origem VARCHAR(255) NOT NULL,
    cod_status INTEGER DEFAULT 1,
    dt_inc TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sync_pendente BOOLEAN DEFAULT FALSE,
    vl_produtos DECIMAL(15,2),
    vl_servicos DECIMAL(15,2),
    vl_frete DECIMAL(15,2),
    vl_desconto DECIMAL(15,2),
    cod_empresa INTEGER DEFAULT 1
);

-- Criar índices para pedidos se não existirem
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos' AND indexname = 'idx_pedidos_orcamento') THEN
        CREATE INDEX idx_pedidos_orcamento ON pedidos(orcamento_origem);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos' AND indexname = 'idx_pedidos_cliente') THEN
        CREATE INDEX idx_pedidos_cliente ON pedidos(cod_cliente);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos' AND indexname = 'idx_pedidos_vendedor') THEN
        CREATE INDEX idx_pedidos_vendedor ON pedidos(cod_vendedor);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos' AND indexname = 'idx_pedidos_status') THEN
        CREATE INDEX idx_pedidos_status ON pedidos(cod_status);
    END IF;
END
$$;

-- Criar tabela de itens de pedido
CREATE TABLE IF NOT EXISTS pedidos_itens (
    id SERIAL PRIMARY KEY,
    pedido_codigo VARCHAR(255) NOT NULL,
    produto_codigo VARCHAR(255) NOT NULL,
    quantidade DECIMAL(15,3) NOT NULL,
    valor_unitario DECIMAL(15,4) NOT NULL,
    valor_total DECIMAL(15,2) NOT NULL,
    cod_empresa INTEGER DEFAULT 1
);

-- Criar índices para pedidos_itens se não existirem
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos_itens' AND indexname = 'idx_pedidos_itens_pedido') THEN
        CREATE INDEX idx_pedidos_itens_pedido ON pedidos_itens(pedido_codigo);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE tablename = 'pedidos_itens' AND indexname = 'idx_pedidos_itens_produto') THEN
        CREATE INDEX idx_pedidos_itens_produto ON pedidos_itens(produto_codigo);
    END IF;
END
$$;

-- Adicionar chave estrangeira se não existir
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_pedido' 
        AND table_name = 'pedidos_itens'
    ) THEN
        ALTER TABLE pedidos_itens
        ADD CONSTRAINT fk_pedido
        FOREIGN KEY (pedido_codigo)
        REFERENCES pedidos(codigo)
        ON DELETE CASCADE;
    END IF;
END
$$; 