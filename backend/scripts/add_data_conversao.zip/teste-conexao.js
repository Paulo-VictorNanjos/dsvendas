const express = require('express');
const cors = require('cors');
const os = require('os');

// Criar app Express
const app = express();

// Habilitar CORS para todos os pedidos
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rota de teste simples
app.get('/', (req, res) => {
  // Obter informações de rede
  const interfaces = os.networkInterfaces();
  const addresses = [];

  // Listar todos os endereços IP da máquina
  Object.keys(interfaces).forEach((ifname) => {
    interfaces[ifname].forEach((iface) => {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({
          interface: ifname,
          address: iface.address
        });
      }
    });
  });

  // Enviar resposta com informações do pedido e da máquina
  res.json({
    message: 'Teste de conexão bem sucedido!',
    time: new Date().toISOString(),
    request: {
      ip: req.ip,
      headers: req.headers,
      method: req.method,
      path: req.path
    },
    server: {
      hostname: os.hostname(),
      platform: os.platform(),
      addresses: addresses,
      nodeVersion: process.version
    }
  });
});

// Iniciar o servidor na porta 3003
const PORT = 3003;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor de teste rodando em http://0.0.0.0:${PORT}`);
  console.log('Para testar, acesse este endpoint a partir de outro dispositivo usando:');
  console.log(`http://SEU_IP_AQUI:${PORT}`);
}); 