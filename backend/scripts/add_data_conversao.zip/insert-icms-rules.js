const knex = require('./database/connection');
const logger = require('./utils/logger');

async function insertIcmsRules() {
  try {
    console.log('Inserindo regras ICMS padrão...');
    
    // Verificar se já existem regras
    const regraExistente = await knex('regras_icms').first();
    
    if (regraExistente) {
      console.log('Já existem regras ICMS no banco, não serão inseridas novas regras.');
      process.exit(0);
    }
    
    // Exemplo de regras para inserir com os campos corretos da tabela
    const regras = [
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'SP',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 18.00, // Alíquota padrão SP
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 18.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 18.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        reducao_somente_icms_proprio: 'N',
        created_at: new Date(),
        updated_at: new Date()
      },
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'RJ',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 20.00, // Alíquota padrão RJ
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 20.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 20.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        reducao_somente_icms_proprio: 'N',
        created_at: new Date(),
        updated_at: new Date()
      },
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'MG',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 18.00, // Alíquota padrão MG
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 18.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 18.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        reducao_somente_icms_proprio: 'N',
        created_at: new Date(),
        updated_at: new Date()
      }
    ];
    
    // Inserir regras no banco
    await knex('regras_icms').insert(regras);
    
    console.log(`${regras.length} regras ICMS inseridas com sucesso!`);
    
    // Verificar inserção
    const regrasInseridas = await knex('regras_icms').select('*');
    console.log('Regras inseridas:', JSON.stringify(regrasInseridas, null, 2));
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao inserir regras ICMS:', error);
    process.exit(1);
  }
}

insertIcmsRules(); 