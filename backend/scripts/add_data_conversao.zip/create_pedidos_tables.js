// Script para criar as tabelas pedidos e pedidos_itens
const knex = require('knex');
const config = require('../knexfile').development;

const db = knex(config);

async function createPedidosTables() {
  try {
    // Verificar se a tabela pedidos já existe
    const hasPedidosTable = await db.schema.hasTable('pedidos');
    
    if (!hasPedidosTable) {
      console.log('Criando tabela pedidos...');
      await db.schema.createTable('pedidos', function(table) {
        table.string('codigo').primary();
        table.string('orcamento_origem');
        table.string('cod_empresa');
        table.string('cod_cliente');
        table.string('cod_vendedor');
        table.date('dt_pedido');
        table.decimal('vl_total', 10, 2);
        table.decimal('vl_produtos', 10, 2);
        table.decimal('vl_desconto', 10, 2);
        table.decimal('vl_st', 10, 2);
        table.decimal('vl_ipi', 10, 2);
        table.string('status').defaultTo('NOVO');
        table.text('observacoes');
        table.string('form_pagto');
        table.string('cond_pagto');
        table.date('dt_inc');
        table.timestamps(true, true);
        
        // Chaves estrangeiras
        table.foreign('orcamento_origem').references('codigo').inTable('orcamentos');
        table.foreign('cod_cliente').references('codigo').inTable('clientes');
        table.foreign('cod_vendedor').references('codigo').inTable('vendedores');
      });
      console.log('Tabela pedidos criada com sucesso!');
    } else {
      console.log('A tabela pedidos já existe no banco de dados.');
    }

    // Verificar se a tabela pedidos_itens já existe
    const hasPedidosItensTable = await db.schema.hasTable('pedidos_itens');
    
    if (!hasPedidosItensTable) {
      console.log('Criando tabela pedidos_itens...');
      await db.schema.createTable('pedidos_itens', function(table) {
        table.string('codigo').primary();
        table.string('pedido_codigo');
        table.string('produto_codigo');
        table.decimal('quantidade', 10, 3);
        table.decimal('valor_unitario', 10, 4);
        table.decimal('valor_total', 10, 2);
        table.decimal('desconto', 10, 2);
        table.decimal('aliq_icms', 10, 2);
        table.decimal('valor_icms', 10, 2);
        table.decimal('valor_icms_st', 10, 2);
        table.decimal('aliq_ipi', 10, 2);
        table.decimal('valor_ipi', 10, 2);
        table.string('cod_empresa');
        table.date('dt_inc');
        table.timestamps(true, true);
        
        // Chaves estrangeiras
        table.foreign('pedido_codigo').references('codigo').inTable('pedidos');
        table.foreign('produto_codigo').references('codigo').inTable('produtos');
      });
      console.log('Tabela pedidos_itens criada com sucesso!');
    } else {
      console.log('A tabela pedidos_itens já existe no banco de dados.');
    }

    console.log('Operação concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao criar tabelas:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
createPedidosTables(); 