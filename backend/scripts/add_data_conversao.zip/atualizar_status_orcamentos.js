// Script para adicionar e atualizar status na tabela orcamentos
const knex = require('knex');
const config = require('../knexfile').development;
const db = knex(config);

async function atualizarStatusOrcamentos() {
  try {
    console.log('Iniciando atualização de status de orçamentos...');
    
    // 1. Verificar se a coluna status existe na tabela orcamentos
    const hasStatusColumn = await db.schema.hasColumn('orcamentos', 'status');
    
    // Se a coluna não existir, criá-la
    if (!hasStatusColumn) {
      console.log('Coluna "status" não encontrada. Adicionando...');
      await db.schema.table('orcamentos', table => {
        table.string('status', 20).nullable();
      });
      console.log('Coluna "status" adicionada com sucesso!');
    } else {
      console.log('Coluna "status" já existe na tabela.');
    }
    
    // 2. Definir status PENDENTE para orçamentos sem status
    const pendingCount = await db('orcamentos')
      .whereNull('status')
      .update({
        status: 'PENDENTE'
      });
    
    console.log(`${pendingCount} orçamentos atualizados para status PENDENTE.`);
    
    // 3. Atualizar orçamentos baseado no cod_status (para compatibilidade)
    // Mapear cod_status para o campo status textual
    const statusMappings = [
      { cod_status: 0, status: 'CANCELADO' },
      { cod_status: 2, status: 'CONVERTIDO' },
      { cod_status: 3, status: 'APROVADO' }
    ];
    
    let totalUpdated = 0;
    
    for (const mapping of statusMappings) {
      const count = await db('orcamentos')
        .where('cod_status', mapping.cod_status)
        .whereNot('status', mapping.status) // Atualizar apenas se o status for diferente
        .update({ status: mapping.status });
      
      console.log(`${count} orçamentos atualizados de cod_status=${mapping.cod_status} para status=${mapping.status}`);
      totalUpdated += count;
    }
    
    // 4. Verificar e atualizar orçamentos que já foram convertidos em pedidos
    const pedidos = await db('pedidos')
      .whereNotNull('orcamento_origem')
      .select('orcamento_origem');
    
    if (pedidos.length > 0) {
      const orcamentosConvertidos = pedidos.map(p => p.orcamento_origem);
      
      const convertedCount = await db('orcamentos')
        .whereIn('codigo', orcamentosConvertidos)
        .whereNot('status', 'CONVERTIDO')
        .update({ status: 'CONVERTIDO' });
      
      console.log(`${convertedCount} orçamentos marcados como CONVERTIDO baseado nos pedidos existentes.`);
      totalUpdated += convertedCount;
    }
    
    // 5. Verificar e atualizar orçamentos que foram aprovados (baseado no campo data_aprovacao)
    const approvedCount = await db('orcamentos')
      .whereNotNull('data_aprovacao')
      .whereNot('status', 'CONVERTIDO') // Não sobrescrever orçamentos já convertidos
      .whereNot('status', 'APROVADO')
      .update({ status: 'APROVADO' });
    
    console.log(`${approvedCount} orçamentos marcados como APROVADO baseado no campo data_aprovacao.`);
    totalUpdated += approvedCount;
    
    console.log(`Total de ${totalUpdated} orçamentos atualizados.`);
    console.log('Atualização de status concluída com sucesso!');
    
  } catch (error) {
    console.error('Erro ao atualizar status de orçamentos:', error);
  } finally {
    // Fechar conexão com o banco
    await db.destroy();
  }
}

// Executar a função
atualizarStatusOrcamentos(); 