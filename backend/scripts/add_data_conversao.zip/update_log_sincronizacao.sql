-- Adicionar novas colunas à tabela log_sincronizacao se não existirem
DO $$
BEGIN
    -- Adicionar coluna entidade
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'log_sincronizacao' 
        AND column_name = 'entidade'
    ) THEN
        ALTER TABLE log_sincronizacao
        ADD COLUMN entidade VARCHAR(50);
    END IF;

    -- Adicionar coluna entidade_id
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'log_sincronizacao' 
        AND column_name = 'entidade_id'
    ) THEN
        ALTER TABLE log_sincronizacao
        ADD COLUMN entidade_id VARCHAR(255);
    END IF;

    -- Adicionar coluna origem
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'log_sincronizacao' 
        AND column_name = 'origem'
    ) THEN
        ALTER TABLE log_sincronizacao
        ADD COLUMN origem VARCHAR(50);
    END IF;

    -- Adicionar coluna mensagem_erro se não existir
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'log_sincronizacao' 
        AND column_name = 'mensagem_erro'
    ) THEN
        ALTER TABLE log_sincronizacao
        ADD COLUMN mensagem_erro TEXT;
    END IF;

    -- Adicionar coluna data_conclusao se não existir
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'log_sincronizacao' 
        AND column_name = 'data_conclusao'
    ) THEN
        ALTER TABLE log_sincronizacao
        ADD COLUMN data_conclusao TIMESTAMP;
    END IF;
END
$$; 