const knex = require('./database/connection');
const erpConnection = require('./database/erpConnection');

async function corrigirRegrasFiscais() {
  try {
    console.log('=== CORREÇÃO DE REGRAS FISCAIS DOS PRODUTOS ===');
    
    // 1. Verificar regras disponíveis no ERP
    console.log('\n1. Verificando regras ICMS disponíveis no ERP:');
    const regrasERP = await erpConnection
      .select('codigo', 'descricao')
      .from('regras_icms_cadastro')
      .whereNull('dt_exc')
      .orderBy('codigo');
      
    console.log(`Encontradas ${regrasERP.length} regras ICMS ativas no ERP:`);
    console.table(regrasERP);
    
    // 2. Buscar produtos no ERP com suas regras fiscais
    console.log('\n2. Buscando produtos no ERP com suas regras fiscais:');
    const produtosERP = await erpConnection
      .select('codigo', 'descricao', 'cod_regra_icms')
      .from('produtos')
      .whereNotNull('cod_regra_icms')
      .andWhereNot('cod_regra_icms', 0)
      .limit(100);
      
    console.log(`Encontrados ${produtosERP.length} produtos com regras fiscais no ERP (limitado a 100):`);
    
    // Analisar a distribuição de regras
    const distribuicaoRegras = {};
    produtosERP.forEach(produto => {
      const regra = produto.cod_regra_icms;
      distribuicaoRegras[regra] = (distribuicaoRegras[regra] || 0) + 1;
    });
    
    console.log('Distribuição de regras fiscais nos produtos do ERP:');
    console.table(Object.keys(distribuicaoRegras).map(regra => ({
      regra_icms: regra,
      quantidade: distribuicaoRegras[regra]
    })));
    
    // 3. Verificar regras fiscais com ST no ERP
    console.log('\n3. Verificando regras fiscais com ST no ERP:');
    const regrasSTERP = await erpConnection
      .select('cod_regra_icms')
      .from('regras_icms_itens')
      .where('uf', 'SP')
      .andWhere('icms_st', 'S')
      .groupBy('cod_regra_icms')
      .orderBy('cod_regra_icms');
      
    console.log(`Encontradas ${regrasSTERP.length} regras com ST ativo para SP:`);
    console.log(regrasSTERP.map(r => r.cod_regra_icms).join(', '));
    
    // 4. Buscar informações dos produtos que usam a regra 8 no ERP
    console.log('\n4. Buscando produtos que usam a regra 8 (ST Importado) no ERP:');
    const produtosRegra8ERP = await erpConnection
      .select('codigo', 'descricao', 'cod_regra_icms')
      .from('produtos')
      .where('cod_regra_icms', 8)
      .limit(10);
      
    console.log(`Encontrados ${produtosRegra8ERP.length} produtos com regra 8 no ERP:`);
    console.table(produtosRegra8ERP);
    
    // Se não encontrou produtos com regra 8, procurar produtos com outras regras que têm ST
    if (produtosRegra8ERP.length === 0 && regrasSTERP.length > 0) {
      console.log('\nBuscando produtos com outras regras que têm ST:');
      const outrasRegrasComST = regrasSTERP.map(r => r.cod_regra_icms);
      
      const produtosSTERP = await erpConnection
        .select('codigo', 'descricao', 'cod_regra_icms')
        .from('produtos')
        .whereIn('cod_regra_icms', outrasRegrasComST)
        .limit(10);
        
      console.log(`Encontrados ${produtosSTERP.length} produtos com regras que têm ST:`);
      console.table(produtosSTERP);
      
      if (produtosSTERP.length > 0) {
        const codigosProdutos = produtosSTERP.map(p => p.codigo);
        
        // Verificar se esses produtos existem no sistema web
        const produtosSTWeb = await knex('produtos')
          .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
          .whereIn('codigo', codigosProdutos);
          
        console.log(`Encontrados ${produtosSTWeb.length} destes produtos no sistema web:`);
        console.table(produtosSTWeb);
        
        // Atualizar os produtos para usar a regra correta e ativar ST
        if (produtosSTWeb.length > 0) {
          console.log('\nAtualizando produtos para usar a regra correta e ativar ST:');
          
          for (const produto of produtosSTWeb) {
            const produtoERP = produtosSTERP.find(p => p.codigo === produto.codigo);
            if (produtoERP) {
              console.log(`Atualizando produto ${produto.codigo} para regra ${produtoERP.cod_regra_icms} com ST=1`);
              
              await knex('produtos')
                .where('codigo', produto.codigo)
                .update({
                  cod_regra_icms: produtoERP.cod_regra_icms,
                  subs_trib: 1
                });
            }
          }
          
          // Verificar resultado
          const produtosAtualizados = await knex('produtos')
            .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
            .whereIn('codigo', codigosProdutos);
            
          console.log('\nProdutos após atualização:');
          console.table(produtosAtualizados);
        }
      }
    }
    
  } catch (error) {
    console.error('Erro durante a correção:', error);
  } finally {
    knex.destroy();
    erpConnection.destroy();
  }
}

corrigirRegrasFiscais().then(() => {
  console.log('\nProcesso de correção concluído!');
}); 