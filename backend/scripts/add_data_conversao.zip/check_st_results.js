const knex = require('./database/connection');

async function verificarResultadosST() {
  try {
    console.log('=== VERIFICAÇÃO DE RESULTADOS DA SINCRONIZAÇÃO DE ST ===');
    
    // 1. Verificar produtos com ST ativo
    console.log('\n1. Produtos com substituição tributária ativa (subs_trib = 1):');
    const produtosComST = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .where('subs_trib', 1)
      .orderBy('cod_regra_icms')
      .limit(10);
      
    console.log(`Encontrados ${produtosComST.length} produtos com ST ativo (mostrando primeiros 10):`);
    console.table(produtosComST);
    
    // 2. Buscar o total de produtos por status de ST
    console.log('\n2. Total de produtos por status de substituição tributária:');
    const totalPorST = await knex('produtos')
      .select('subs_trib')
      .count('* as total')
      .groupBy('subs_trib');
      
    const formattedTotals = totalPorST.map(item => ({
      subs_trib: item.subs_trib === null ? 'NULL' : item.subs_trib.toString(),
      total: item.total
    }));
    
    console.table(formattedTotals);
    
    // 3. Verificar produtos para regra específica 8 (ST Importado)
    console.log('\n3. Verificando produtos com regra 8 (ST Importado):');
    const produtosRegra8 = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .where('cod_regra_icms', 8)
      .limit(10);
      
    console.log(`Encontrados ${produtosRegra8.length} produtos com regra 8:`);
    console.table(produtosRegra8);
    
    // 4. Verificar distribuição de produtos por regra fiscal
    console.log('\n4. Distribuição de produtos por regra fiscal:');
    const totalPorRegra = await knex('produtos')
      .select('cod_regra_icms')
      .count('* as total')
      .whereNotNull('cod_regra_icms')
      .groupBy('cod_regra_icms')
      .orderBy('total', 'desc');
      
    console.table(totalPorRegra);
    
  } catch (error) {
    console.error('Erro durante a verificação:', error);
  } finally {
    knex.destroy();
  }
}

verificarResultadosST().then(() => {
  console.log('\nVerificação concluída!');
}); 