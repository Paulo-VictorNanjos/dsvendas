const knex = require('./database/connection');
const erpConnection = require('./database/erpConnection');

async function debugSubstituicaoTributaria() {
  console.log('=== DEPURAÇÃO DE SUBSTITUIÇÃO TRIBUTÁRIA (ST) ===');
  
  try {
    // 1. Verificar a regra de ICMS 8 no ERP
    console.log('\n1. Verificando a regra de ICMS 8 no ERP...');
    const regraERPCadastro = await erpConnection
      .select('*')
      .from('regras_icms_cadastro')
      .where('codigo', 8)
      .first();
      
    console.log('Regra 8 no cadastro ERP:', regraERPCadastro || 'Não encontrada');
    
    // 2. Verificar itens da regra de ICMS 8 no ERP
    const regrasERPItens = await erpConnection
      .select('*')
      .from('regras_icms_itens')
      .where('cod_regra_icms', 8);
      
    console.log(`\nEncontrados ${regrasERPItens.length} itens para a regra 8 no ERP`);
    
    if (regrasERPItens.length > 0) {
      console.log('Primeiros 5 itens da regra 8 no ERP:');
      for (let i = 0; i < Math.min(5, regrasERPItens.length); i++) {
        console.log(`Item ${i+1}:`, regrasERPItens[i]);
      }
    }
    
    // 3. Verificar a regra 8 no sistema web
    console.log('\n3. Verificando a regra de ICMS 8 no sistema web...');
    const regraWebCadastro = await knex
      .select('*')
      .from('regras_icms_cadastro')
      .where('codigo', 8)
      .first();
      
    console.log('Regra 8 no cadastro web:', regraWebCadastro || 'Não encontrada');
    
    // 4. Verificar itens da regra 8 no sistema web
    const regrasWebItens = await knex
      .select('*')
      .from('regras_icms_itens')
      .where('cod_regra_icms', 8);
      
    console.log(`\nEncontrados ${regrasWebItens.length} itens para a regra 8 no sistema web`);
    
    if (regrasWebItens.length > 0) {
      console.log('Primeiros 5 itens da regra 8 no sistema web:');
      for (let i = 0; i < Math.min(5, regrasWebItens.length); i++) {
        console.log(`Item ${i+1}:`, regrasWebItens[i]);
      }
    }
    
    // 5. Buscar produtos que usam a regra 8 no ERP
    console.log('\n5. Buscando produtos que usam a regra 8 no ERP...');
    const produtosComRegra8ERP = await erpConnection
      .select('codigo', 'descricao', 'cod_regra_icms', 'aliq_ipi')
      .from('produtos')
      .where('cod_regra_icms', 8)
      .limit(10);
      
    console.log(`Encontrados ${produtosComRegra8ERP.length} produtos com regra 8 no ERP`);
    if (produtosComRegra8ERP.length > 0) {
      console.table(produtosComRegra8ERP);
      
      // Guardar códigos para comparação
      const codigosProdutos = produtosComRegra8ERP.map(p => p.codigo);
      
      // 6. Verificar esses mesmos produtos no sistema web
      console.log('\n6. Verificando os mesmos produtos no sistema web...');
      const produtosComRegra8Web = await knex
        .select('codigo', 'descricao', 'cod_regra_icms', 'aliq_ipi', 'subs_trib')
        .from('produtos')
        .whereIn('codigo', codigosProdutos);
        
      console.log(`Encontrados ${produtosComRegra8Web.length} dos produtos no sistema web`);
      if (produtosComRegra8Web.length > 0) {
        console.table(produtosComRegra8Web);
      }
      
      // 7. Verificar se existe a coluna para ST no sistema web
      console.log('\n7. Verificando estrutura da tabela produtos no sistema web...');
      const colunasWeb = await knex('produtos').columnInfo();
      console.log('Colunas relacionadas a ST na tabela produtos:');
      
      const stColunas = Object.keys(colunasWeb).filter(coluna => 
        coluna.toLowerCase().includes('st') || 
        coluna.toLowerCase().includes('subs') || 
        coluna.toLowerCase().includes('substituicao')
      );
      
      console.log(stColunas);
      
      // 8. Verificar como a tabela de regras fiscais está se relacionando com os produtos
      console.log('\n8. Verificando regras fiscais dos produtos no sistema web...');
      const regrasFiscaisProdutos = await knex
        .select('*')
        .from('regras_fiscais_produtos')
        .whereIn('cod_produto', codigosProdutos)
        .andWhere('ativo', true);
        
      console.log(`Encontradas ${regrasFiscaisProdutos.length} regras fiscais ativas para os produtos`);
      if (regrasFiscaisProdutos.length > 0) {
        console.table(regrasFiscaisProdutos);
      }
      
      // 9. Simular a atualização de um produto com ST
      if (produtosComRegra8ERP.length > 0) {
        console.log('\n9. Simulando atualização de um produto com ST...');
        const produtoTeste = produtosComRegra8ERP[0].codigo;
        
        // Buscar detalhes da regra para este produto
        const regraDetalhes = regrasWebItens.find(r => r.uf === 'SP') || regrasWebItens[0];
        
        if (regraDetalhes) {
          console.log(`Atualizando produto ${produtoTeste} com ST: ${regraDetalhes.icms_st || 'N'}`);
          
          // Atualizar o produto
          await knex('produtos')
            .where('codigo', produtoTeste)
            .update({
              cod_regra_icms: 8,
              subs_trib: regraDetalhes.icms_st === 'S' ? 'S' : 'N'
            });
            
          // Verificar produto atualizado
          const produtoAtualizado = await knex('produtos')
            .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
            .where('codigo', produtoTeste)
            .first();
            
          console.log('Produto após atualização:');
          console.log(produtoAtualizado);
        } else {
          console.log('Não foi possível encontrar detalhes da regra para simular a atualização');
        }
      }
    }
    
  } catch (error) {
    console.error('ERRO durante a depuração:', error);
  } finally {
    // Encerrar conexões
    knex.destroy();
    erpConnection.destroy();
  }
}

// Executar a função de depuração
debugSubstituicaoTributaria().then(() => {
  console.log('\nProcesso de depuração concluído!');
}).catch(err => {
  console.error('Erro fatal:', err);
}); 