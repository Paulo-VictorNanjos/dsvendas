/**
 * Script para sincronização de clientes do ERP
 * Foco na correta importação de UF e município
 */

require('dotenv').config();
const knex = require('./database/connection');
const erpConnection = require('./database/erpConnection');
const syncService = require('./services/syncService');
const logger = require('./utils/logger');

async function sincronizarClientes() {
  try {
    console.log('==========================================================');
    console.log('  SINCRONIZAÇÃO DE CLIENTES (FOCO EM UF E MUNICÍPIO)');
    console.log('==========================================================');
    
    // Verificar conexão com ERP
    try {
      await erpConnection.raw('SELECT 1');
      console.log('[OK] Conexão com banco de dados ERP estabelecida');
    } catch (errConn) {
      console.error('[ERRO] Falha ao conectar ao banco de dados ERP:', errConn.message);
      process.exit(1);
    }
    
    // Verificar conexão com banco local
    try {
      await knex.raw('SELECT 1');
      console.log('[OK] Conexão com banco de dados local estabelecida');
    } catch (errConn) {
      console.error('[ERRO] Falha ao conectar ao banco de dados local:', errConn.message);
      process.exit(1);
    }
    
    // Garantir que tabelas necessárias existem no banco local
    await verificarTabelas();
    
    // Buscar clientes diretamente usando a estrutura conhecida da tabela
    console.log('[INFO] Buscando clientes do ERP...');
    
    // Baseado na estrutura da tabela fornecida
    const clientesERP = await erpConnection('clientes')
      .select(
        'codigo',
        'razao', 
        'nome',
        'cnpj',
        'cpf',
        'municipio',
        'uf',
        'uf_insc_rg',
        'insc_mun',
        'cep',
        'logradouro',
        'logradouro_num',
        'complemento',
        'bairro',
        'cod_ibge',
        'cod_status'
      )
      .whereNull('dt_exc')
      .limit(2000);
    
    console.log(`[INFO] Encontrados ${clientesERP.length} clientes no ERP`);
    
    // Exibir estatísticas da qualidade dos dados
    const clientesComUF = clientesERP.filter(c => c.uf && c.uf.trim() !== '').length;
    const clientesComMunicipio = clientesERP.filter(c => c.municipio && c.municipio.trim() !== '').length;
    
    console.log(`[INFO] Clientes com UF preenchida: ${clientesComUF}/${clientesERP.length} (${Math.round(clientesComUF/clientesERP.length*100)}%)`);
    console.log(`[INFO] Clientes com Município preenchido: ${clientesComMunicipio}/${clientesERP.length} (${Math.round(clientesComMunicipio/clientesERP.length*100)}%)`);
    
    if (clientesERP.length > 0) {
      console.log('[INFO] Exemplo de cliente recuperado:');
      console.log(JSON.stringify(clientesERP[0], null, 2));
    }
    
    // Garantir que a tabela de estados está populada
    await verificarEstados();
    
    // Processar clientes para garantir UF e município corretos
    console.log('[INFO] Processando dados dos clientes para garantir UF e município corretos...');
    const clientesProcessados = await processarClientes(clientesERP);
    
    // Sincronizar clientes com o banco local
    console.log('[INFO] Sincronizando clientes com o banco local...');
    let inseridos = 0;
    let atualizados = 0;
    
    for (const cliente of clientesProcessados) {
      try {
        // Verificar se o cliente já existe
        const clienteExistente = await knex('clientes')
          .where('codigo', cliente.codigo)
          .first();
        
        if (clienteExistente) {
          // Verificar se a tabela de clientes tem a coluna dt_alt
          const hasColumn = await knex.schema.hasColumn('clientes', 'dt_alt');
          
          // Atualizar cliente existente
          if (hasColumn) {
            // Se a coluna dt_alt existe, incluir no update
            await knex('clientes')
              .where('codigo', cliente.codigo)
              .update({
                ...cliente,
                dt_alt: knex.fn.now()
              });
          } else {
            // Se a coluna dt_alt não existe, não incluir no update
            await knex('clientes')
              .where('codigo', cliente.codigo)
              .update(cliente);
          }
          
          atualizados++;
          
          // Log a cada 50 atualizações
          if (atualizados % 50 === 0) {
            console.log(`[INFO] ${atualizados} clientes atualizados...`);
          }
        } else {
          // Inserir novo cliente
          await knex('clientes').insert(cliente);
          inseridos++;
          
          // Log a cada 50 inserções
          if (inseridos % 50 === 0) {
            console.log(`[INFO] ${inseridos} clientes inseridos...`);
          }
        }
      } catch (errCliente) {
        console.error(`[ERRO] Falha ao processar cliente ${cliente.codigo}:`, errCliente.message);
      }
    }
    
    console.log('==========================================================');
    console.log(`RESULTADO DA SINCRONIZAÇÃO:`);
    console.log(`- Total de clientes no ERP: ${clientesERP.length}`);
    console.log(`- Clientes inseridos: ${inseridos}`);
    console.log(`- Clientes atualizados: ${atualizados}`);
    console.log(`- Total processado: ${inseridos + atualizados}`);
    console.log('==========================================================');
    
    process.exit(0);
  } catch (error) {
    console.error('[ERRO FATAL] Falha na sincronização:', error);
    process.exit(1);
  }
}

/**
 * Processa os clientes para garantir que UF e município estão corretos
 */
async function processarClientes(clientes) {
  const clientesProcessados = [];
  
  for (const cliente of clientes) {
    try {
      // Criar cópia do cliente para não modificar o original
      const clienteProcessado = { ...cliente };
      
      // Garantir valores padrão para campos nulos
      clienteProcessado.razao = clienteProcessado.razao || '';
      clienteProcessado.nome = clienteProcessado.nome || '';
      clienteProcessado.cnpj = clienteProcessado.cnpj || clienteProcessado.cpf || '';
      clienteProcessado.uf = clienteProcessado.uf || '';
      clienteProcessado.municipio = clienteProcessado.municipio || '';
      clienteProcessado.cod_ibge = clienteProcessado.cod_ibge || '';
      
      // Normalizar UF (maiúsculas e remover espaços)
      if (clienteProcessado.uf) {
        clienteProcessado.uf = clienteProcessado.uf.trim().toUpperCase();
        
        // Verificar se UF é válida (2 caracteres)
        if (clienteProcessado.uf.length !== 2) {
          console.log(`[INFO] UF inválida para cliente ${clienteProcessado.codigo}: "${clienteProcessado.uf}" - resetando`);
          clienteProcessado.uf = '';
        }
      }
      
      // Se não temos UF válida, tentar determinar pela tabela IBGE usando o município
      if (!clienteProcessado.uf && clienteProcessado.municipio) {
        try {
          // Buscar no IBGE pelo nome do município
          const ibgeData = await knex('ibge')
            .whereRaw('LOWER(nome) LIKE ?', [`%${clienteProcessado.municipio.toLowerCase().trim()}%`])
            .first();
            
          if (ibgeData) {
            clienteProcessado.uf = ibgeData.uf;
            clienteProcessado.municipio = ibgeData.nome; // Nome padronizado
            clienteProcessado.cod_ibge = ibgeData.codigo;
            console.log(`[INFO] UF '${ibgeData.uf}' encontrada para cliente ${clienteProcessado.codigo} pelo município '${clienteProcessado.municipio}'`);
          }
        } catch (error) {
          console.log(`[INFO] Erro ao buscar IBGE para cliente ${clienteProcessado.codigo}:`, error.message);
        }
      }
      
      // Se não temos município mas temos UF e código IBGE, buscar município
      if ((!clienteProcessado.municipio || clienteProcessado.municipio.trim() === '') && 
          clienteProcessado.uf && clienteProcessado.cod_ibge) {
        try {
          // Buscar no IBGE pelo código
          const ibgeData = await knex('ibge')
            .where('codigo', String(clienteProcessado.cod_ibge).padStart(7, '0'))
            .first();
            
          if (ibgeData) {
            clienteProcessado.municipio = ibgeData.nome;
            console.log(`[INFO] Município '${ibgeData.nome}' encontrado para cliente ${clienteProcessado.codigo} pelo código IBGE`);
          }
        } catch (error) {
          console.log(`[INFO] Erro ao buscar município por código IBGE para cliente ${clienteProcessado.codigo}:`, error.message);
        }
      }
      
      // Se ainda não temos UF, usar SP como padrão
      if (!clienteProcessado.uf) {
        clienteProcessado.uf = 'SP';
        console.log(`[INFO] Usando UF padrão (SP) para cliente ${clienteProcessado.codigo}`);
      }
      
      // Adicionar campos obrigatórios
      clienteProcessado.cod_empresa = 1;
      clienteProcessado.cod_status = clienteProcessado.cod_status || 1;
      
      // Limitar tamanho dos campos conforme definição da tabela
      const clienteFinal = {
        codigo: clienteProcessado.codigo,
        razao: (clienteProcessado.razao || '').substring(0, 60),
        nome: (clienteProcessado.nome || '').substring(0, 60),
        cnpj: (clienteProcessado.cnpj || '').substring(0, 19),
        uf_insc_rg: (clienteProcessado.uf_insc_rg || '').substring(0, 2).toUpperCase(),
        insc_mun: (clienteProcessado.insc_mun || '').substring(0, 10),
        cep: (clienteProcessado.cep || '').substring(0, 8),
        logradouro: (clienteProcessado.logradouro || '').substring(0, 90),
        logradouro_num: (clienteProcessado.logradouro_num || '').substring(0, 10),
        complemento: (clienteProcessado.complemento || '').substring(0, 200),
        bairro: (clienteProcessado.bairro || '').substring(0, 200),
        cod_ibge: (clienteProcessado.cod_ibge || '').substring(0, 50),
        municipio: (clienteProcessado.municipio || '').substring(0, 60),
        uf: clienteProcessado.uf.substring(0, 2).toUpperCase(),
        cod_empresa: 1,
        cod_status: clienteProcessado.cod_status || 1
      };
      
      clientesProcessados.push(clienteFinal);
    } catch (error) {
      console.error(`[ERRO] Falha ao processar cliente ${cliente.codigo}:`, error.message);
    }
  }
  
  return clientesProcessados;
}

/**
 * Verifica e cria as tabelas necessárias se não existirem
 */
async function verificarTabelas() {
  // Verificar tabela de clientes
  const hasClientesTable = await knex.schema.hasTable('clientes');
  if (!hasClientesTable) {
    console.log('[INFO] Criando tabela de clientes...');
    await knex.schema.createTable('clientes', table => {
      table.integer('codigo').primary();
      table.string('razao', 60);
      table.string('nome', 60);
      table.string('cnpj', 19);
      table.string('uf_insc_rg', 2);
      table.string('insc_mun', 10);
      table.string('cep', 8);
      table.string('logradouro', 90);
      table.string('logradouro_num', 10);
      table.string('complemento', 200);
      table.string('bairro', 200);
      table.string('cod_ibge', 50);
      table.string('municipio', 60);
      table.string('uf', 2);
      table.integer('cod_empresa');
      table.integer('cod_status');
      table.timestamp('dt_alt').defaultTo(knex.fn.now());
    });
    console.log('[OK] Tabela de clientes criada');
  } else {
    // Verificar se a coluna insc_est existe, se existir, não mencionar no processamento
    const hasInscEstColumn = await knex.schema.hasColumn('clientes', 'insc_est');
    if (hasInscEstColumn) {
      console.log('[INFO] Coluna insc_est encontrada e será usada');
    } else {
      console.log('[INFO] Coluna insc_est não encontrada, será ignorada no processamento');
    }
    
    // Verificar se a coluna dt_alt existe, se não existir, adicionar
    const hasDtAltColumn = await knex.schema.hasColumn('clientes', 'dt_alt');
    if (!hasDtAltColumn) {
      console.log('[INFO] Coluna dt_alt não encontrada, adicionando...');
      await knex.schema.table('clientes', table => {
        table.timestamp('dt_alt').defaultTo(knex.fn.now());
      });
      console.log('[OK] Coluna dt_alt adicionada à tabela clientes');
    }
  }

  // Verificar tabela de IBGE
  const hasIbgeTable = await knex.schema.hasTable('ibge');
  if (!hasIbgeTable) {
    console.log('[INFO] Criando tabela IBGE...');
    await knex.schema.createTable('ibge', table => {
      table.string('codigo', 7).primary();
      table.string('nome', 100).notNullable();
      table.string('uf', 2).notNullable();
      table.string('regiao', 20);
      table.boolean('capital').defaultTo(false);
      table.string('ddd', 2);
      table.string('codigo_siafi', 4);
      table.boolean('ativo').defaultTo(true);
      table.timestamp('dt_alt').defaultTo(knex.fn.now());
      
      table.index(['uf', 'nome']);
    });
    console.log('[OK] Tabela IBGE criada');
    console.log('[INFO] É necessário popular a tabela IBGE antes de continuar');
    
    // Verificar se é necessário executar seed de IBGE
    const countIbge = await knex('ibge').count('* as count').first();
    if (countIbge.count === 0) {
      console.log('[ALERTA] Tabela IBGE está vazia. Execute o seed de IBGE antes de continuar.');
    }
  }

  // Verificar tabela de estados
  const hasEstadosTable = await knex.schema.hasTable('estados');
  if (!hasEstadosTable) {
    console.log('[INFO] Criando tabela de estados...');
    await knex.schema.createTable('estados', table => {
      table.string('uf', 2).primary();
      table.string('nome', 50).notNullable();
      table.string('codigo_ibge', 2);
      table.boolean('ativo').defaultTo(true);
      table.timestamp('dt_alt').defaultTo(knex.fn.now());
    });
    console.log('[OK] Tabela de estados criada');
  }
}

/**
 * Verifica se a tabela de estados está populada e adiciona estados padrão se necessário
 */
async function verificarEstados() {
  const countEstados = await knex('estados').count('* as count').first();
  
  if (countEstados.count === 0) {
    console.log('[INFO] Populando tabela de estados com dados padrão...');
    
    // Lista de estados brasileiros
    const estados = [
      { uf: 'AC', nome: 'Acre' },
      { uf: 'AL', nome: 'Alagoas' },
      { uf: 'AP', nome: 'Amapá' },
      { uf: 'AM', nome: 'Amazonas' },
      { uf: 'BA', nome: 'Bahia' },
      { uf: 'CE', nome: 'Ceará' },
      { uf: 'DF', nome: 'Distrito Federal' },
      { uf: 'ES', nome: 'Espírito Santo' },
      { uf: 'GO', nome: 'Goiás' },
      { uf: 'MA', nome: 'Maranhão' },
      { uf: 'MT', nome: 'Mato Grosso' },
      { uf: 'MS', nome: 'Mato Grosso do Sul' },
      { uf: 'MG', nome: 'Minas Gerais' },
      { uf: 'PA', nome: 'Pará' },
      { uf: 'PB', nome: 'Paraíba' },
      { uf: 'PR', nome: 'Paraná' },
      { uf: 'PE', nome: 'Pernambuco' },
      { uf: 'PI', nome: 'Piauí' },
      { uf: 'RJ', nome: 'Rio de Janeiro' },
      { uf: 'RN', nome: 'Rio Grande do Norte' },
      { uf: 'RS', nome: 'Rio Grande do Sul' },
      { uf: 'RO', nome: 'Rondônia' },
      { uf: 'RR', nome: 'Roraima' },
      { uf: 'SC', nome: 'Santa Catarina' },
      { uf: 'SP', nome: 'São Paulo' },
      { uf: 'SE', nome: 'Sergipe' },
      { uf: 'TO', nome: 'Tocantins' }
    ];
    
    // Inserir estados
    for (const estado of estados) {
      await knex('estados').insert({
        ...estado,
        ativo: true
      });
    }
    
    console.log('[OK] Tabela de estados populada com sucesso');
  } else {
    console.log(`[OK] Tabela de estados já está populada com ${countEstados.count} registros`);
  }
}

// Executar a sincronização
sincronizarClientes().catch(err => {
  console.error('Erro não tratado:', err);
  process.exit(1);
}); 