const knex = require('./database/connection');

async function atualizarProdutoComST() {
  try {
    console.log('=== ATUALIZAÇÃO MANUAL DE PRODUTO COM ST ===');
    
    // Produto a ser atualizado - substitua por um código existente no seu sistema
    const codigoProduto = '3196';
    
    // Verificar se o produto existe
    const produto = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .where('codigo', codigoProduto)
      .first();
      
    if (!produto) {
      console.log(`Produto com código ${codigoProduto} não encontrado.`);
      return;
    }
    
    console.log('Produto antes da atualização:');
    console.log(produto);
    
    // Atualizar o produto para usar a regra 8 e ativar ST
    await knex('produtos')
      .where('codigo', codigoProduto)
      .update({
        cod_regra_icms: 8,
        subs_trib: 1
      });
      
    console.log(`\nProduto ${codigoProduto} atualizado para regra 8 com ST=1`);
    
    // Verificar a atualização
    const produtoAtualizado = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .where('codigo', codigoProduto)
      .first();
      
    console.log('Produto após atualização:');
    console.log(produtoAtualizado);
    
  } catch (error) {
    console.error('Erro ao atualizar produto:', error);
  } finally {
    knex.destroy();
  }
}

atualizarProdutoComST().then(() => {
  console.log('\nProcesso de atualização concluído!');
}); 