-- Criar tabela de formas de pagamento
CREATE TABLE IF NOT EXISTS form_pagto (
    codigo SERIAL PRIMARY KEY,
    descricao VARCHAR(100) NOT NULL,
    cod_status INTEGER DEFAULT 1,
    cod_empresa INTEGER DEFAULT 1
);

-- Criar tabela de condições de pagamento
CREATE TABLE IF NOT EXISTS cond_pagto (
    codigo SERIAL PRIMARY KEY,
    descricao VARCHAR(100) NOT NULL,
    num_parcelas INTEGER NOT NULL DEFAULT 1,
    prazo_primeira INTEGER DEFAULT 0, -- Prazo em dias para primeira parcela
    prazo_demais INTEGER DEFAULT 30,  -- Prazo em dias entre as demais parcelas
    cod_status INTEGER DEFAULT 1,
    cod_empresa INTEGER DEFAULT 1
);

-- Adicionar colunas na tabela de orçamentos
DO $$
BEGIN
    -- Adicionar coluna form_pagto se não existir
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'orcamentos' 
        AND column_name = 'form_pagto'
    ) THEN
        ALTER TABLE orcamentos
        ADD COLUMN form_pagto INTEGER REFERENCES form_pagto(codigo);
    END IF;

    -- Adicionar coluna cond_pagto se não existir
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'orcamentos' 
        AND column_name = 'cond_pagto'
    ) THEN
        ALTER TABLE orcamentos
        ADD COLUMN cond_pagto INTEGER REFERENCES cond_pagto(codigo);
    END IF;
END
$$; 