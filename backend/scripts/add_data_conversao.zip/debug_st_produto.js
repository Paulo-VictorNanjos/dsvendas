const knex = require('./database/connection');
const erpConnection = require('./database/erpConnection');

async function debugSTProdutos() {
  console.log('=== DEPURAÇÃO DE SUBSTITUIÇÃO TRIBUTÁRIA (ST) EM PRODUTOS ===');
  
  try {
    // 1. Primeiro, vamos buscar produtos no ERP que possuem regras com ST
    console.log('\n1. Buscando produtos no ERP com regras associadas a ST...');
    
    // Encontrar regras com ST marcado como 'S'
    const regrasComST = await erpConnection
      .select('codigo')
      .from('regras_icms_cadastro')
      .whereIn('codigo', function() {
        this.select('cod_regra_icms')
          .from('regras_icms_itens')
          .where('icms_st', 'S')
          .groupBy('cod_regra_icms');
      });
      
    if (regrasComST.length === 0) {
      console.log('Não foram encontradas regras de ICMS com ST no ERP');
      return;
    }
    
    const codigosRegrasComST = regrasComST.map(r => r.codigo);
    console.log(`Encontradas ${regrasComST.length} regras com ST: ${codigosRegrasComST.join(', ')}`);
    
    // Buscar produtos que usam essas regras
    const produtosComST = await erpConnection
      .select('codigo', 'descricao', 'cod_regra_icms')
      .from('produtos')
      .whereIn('cod_regra_icms', codigosRegrasComST)
      .limit(10);
      
    if (produtosComST.length === 0) {
      console.log('Não foram encontrados produtos no ERP com regras de ST');
      
      // Vamos buscar 5 produtos aleatórios para teste
      console.log('\nBuscando produtos aleatórios no ERP para teste...');
      const produtosAleatorios = await erpConnection
        .select('codigo', 'descricao', 'cod_regra_icms')
        .from('produtos')
        .whereNotNull('cod_regra_icms')
        .limit(5);
        
      console.log('Produtos aleatórios encontrados:');
      console.table(produtosAleatorios);
      
      // Vamos usar o primeiro produto como exemplo
      if (produtosAleatorios.length > 0) {
        const produtoExemplo = produtosAleatorios[0];
        console.log(`\nUsando produto ${produtoExemplo.codigo} como exemplo para configurar ST`);
        
        // Buscar regra associada a este produto
        const regraIcms = await erpConnection
          .select('*')
          .from('regras_icms_itens')
          .where('cod_regra_icms', produtoExemplo.cod_regra_icms)
          .andWhere('uf', 'SP')
          .first();
          
        if (regraIcms) {
          console.log(`Regra ICMS do produto: ${regraIcms.cod_regra_icms}, ST atual: ${regraIcms.icms_st || 'N'}`);
          
          // Verificar produto no sistema web
          const produtoWeb = await knex('produtos')
            .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
            .where('codigo', produtoExemplo.codigo)
            .first();
            
          console.log('Produto no sistema web:');
          console.log(produtoWeb);
          
          // Atualizar o produto com ST
          await knex('produtos')
            .where('codigo', produtoExemplo.codigo)
            .update({
              cod_regra_icms: produtoExemplo.cod_regra_icms,
              subs_trib: 'S' // Forçar ST para teste
            });
            
          // Verificar produto atualizado
          const produtoAtualizado = await knex('produtos')
            .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
            .where('codigo', produtoExemplo.codigo)
            .first();
            
          console.log('Produto após atualização:');
          console.log(produtoAtualizado);
        }
      }
      
      return;
    }
    
    console.log(`Encontrados ${produtosComST.length} produtos com regras de ST no ERP`);
    console.table(produtosComST);
    
    // 2. Verificar esses produtos no sistema web
    const codigosProdutos = produtosComST.map(p => p.codigo);
    
    console.log('\n2. Verificando esses produtos no sistema web...');
    const produtosWebST = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .whereIn('codigo', codigosProdutos);
      
    console.log(`Encontrados ${produtosWebST.length} produtos correspondentes no sistema web`);
    console.table(produtosWebST);
    
    // 3. Analisar a correspondência entre regras e ST
    console.log('\n3. Analisando correspondência entre regras e ST...');
    
    // Buscar todos os itens de regras para os produtos em questão
    const regrasDetalhesSP = await erpConnection
      .select('cod_regra_icms', 'icms_st')
      .from('regras_icms_itens')
      .whereIn('cod_regra_icms', produtosComST.map(p => p.cod_regra_icms))
      .andWhere('uf', 'SP'); // Filtramos apenas para SP para simplificar
      
    console.log('Detalhes das regras para UF=SP:');
    console.table(regrasDetalhesSP);
    
    // Criar mapa para verificar a correspondência
    const mapaST = {};
    for (const regra of regrasDetalhesSP) {
      mapaST[regra.cod_regra_icms] = regra.icms_st === 'S';
    }
    
    // Verificar produtos web vs status ST esperado
    for (const produto of produtosWebST) {
      const stEsperado = mapaST[produto.cod_regra_icms] ? 'S' : 'N';
      const stAtual = produto.subs_trib || 'N';
      console.log(`Produto ${produto.codigo}: ST Esperado=${stEsperado}, ST Atual=${stAtual}, Match=${stEsperado === stAtual}`);
    }
    
    // 4. Testar a atualização de um produto
    if (produtosWebST.length > 0) {
      const produtoTeste = produtosWebST[0];
      const stEsperado = mapaST[produtoTeste.cod_regra_icms] ? 'S' : 'N';
      
      console.log(`\n4. Atualizando o produto ${produtoTeste.codigo} com ST=${stEsperado}...`);
      
      await knex('produtos')
        .where('codigo', produtoTeste.codigo)
        .update({
          subs_trib: stEsperado
        });
        
      // Verificar atualização
      const produtoAtualizado = await knex('produtos')
        .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
        .where('codigo', produtoTeste.codigo)
        .first();
        
      console.log('Produto após atualização:');
      console.log(produtoAtualizado);
    }
    
  } catch (error) {
    console.error('ERRO durante a depuração:', error);
  } finally {
    // Encerrar conexões
    knex.destroy();
    erpConnection.destroy();
  }
}

// Executar a função de depuração
debugSTProdutos().then(() => {
  console.log('\nProcesso de depuração concluído!');
}).catch(err => {
  console.error('Erro fatal:', err);
}); 