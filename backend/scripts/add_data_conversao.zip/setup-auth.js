const db = require('../database/connection');
const bcrypt = require('bcryptjs');

async function setupAuth() {
  try {
    // Dropar tabela se existir (com CASCADE)
    await db.raw('DROP TABLE IF EXISTS usuarios CASCADE');
    console.log('✅ Tabela antiga removida (se existia)');

    // Criar extensão uuid-ossp
    await db.raw('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
    console.log('✅ Extensão uuid-ossp criada/verificada');

    // Criar tabela de usuários
    await db.schema.createTable('usuarios', function(table) {
      table.uuid('id').primary().defaultTo(db.raw('uuid_generate_v4()'));
      table.string('nome').notNullable();
      table.string('email').notNullable().unique();
      table.string('senha').notNullable();
      table.string('role').notNullable().defaultTo('user');
      table.boolean('ativo').notNullable().defaultTo(true);
      table.timestamp('dt_inc').notNullable().defaultTo(db.fn.now());
      table.timestamp('dt_alt');
      table.timestamp('ultimo_login');
    });
    console.log('✅ Tabela de usuários criada');

    // Criar usuário admin
    const senha = await bcrypt.hash('admin123', 10);
    await db('usuarios').insert({
      nome: 'Administrador',
      email: 'admin@dsvendas.com',
      senha: senha,
      role: 'admin'
    });
    
    console.log('✅ Sistema de autenticação configurado com sucesso!');
    console.log('Usuário admin criado:');
    console.log('Email: admin@dsvendas.com');
    console.log('Senha: admin123');

    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao configurar sistema de autenticação:', error);
    process.exit(1);
  }
}

setupAuth(); 