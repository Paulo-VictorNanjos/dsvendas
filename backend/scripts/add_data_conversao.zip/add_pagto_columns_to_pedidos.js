// Script para adicionar as colunas form_pagto e cond_pagto à tabela pedidos
const knex = require('knex');
const config = require('../knexfile').development;

const db = knex(config);

async function addPagtoColumnsToPedidos() {
  try {
    console.log('Verificando e adicionando colunas de pagamento à tabela pedidos...');
    
    // Verificar se a coluna form_pagto já existe
    const hasFormPagtoColumn = await db.schema.hasColumn('pedidos', 'form_pagto');
    
    if (!hasFormPagtoColumn) {
      console.log('Adicionando coluna form_pagto à tabela pedidos...');
      await db.schema.table('pedidos', function(table) {
        table.string('form_pagto').nullable();
      });
      console.log('Coluna form_pagto adicionada com sucesso!');
    } else {
      console.log('A coluna form_pagto já existe na tabela pedidos.');
    }

    // Verificar se a coluna cond_pagto já existe
    const hasCondPagtoColumn = await db.schema.hasColumn('pedidos', 'cond_pagto');
    
    if (!hasCondPagtoColumn) {
      console.log('Adicionando coluna cond_pagto à tabela pedidos...');
      await db.schema.table('pedidos', function(table) {
        table.string('cond_pagto').nullable();
      });
      console.log('Coluna cond_pagto adicionada com sucesso!');
    } else {
      console.log('A coluna cond_pagto já existe na tabela pedidos.');
    }

    console.log('Operação concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao adicionar colunas:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
addPagtoColumnsToPedidos(); 