const knex = require('./database/connection');
const { v4: uuidv4 } = require('uuid');

async function testInsertOrcamento() {
  try {
    console.log('Iniciando teste de inserção de orçamento...');
    
    // 1. Buscar um cliente para o teste
    const cliente = await knex('clientes')
      .select('codigo', 'nome', 'uf', 'cod_ibge')
      .limit(1)
      .first();
      
    if (!cliente) {
      console.log('Nenhum cliente encontrado para o teste');
      return;
    }
    
    console.log('Cliente selecionado:', cliente.codigo, cliente.nome, cliente.uf);
    
    // 2. Buscar um produto para o teste
    const produto = await knex('produtos')
      .select('codigo', 'descricao', 'preco_venda', 'class_fiscal', 'cod_regra_icms', 'cod_origem_prod')
      .limit(1)
      .first();
      
    if (!produto) {
      console.log('Nenhum produto encontrado para o teste');
      return;
    }
    
    console.log('Produto selecionado:', produto.codigo, produto.descricao);
    
    // 3. Preparar dados do orçamento
    const orcamentoCodigo = uuidv4();
    const now = new Date();
    const item = {
      codigo: uuidv4(),
      orcamento_codigo: orcamentoCodigo,
      produto_codigo: produto.codigo,
      quantidade: 2,
      valor_unitario: produto.preco_venda || 100,
      valor_total: (produto.preco_venda || 100) * 2,
      cod_status: 1,
      cod_empresa: 1
    };
    
    // 4. Inserir dados do orçamento
    console.log('Inserindo orçamento...');
    
    await knex.transaction(async trx => {
      // Criar orçamento
      await trx('orcamentos').insert({
        codigo: orcamentoCodigo,
        dt_orcamento: now,
        dt_inc: now,
        cod_empresa: 1,
        cod_status: 1,
        cod_cliente: cliente.codigo,
        cod_vendedor: 1,
        cod_forma_pagto: 1,
        cod_cond_pagto: 1,
        vl_produtos: item.valor_total,
        vl_impostos: 0,
        vl_total: item.valor_total,
        observacoes: 'Teste de inserção via script'
      });
      
      // Calcular impostos
      // Como não estamos importando o serviço de impostos para este teste simples,
      // vamos adicionar alguns valores de teste para os campos fiscais
      item.base_icms = item.valor_total;
      item.aliq_icms = 18;
      item.valor_icms = item.valor_total * 0.18;
      item.base_icms_st = 0;
      item.valor_icms_st = 0;
      item.aliq_ipi = 0;
      item.valor_ipi = 0;
      item.valor_fcp_st = 0;
      item.ncm = produto.class_fiscal || '72131000';
      item.cest = '';
      item.cod_origem_prod = produto.cod_origem_prod || '0';
      item.situacao_tributaria = '00';
      
      // Inserir item
      await trx('orcamentos_itens').insert(item);
      
      console.log('Orçamento inserido com sucesso!');
    });
    
    // 5. Verificar se o orçamento foi inserido corretamente
    const orcamento = await knex('orcamentos')
      .where('codigo', orcamentoCodigo)
      .first();
      
    console.log('Orçamento recuperado:', orcamento);
    
    // 6. Verificar se o item foi inserido corretamente
    const itens = await knex('orcamentos_itens')
      .where('orcamento_codigo', orcamentoCodigo)
      .select('*');
      
    console.log('Itens do orçamento:', itens.length);
    console.log('Primeiro item:', itens[0]);
    
    // 7. Verificar campos fiscais
    console.log('\nCampos fiscais do item:');
    console.log('--------------------');
    console.log('NCM:', itens[0].ncm);
    console.log('CEST:', itens[0].cest);
    console.log('Origem:', itens[0].cod_origem_prod);
    console.log('Situação tributária:', itens[0].situacao_tributaria);
    console.log('Base ICMS:', itens[0].base_icms);
    console.log('Valor ICMS:', itens[0].valor_icms);
    console.log('Alíquota ICMS:', itens[0].aliq_icms);
    console.log('Base ICMS-ST:', itens[0].base_icms_st);
    console.log('Valor ICMS-ST:', itens[0].valor_icms_st);
    console.log('Valor IPI:', itens[0].valor_ipi);
    console.log('Alíquota IPI:', itens[0].aliq_ipi);
    console.log('Valor FCP-ST:', itens[0].valor_fcp_st);
    
    return {
      orcamento,
      itens
    };
  } catch (error) {
    console.error('Erro no teste:', error);
  }
}

testInsertOrcamento()
  .then(result => {
    if (result) {
      console.log('\nTeste concluído com sucesso!');
    } else {
      console.log('\nFalha no teste');
    }
  })
  .catch(err => console.error('Erro:', err))
  .finally(() => process.exit(0)); 