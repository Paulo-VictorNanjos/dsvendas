require('dotenv').config();
const { erpConnection } = require('./database/connection');
const logger = require('./utils/logger');

async function verificarBancoDadosERP() {
  try {
    console.log('Iniciando verificação do banco de dados ERP...');
    console.log('Configurações de conexão:', {
      host: process.env.ERP_DB_HOST || process.env.DB_HOST || 'localhost',
      user: process.env.ERP_DB_USER || process.env.DB_USER || 'postgres',
      database: process.env.ERP_DB_DATABASE || 'erp',
      port: parseInt(process.env.ERP_DB_PORT || process.env.DB_PORT || '5434')
    });

    // Verificar se conseguimos conectar ao banco ERP
    try {
      await erpConnection.raw('SELECT 1+1 as result');
      console.log('Conexão com o banco ERP estabelecida com sucesso!');
    } catch (err) {
      console.error('Erro ao conectar ao banco ERP:', err.message);
      return;
    }

    // Testar consulta direta para o produto 237/D
    try {
      console.log('\n--- TESTE DE CONSULTA DIRETA PARA PRODUTO 237/D ---');
      const produtoTeste = await erpConnection('posicao_estoque')
        .where('cod_produto', '237/D')
        .first();
      
      if (produtoTeste) {
        console.log('Produto encontrado na view posicao_estoque:');
        console.log(produtoTeste);
        
        // Verificar como estaria o mapeamento para o frontend
        const resultadoMapeado = {
          cod_produto: produtoTeste.cod_produto,
          qtd_disponivel: parseFloat(produtoTeste.qtde_kardex || 0),
          qtd_total: parseFloat(produtoTeste.qtde_kardex || 0),
          qtd_reservada: 0,
          cod_local_estoque: produtoTeste.cod_local_estoque,
          cod_empresa: produtoTeste.cod_empresa,
          success: true
        };
        
        console.log('Mapeamento para o frontend:');
        console.log(resultadoMapeado);
      } else {
        console.log('Produto 237/D não encontrado na view posicao_estoque');
        
        // Tentar buscar com variações do código
        console.log('Tentando variações do código...');
        const variacao1 = await erpConnection('posicao_estoque')
          .whereRaw("cod_produto LIKE '%237%'")
          .limit(5);
          
        if (variacao1 && variacao1.length > 0) {
          console.log('Produtos encontrados com código similar:');
          console.log(variacao1);
        } else {
          console.log('Nenhum produto similar encontrado');
        }
      }
    } catch (err) {
      console.error('Erro ao consultar produto específico:', err.message);
    }

    // Verificar se a view posicao_estoque existe
    const viewExists = await erpConnection.raw(`
      SELECT EXISTS (
        SELECT 1 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'posicao_estoque'
      )
    `);
    
    const existeView = viewExists.rows && viewExists.rows[0] && viewExists.rows[0].exists;
    console.log(`\nA view posicao_estoque ${existeView ? 'existe' : 'NÃO existe'} no banco de dados ERP.`);
    
    // Se a view existir, verificar sua estrutura
    if (existeView) {
      const colunas = await erpConnection.raw(`
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'posicao_estoque'
        ORDER BY ordinal_position
      `);
      
      console.log('Estrutura da view posicao_estoque:');
      if (colunas.rows && colunas.rows.length > 0) {
        colunas.rows.forEach(col => {
          console.log(`- ${col.column_name} (${col.data_type})`);
        });
      } else {
        console.log('Nenhuma coluna encontrada na view.');
      }
      
      // Verificar se há dados na view
      try {
        const amostra = await erpConnection('posicao_estoque').select('*').limit(5);
        if (amostra && amostra.length > 0) {
          console.log('\nAmostra de dados da view posicao_estoque (5 primeiros registros):');
          amostra.forEach(item => console.log(item));
          
          // Contar total de registros
          const totalCount = await erpConnection('posicao_estoque').count('* as total').first();
          console.log(`\nTotal de registros na view: ${totalCount.total}`);
        } else {
          console.log('A view posicao_estoque não contém dados.');
        }
      } catch (err) {
        console.error('Erro ao consultar dados da view:', err.message);
      }
    }
    
    // Testar a API usando o cliente http
    console.log('\n--- TESTE DA API DE ESTOQUE ---');
    const http = require('http');
    
    const options = {
      hostname: 'localhost',
      port: 3001,
      path: '/api/produtos/estoque/237%2FD',
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    const req = http.request(options, (res) => {
      console.log(`Status da API: ${res.statusCode}`);
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          console.log('Resposta da API:');
          console.log(parsed);
          process.exit(0);
        } catch (e) {
          console.error('Erro ao parsear resposta:', e.message);
          console.log('Dados brutos:', data);
          process.exit(1);
        }
      });
    });
    
    req.on('error', (e) => {
      console.error(`Erro na requisição: ${e.message}`);
      process.exit(1);
    });
    
    req.end();
    
  } catch (error) {
    console.error('Erro na verificação do banco de dados ERP:', error);
    process.exit(1);
  }
}

verificarBancoDadosERP(); 