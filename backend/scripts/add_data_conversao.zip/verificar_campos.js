/**
 * Script para verificar os campos da tabela orcamentos_itens
 */

const knex = require('knex');

// Configuração do banco de dados (ajuste conforme seu ambiente)
const dbConfig = {
  client: 'pg',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'dsvendas',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres'
  }
};

async function verificarCampos() {
  console.log('Verificando campos da tabela orcamentos_itens...');
  
  const db = knex(dbConfig);
  
  try {
    // Verificar se a tabela existe
    const tabelaExiste = await db.schema.hasTable('orcamentos_itens');
    
    if (!tabelaExiste) {
      console.error('Erro: A tabela orcamentos_itens não existe no banco de dados!');
      process.exit(1);
    }
    
    console.log('Tabela orcamentos_itens encontrada, verificando colunas...');
    
    // Obter informações das colunas
    const colunas = await db.raw(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_name = 'orcamentos_itens'
      ORDER BY ordinal_position
    `);
    
    console.log('\nColunas existentes na tabela orcamentos_itens:');
    console.log('----------------------------------------------');
    
    // Exibir colunas de forma organizada
    colunas.rows.forEach(coluna => {
      console.log(`${coluna.column_name.padEnd(25)} | ${coluna.data_type.padEnd(15)} | ${coluna.is_nullable}`);
    });
    
    console.log('\nVerificando campos específicos para impostos:');
    console.log('--------------------------------------------');
    
    // Verificar campos específicos
    const camposNecessarios = [
      'aliq_icms',
      'valor_icms',
      'aliq_ipi',
      'valor_ipi',
      'valor_icms_st',
      'icms_st'
    ];
    
    for (const campo of camposNecessarios) {
      const existe = await db.schema.hasColumn('orcamentos_itens', campo);
      console.log(`${campo.padEnd(25)} | ${existe ? 'Existe' : 'NÃO EXISTE - PRECISA SER CRIADO'}`);
    }
    
  } catch (error) {
    console.error('Erro ao verificar campos:', error.message);
    console.error(error.stack);
  } finally {
    // Fechar conexão com o banco
    await db.destroy();
  }
}

// Executar verificação
verificarCampos()
  .then(() => {
    console.log('\nVerificação concluída');
    process.exit(0);
  })
  .catch(err => {
    console.error('Erro fatal:', err);
    process.exit(1);
  }); 