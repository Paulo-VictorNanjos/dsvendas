const knex = require('./database/connection');

async function modifyTable() {
  try {
    console.log('Modificando estrutura da tabela regras_icms...');
    
    // Primeiro precisamos remover a restrição de chave primária existente
    console.log('Removendo chave primária atual...');
    await knex.raw('ALTER TABLE regras_icms DROP CONSTRAINT regras_icms_pkey');
    
    // Agora adicionamos uma nova chave primária composta
    console.log('Adicionando chave primária composta (codigo, uf)...');
    await knex.raw('ALTER TABLE regras_icms ADD PRIMARY KEY (codigo, uf)');
    
    console.log('Tabela modificada com sucesso!');
    
    // Verificar as novas chaves primárias
    console.log('\nVerificando novas chaves primárias:');
    const chavesPrimarias = await knex
      .select(
        'tc.constraint_name', 
        'tc.table_name', 
        'kcu.column_name', 
        'tc.constraint_type'
      )
      .from('information_schema.table_constraints AS tc')
      .join(
        'information_schema.key_column_usage AS kcu',
        function() {
          this.on('tc.constraint_name', '=', 'kcu.constraint_name')
              .andOn('tc.table_schema', '=', 'kcu.table_schema');
        }
      )
      .where('tc.table_name', 'regras_icms')
      .andWhere('tc.constraint_type', 'PRIMARY KEY');
    
    console.table(chavesPrimarias);
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao modificar tabela:', error);
    process.exit(1);
  }
}

modifyTable(); 