/**
 * Script para adicionar os campos necessários à tabela orcamentos_itens
 */

const knex = require('knex');

// Configuração do banco de dados (ajuste conforme seu ambiente)
const dbConfig = {
  client: 'pg',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5434,
    database: process.env.DB_NAME || 'dsvendas',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres'
  }
};

async function adicionarCampos() {
  console.log('Adicionando campos necessários à tabela orcamentos_itens...');
  
  const db = knex(dbConfig);
  
  try {
    // Verificar se a tabela existe
    const tabelaExiste = await db.schema.hasTable('orcamentos_itens');
    
    if (!tabelaExiste) {
      console.error('Erro: A tabela orcamentos_itens não existe no banco de dados!');
      process.exit(1);
    }
    
    console.log('Tabela orcamentos_itens encontrada, adicionando campos...');

    // Campo aliq_icms
    const temAliqIcms = await db.schema.hasColumn('orcamentos_itens', 'aliq_icms');
    if (!temAliqIcms) {
      console.log('Adicionando campo aliq_icms...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.decimal('aliq_icms', 15, 4).defaultTo(0);
      });
      console.log('Campo aliq_icms adicionado com sucesso.');
    } else {
      console.log('Campo aliq_icms já existe.');
    }

    // Campo valor_icms
    const temValorIcms = await db.schema.hasColumn('orcamentos_itens', 'valor_icms');
    if (!temValorIcms) {
      console.log('Adicionando campo valor_icms...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.decimal('valor_icms', 15, 4).defaultTo(0);
      });
      console.log('Campo valor_icms adicionado com sucesso.');
    } else {
      console.log('Campo valor_icms já existe.');
    }

    // Campo aliq_ipi
    const temAliqIpi = await db.schema.hasColumn('orcamentos_itens', 'aliq_ipi');
    if (!temAliqIpi) {
      console.log('Adicionando campo aliq_ipi...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.decimal('aliq_ipi', 15, 4).defaultTo(0);
      });
      console.log('Campo aliq_ipi adicionado com sucesso.');
    } else {
      console.log('Campo aliq_ipi já existe.');
    }

    // Campo valor_ipi
    const temValorIpi = await db.schema.hasColumn('orcamentos_itens', 'valor_ipi');
    if (!temValorIpi) {
      console.log('Adicionando campo valor_ipi...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.decimal('valor_ipi', 15, 4).defaultTo(0);
      });
      console.log('Campo valor_ipi adicionado com sucesso.');
    } else {
      console.log('Campo valor_ipi já existe.');
    }

    // Campo valor_icms_st
    const temValorIcmsSt = await db.schema.hasColumn('orcamentos_itens', 'valor_icms_st');
    if (!temValorIcmsSt) {
      console.log('Adicionando campo valor_icms_st...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.decimal('valor_icms_st', 15, 4).defaultTo(0);
      });
      console.log('Campo valor_icms_st adicionado com sucesso.');
    } else {
      console.log('Campo valor_icms_st já existe.');
    }

    // Campo icms_st
    const temIcmsSt = await db.schema.hasColumn('orcamentos_itens', 'icms_st');
    if (!temIcmsSt) {
      console.log('Adicionando campo icms_st...');
      await db.schema.alterTable('orcamentos_itens', table => {
        table.string('icms_st', 1).defaultTo('N');
      });
      console.log('Campo icms_st adicionado com sucesso.');
    } else {
      console.log('Campo icms_st já existe.');
    }

    console.log('\nTodos os campos foram verificados e adicionados se necessário.');
    
  } catch (error) {
    console.error('Erro ao adicionar campos:', error.message);
    console.error(error.stack);
  } finally {
    // Fechar conexão com o banco
    await db.destroy();
  }
}

// Executar adição de campos
adicionarCampos()
  .then(() => {
    console.log('\nOperação concluída com sucesso.');
    process.exit(0);
  })
  .catch(err => {
    console.error('Erro fatal:', err);
    process.exit(1);
  }); 