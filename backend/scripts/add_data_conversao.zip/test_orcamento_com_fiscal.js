const knex = require('./database/connection');
const { v4: uuidv4 } = require('uuid');
const productFiscalRulesService = require('./services/productFiscalRulesService');

async function testInsertOrcamentoComFiscal() {
  try {
    console.log('Iniciando teste de inserção de orçamento com cálculo fiscal...');
    
    // 1. Buscar um cliente para o teste
    const cliente = await knex('clientes')
      .select('codigo', 'nome', 'uf', 'cod_ibge')
      .limit(1)
      .first();
      
    if (!cliente) {
      console.log('Nenhum cliente encontrado para o teste');
      return;
    }
    
    console.log('Cliente selecionado:', cliente.codigo, cliente.nome, cliente.uf);
    
    // 2. Buscar um produto para o teste
    const produto = await knex('produtos')
      .select('*')
      .limit(1)
      .first();
      
    if (!produto) {
      console.log('Nenhum produto encontrado para o teste');
      return;
    }
    
    console.log('Produto selecionado:', produto.codigo, produto.descricao);
    console.log('Dados fiscais do produto:');
    console.log('- NCM/Class. Fiscal:', produto.class_fiscal);
    console.log('- Regra ICMS:', produto.cod_regra_icms);
    console.log('- Origem:', produto.cod_origem_prod);
    
    // 3. Calcular impostos usando o serviço
    console.log('\nCalculando impostos...');
    const quantidade = 2;
    const valorUnitario = 50; // Valor fixo para o teste
    
    const impostos = await productFiscalRulesService.calculateIcms(
      produto,
      quantidade,
      valorUnitario,
      {
        uf: cliente.uf,
        cod_ibge: cliente.cod_ibge
      }
    );
    
    console.log('Resultado do cálculo fiscal:');
    console.log(impostos);
    
    // 4. Preparar dados do orçamento
    const orcamentoCodigo = uuidv4();
    const now = new Date();
    const valorImpostos = impostos.valorIpi + impostos.valorIcmsSt + impostos.valorFcp;
    
    // 5. Preparar item do orçamento
    const item = {
      codigo: uuidv4(),
      orcamento_codigo: orcamentoCodigo,
      produto_codigo: produto.codigo,
      quantidade: quantidade,
      valor_unitario: valorUnitario,
      valor_total: valorUnitario * quantidade,
      cod_status: 1,
      cod_empresa: 1,
      base_icms: impostos.baseIcms,
      aliq_icms: impostos.aliqIcms,
      valor_icms: impostos.valorIcms,
      base_icms_st: impostos.aplicaIcmsSt ? impostos.baseIcmsSt : 0,
      valor_icms_st: impostos.valorIcmsSt,
      aliq_ipi: impostos.aliqIpi,
      valor_ipi: impostos.valorIpi,
      valor_fcp_st: impostos.valorFcp,
      ncm: impostos.ncm,
      cest: impostos.cest,
      cod_origem_prod: impostos.codOrigemProd,
      situacao_tributaria: impostos.stIcms
    };
    
    // 6. Inserir dados do orçamento
    console.log('\nInserindo orçamento com cálculo fiscal...');
    
    await knex.transaction(async trx => {
      // Criar orçamento
      await trx('orcamentos').insert({
        codigo: orcamentoCodigo,
        dt_orcamento: now,
        dt_inc: now,
        cod_empresa: 1,
        cod_status: 1,
        cod_cliente: cliente.codigo,
        cod_vendedor: 1,
        cod_forma_pagto: 1,
        cod_cond_pagto: 1,
        vl_produtos: item.valor_total,
        vl_impostos: valorImpostos,
        vl_total: item.valor_total + valorImpostos,
        observacoes: 'Teste de cálculo fiscal via script'
      });
      
      // Inserir item
      await trx('orcamentos_itens').insert(item);
      
      console.log('Orçamento inserido com sucesso!');
    });
    
    // 7. Verificar se o orçamento foi inserido corretamente
    const orcamento = await knex('orcamentos')
      .where('codigo', orcamentoCodigo)
      .first();
      
    console.log('\nOrçamento recuperado:');
    console.log('Código:', orcamento.codigo);
    console.log('Valor produtos:', orcamento.vl_produtos);
    console.log('Valor impostos:', orcamento.vl_impostos);
    console.log('Valor total:', orcamento.vl_total);
    
    // 8. Verificar se o item foi inserido corretamente com todos os campos fiscais
    const itens = await knex('orcamentos_itens')
      .where('orcamento_codigo', orcamentoCodigo)
      .select('*');
      
    console.log('\nItens do orçamento:', itens.length);
    
    // 9. Verificar campos fiscais
    console.log('\nCampos fiscais do item:');
    console.log('--------------------');
    console.log('NCM:', itens[0].ncm);
    console.log('CEST:', itens[0].cest);
    console.log('Origem:', itens[0].cod_origem_prod);
    console.log('Situação tributária:', itens[0].situacao_tributaria);
    console.log('Base ICMS:', itens[0].base_icms);
    console.log('Valor ICMS:', itens[0].valor_icms);
    console.log('Alíquota ICMS:', itens[0].aliq_icms);
    console.log('Base ICMS-ST:', itens[0].base_icms_st);
    console.log('Valor ICMS-ST:', itens[0].valor_icms_st);
    console.log('Valor IPI:', itens[0].valor_ipi);
    console.log('Alíquota IPI:', itens[0].aliq_ipi);
    console.log('Valor FCP-ST:', itens[0].valor_fcp_st);
    
    return {
      orcamento,
      itens,
      impostos
    };
  } catch (error) {
    console.error('Erro no teste:', error);
  }
}

testInsertOrcamentoComFiscal()
  .then(result => {
    if (result) {
      console.log('\nTeste concluído com sucesso!');
    } else {
      console.log('\nFalha no teste');
    }
  })
  .catch(err => console.error('Erro:', err))
  .finally(() => process.exit(0)); 