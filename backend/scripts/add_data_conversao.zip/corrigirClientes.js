const knex = require('./database/connection');
const logger = require('./utils/logger');

async function corrigirClientes() {
  try {
    console.log('Iniciando correção de clientes com campos nulos...');
    
    // 1. Primeiro, verificar quantos clientes têm campos nulos
    const clientesNulos = await knex('clientes')
      .whereNull('uf')
      .orWhereNull('contribuinte')
      .orWhereNull('insc_est')
      .count('* as total')
      .first();
      
    console.log(`Encontrados ${clientesNulos.total} clientes com campos nulos.`);
    
    if (clientesNulos.total === 0) {
      console.log('Nenhum cliente para corrigir!');
      process.exit(0);
      return;
    }
    
    // 2. Atualizar clientes com UF nula
    console.log('Corrigindo clientes com UF nula...');
    const clientesUfNula = await knex('clientes')
      .whereNull('uf')
      .orWhere('uf', '')
      .update({
        uf: 'SP' // UF padrão é SP
      });
    
    console.log(`${clientesUfNula} clientes tiveram a UF corrigida para SP.`);
    
    // 3. Atualizar clientes com contribuinte nulo
    console.log('Corrigindo clientes com contribuinte nulo...');
    const clientesContribuinteNulo = await knex('clientes')
      .whereNull('contribuinte')
      .update({
        contribuinte: 0 // Padrão: não contribuinte
      });
    
    console.log(`${clientesContribuinteNulo} clientes tiveram o campo contribuinte corrigido para 0.`);
    
    // 4. Atualizar clientes com inscrição estadual nula
    console.log('Corrigindo clientes com inscrição estadual nula...');
    const clientesInscEstNula = await knex('clientes')
      .whereNull('insc_est')
      .update({
        insc_est: 'ISENTO' // Padrão: isento
      });
    
    console.log(`${clientesInscEstNula} clientes tiveram a inscrição estadual corrigida para ISENTO.`);
    
    // 5. Verificar se ainda existem clientes com campos nulos
    const clientesNulosRestantes = await knex('clientes')
      .whereNull('uf')
      .orWhereNull('contribuinte')
      .orWhereNull('insc_est')
      .count('* as total')
      .first();
      
    if (clientesNulosRestantes.total > 0) {
      console.log(`ATENÇÃO: Ainda existem ${clientesNulosRestantes.total} clientes com campos nulos.`);
      
      // Fazer uma correção mais agressiva
      console.log('Executando correção final...');
      
      // Buscar todos os clientes e corrigir um por um
      const clientesParaCorrigir = await knex('clientes')
        .whereNull('uf')
        .orWhereNull('contribuinte')
        .orWhereNull('insc_est')
        .select('codigo');
      
      for (const cliente of clientesParaCorrigir) {
        await knex('clientes')
          .where('codigo', cliente.codigo)
          .update({
            uf: 'SP',
            contribuinte: 0,
            insc_est: 'ISENTO'
          });
      }
      
      console.log(`Correção finalizada para ${clientesParaCorrigir.length} clientes.`);
    } else {
      console.log('Todos os clientes estão com os campos corrigidos!');
    }
    
    console.log('Correção de clientes concluída com sucesso!');
    process.exit(0);
  } catch (err) {
    console.error('Erro ao corrigir clientes:', err);
    process.exit(1);
  }
}

// Executar a função principal
corrigirClientes(); 