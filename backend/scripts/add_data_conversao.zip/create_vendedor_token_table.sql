-- Script para criar a tabela de tokens de vendedor
CREATE TABLE IF NOT EXISTS vendedor_token (
    id UUID PRIMARY KEY,
    vendedor_codigo VARCHAR(20) REFERENCES vendedores(codigo) ON DELETE CASCADE,
    token VARCHAR(64) NOT NULL UNIQUE,
    ativo BOOLEAN DEFAULT TRUE,
    dt_expiracao TIMESTAMP,
    dt_inc TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_uso TIMESTAMP,
    gerado_por VARCHAR(100),
    descricao VARCHAR(255)
);

CREATE INDEX IF NOT EXISTS idx_vendedor_token_token ON vendedor_token(token);
CREATE INDEX IF NOT EXISTS idx_vendedor_token_vendedor ON vendedor_token(vendedor_codigo);

-- Comentarios nas colunas
COMMENT ON TABLE vendedor_token IS 'Tokens para vinculacao de usuarios a vendedores';
COMMENT ON COLUMN vendedor_token.id IS 'ID unico do token (UUID)';
COMMENT ON COLUMN vendedor_token.vendedor_codigo IS 'Codigo do vendedor associado ao token';
COMMENT ON COLUMN vendedor_token.token IS 'Token de acesso unico';
COMMENT ON COLUMN vendedor_token.ativo IS 'Indica se o token esta ativo';
COMMENT ON COLUMN vendedor_token.dt_expiracao IS 'Data de expiracao do token';
COMMENT ON COLUMN vendedor_token.dt_inc IS 'Data de inclusao do token';
COMMENT ON COLUMN vendedor_token.dt_uso IS 'Data em que o token foi utilizado';
COMMENT ON COLUMN vendedor_token.gerado_por IS 'Nome do usuario que gerou o token';
COMMENT ON COLUMN vendedor_token.descricao IS 'Descricao ou proposito do token';

-- Inserir um token de exemplo para testes (opcional)
-- INSERT INTO vendedor_token (id, vendedor_codigo, token, ativo, dt_expiracao, gerado_por, descricao)
-- VALUES (
--     gen_random_uuid(),
--     '1', -- Substitua pelo codigo de um vendedor existente
--     'ABC123DEF456',
--     TRUE,
--     NOW() + INTERVAL '30 days',
--     'Admin',
--     'Token de teste para vinculacao inicial'
-- ); 