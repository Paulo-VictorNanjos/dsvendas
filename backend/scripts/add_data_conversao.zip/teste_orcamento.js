/**
 * Script para testar a criação de orçamento com cálculo fiscal
 */
const db = require('./database/connection');
const orcamentoController = require('./controllers/orcamentoController');

// Simular req e res
const req = {
  body: {
    cod_cliente: '43979',
    cod_vendedor: '1',
    form_pagto: '1',
    cond_pagto: '1',
    itens: [
      {
        produto_codigo: '557.000-018',
        quantidade: 2,
        valor_unitario: 100.00
      }
    ]
  }
};

const res = {
  status: function(statusCode) {
    console.log('Status:', statusCode);
    return this;
  },
  json: function(data) {
    console.log('Resposta:', JSON.stringify(data, null, 2));
    return this;
  }
};

// Executar criação de orçamento
async function testar() {
  try {
    console.log('Iniciando teste de criação de orçamento...');
    await orcamentoController.create(req, res);
    console.log('Teste concluído.');
  } catch (error) {
    console.error('Erro no teste:', error);
  } finally {
    // Fechar conexão
    await db.destroy();
  }
}

// Executar o teste
testar(); 