const knex = require('./database/connection');
const logger = require('./utils/logger');

/**
 * Função para verificar se um produto tem substituição tributária em uma UF específica
 * @param {string} codigoProduto - Código do produto
 * @param {string} uf - UF de destino (ex: SP, RJ, MG)
 * @param {number} tipoCliente - Tipo de cliente (1 = contribuinte, 0 = não contribuinte)
 */
async function verificarSubstituicaoTributaria(codigoProduto, uf, tipoCliente = 1) {
  try {
    console.log(`\n============ TESTE DE ICMS ST ============`);
    console.log(`Produto: ${codigoProduto}`);
    console.log(`UF: ${uf}`);
    console.log(`Tipo Cliente: ${tipoCliente} (${tipoCliente === 1 ? 'Contribuinte' : 'Não Contribuinte'})`);
    console.log(`========================================\n`);
    
    // 1. Buscar o produto para confirmar que existe
    const produto = await knex('produtos')
      .where('codigo', codigoProduto)
      .first();
    
    if (!produto) {
      console.log(`ERRO: Produto ${codigoProduto} não encontrado!`);
      return;
    }
    
    console.log(`Produto encontrado: ${produto.descricao}`);
    console.log(`Código: ${produto.codigo}`);
    console.log(`Regra ICMS configurada no produto: ${produto.cod_regra_icms || 'Não definida'}`);
    
    // 2. Verificar se o produto tem regra fiscal específica (tabela regras_fiscais_produtos)
    console.log(`\n[1] Buscando regra fiscal específica em regras_fiscais_produtos...`);
    const regraFiscalProduto = await knex('regras_fiscais_produtos')
      .where({
        'cod_produto': codigoProduto,
        'ativo': true
      })
      .first();
    
    let codRegraIcms;
    if (regraFiscalProduto) {
      console.log(`✓ Regra fiscal específica encontrada!`);
      console.log(`Regra ICMS da tabela regras_fiscais_produtos: ${regraFiscalProduto.cod_regra_icms}`);
      codRegraIcms = regraFiscalProduto.cod_regra_icms;
    } else {
      console.log(`✗ Regra fiscal específica NÃO encontrada!`);
      console.log(`Usando regra ICMS do cadastro do produto: ${produto.cod_regra_icms}`);
      codRegraIcms = produto.cod_regra_icms;
    }
    
    if (!codRegraIcms) {
      console.log(`ERRO: Não foi possível determinar uma regra ICMS para o produto ${codigoProduto}!`);
      return;
    }
    
    // 3. Consultar a tabela regras_icms_itens para verificar se tem ST
    console.log(`\n[2] Consultando tabela regras_icms_itens para verificar ST...`);
    console.log(`Código de regra ICMS a ser utilizado: ${codRegraIcms}`);
    console.log(`UF de destino: ${uf}`);
    console.log(`Tipo de cliente: ${tipoCliente}`);
    
    // Primeiro tenta buscar regra para empresa 1
    const regraIcmsItem = await knex('regras_icms_itens')
      .where({
        'cod_regra_icms': codRegraIcms,
        'uf': uf,
        'cod_empresa': 1
      })
      .first();
    
    if (!regraIcmsItem) {
      console.log(`✗ Nenhuma regra encontrada para cod_regra_icms=${codRegraIcms}, uf=${uf} e cod_empresa=1`);
      
      // Tentar buscar sem filtro de empresa
      const regraIcmsItemSemEmpresa = await knex('regras_icms_itens')
        .where({
          'cod_regra_icms': codRegraIcms,
          'uf': uf
        })
        .first();
      
      if (!regraIcmsItemSemEmpresa) {
        console.log(`✗ Nenhuma regra encontrada para cod_regra_icms=${codRegraIcms} e uf=${uf}`);
        
        // Tentar buscar com UF 'GERAL'
        const regraIcmsItemGeral = await knex('regras_icms_itens')
          .where({
            'cod_regra_icms': codRegraIcms,
            'uf': 'GERAL'
          })
          .first();
        
        if (!regraIcmsItemGeral) {
          console.log(`✗ Nenhuma regra encontrada para cod_regra_icms=${codRegraIcms} e uf=GERAL`);
          console.log(`\nRESULTADO: Produto NÃO tem ST para a UF ${uf}`);
          return;
        } else {
          console.log(`✓ Regra encontrada para cod_regra_icms=${codRegraIcms} e uf=GERAL`);
          console.log(`Dados da regra:`, regraIcmsItemGeral);
          
          // Verificar se tem ST
          const temST = regraIcmsItemGeral.icms_st === 'S';
          console.log(`\nRESULTADO: Produto ${temST ? 'TEM' : 'NÃO TEM'} ST para a UF ${uf} (baseado na regra GERAL)`);
          
          // Mostrar mais detalhes sobre a regra
          await mostrarDetalhesRegra(regraIcmsItemGeral, tipoCliente);
          return;
        }
      } else {
        console.log(`✓ Regra encontrada para cod_regra_icms=${codRegraIcms} e uf=${uf} (sem filtro de empresa)`);
        console.log(`Dados da regra:`, regraIcmsItemSemEmpresa);
        
        // Verificar se tem ST
        const temST = regraIcmsItemSemEmpresa.icms_st === 'S';
        console.log(`\nRESULTADO: Produto ${temST ? 'TEM' : 'NÃO TEM'} ST para a UF ${uf}`);
        
        // Mostrar mais detalhes sobre a regra
        await mostrarDetalhesRegra(regraIcmsItemSemEmpresa, tipoCliente);
        return;
      }
    }
    
    console.log(`✓ Regra encontrada para cod_regra_icms=${codRegraIcms}, uf=${uf} e cod_empresa=1`);
    console.log(`Dados da regra:`, regraIcmsItem);
    
    // Verificar se tem ST
    const temST = regraIcmsItem.icms_st === 'S';
    console.log(`\nRESULTADO: Produto ${temST ? 'TEM' : 'NÃO TEM'} ST para a UF ${uf}`);
    
    // Mostrar mais detalhes sobre a regra
    await mostrarDetalhesRegra(regraIcmsItem, tipoCliente);
    
  } catch (err) {
    console.error('Erro ao verificar substituição tributária:', err);
  } finally {
    process.exit(0);
  }
}

/**
 * Mostra detalhes adicionais sobre a regra ICMS
 */
async function mostrarDetalhesRegra(regra, tipoCliente) {
  try {
    console.log(`\n===== DETALHES DA REGRA ICMS =====`);
    
    // Determinar quais campos usar com base no tipo de cliente
    if (tipoCliente === 1) { // Contribuinte
      console.log(`Tipo de Cliente: Contribuinte`);
      console.log(`Situação Tributária: ${regra.st_icms_contr || 'Não definida'}`);
      console.log(`Alíquota ICMS: ${regra.aliq_icms_contr || 0}%`);
      console.log(`Redução Base: ${regra.red_icms_contr || 0}%`);
      console.log(`Convênio: ${regra.cod_convenio_contr || 'Não definido'}`);
    } else { // Não Contribuinte
      console.log(`Tipo de Cliente: Não Contribuinte`);
      console.log(`Situação Tributária: ${regra.st_icms || 'Não definida'}`);
      console.log(`Alíquota ICMS: ${regra.aliq_icms || 0}%`);
      console.log(`Redução Base: ${regra.red_icms || 0}%`);
      console.log(`Convênio: ${regra.cod_convenio || 'Não definido'}`);
    }
    
    console.log(`Substituição Tributária: ${regra.icms_st === 'S' ? 'SIM' : 'NÃO'}`);
    console.log(`Alíquota Interna do Estado: ${regra.aliq_interna || 0}%`);
    
    // Verificar se existe tributação específica para o produto
    if (regra.cod_regra_icms) {
      const classFiscal = await knex('class_fiscal_tributacoes')
        .where({
          'cod_class_fiscal': regra.cod_regra_icms,
          'uf': regra.uf
        })
        .first();
      
      if (classFiscal) {
        console.log(`\n===== TRIBUTAÇÃO ESPECÍFICA =====`);
        console.log(`CEST: ${classFiscal.cest || 'Não definido'}`);
        console.log(`IVA: ${classFiscal.iva || 0}%`);
        console.log(`Alíquota Interna: ${classFiscal.aliq_interna || 0}%`);
      }
    }
    
    console.log(`================================`);
  } catch (err) {
    console.error('Erro ao mostrar detalhes da regra:', err);
  }
}

// Verificar argumentos da linha de comando
const args = process.argv.slice(2);
if (args.length < 2) {
  console.log('Uso: node testarIcmsST.js <codigoProduto> <uf> [tipoCliente]');
  console.log('Exemplo: node testarIcmsST.js 1001 SP 1');
  console.log('tipoCliente: 1 = Contribuinte, 0 = Não Contribuinte (padrão: 1)');
  process.exit(1);
}

const codigoProduto = args[0];
const uf = args[1].toUpperCase();
const tipoCliente = args.length > 2 ? parseInt(args[2]) : 1;

// Executar a verificação
verificarSubstituicaoTributaria(codigoProduto, uf, tipoCliente); 