const knex = require('./database/connection');

async function repairSequence() {
  try {
    console.log('Tentando corrigir a sequência da tabela regras_icms...');
    
    // Verificar se há dados na tabela
    console.log('Verificando registros existentes...');
    const regras = await knex('regras_icms').select('*');
    console.log(`Registros encontrados: ${regras.length}`);
    
    if (regras.length > 0) {
      console.log('Tabela não está vazia, não vamos limpar.');
    } else {
      // Se não há registros, mas ainda assim recebemos erro de chave duplicada,
      // isso pode ser um problema com a sequência ou com registros fantasmas
      console.log('Tabela parece vazia, tentando remover restrições e limpar completamente...');
      
      // Tentar limpar a tabela completamente
      await knex.raw('TRUNCATE TABLE regras_icms RESTART IDENTITY');
      console.log('Tabela truncada com sucesso!');
    }
    
    // Inserir uma regra de teste
    console.log('Inserindo regra de teste...');
    const regraInsert = await knex('regras_icms').insert({
      codigo: 1,
      uf: 'SP',
      st_icms: '00',
      aliq_icms: 18.00,
      red_icms: 0.00,
      st_icms_contr: '10',
      aliq_icms_contr: 18.00,
      red_icms_contr: 0.00,
      icms_st: 'S',
      aliq_interna: 18.00,
      created_at: new Date(),
      updated_at: new Date()
    });
    
    console.log('Regra inserida com sucesso!');
    
    // Verificar se a regra foi inserida
    const regrasAposInsercao = await knex('regras_icms').select('*');
    console.log(`Registros após inserção: ${regrasAposInsercao.length}`);
    console.log(JSON.stringify(regrasAposInsercao, null, 2));
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao reparar sequência:', error);
    process.exit(1);
  }
}

repairSequence(); 