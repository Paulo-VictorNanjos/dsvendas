const knex = require('./database/connection');

async function checkProductsTable() {
  try {
    console.log('Verificando estrutura da tabela produtos...');

    // Verificar todos os campos da tabela produtos
    const columns = await knex.raw(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'produtos' 
      ORDER BY column_name
    `);

    console.log('Campos encontrados na tabela produtos:');
    columns.rows.forEach(col => {
      console.log(`- ${col.column_name} (${col.data_type})`);
    });

    // Verificar se existe o campo preco na tabela
    const hasPreco = columns.rows.some(col => col.column_name === 'preco');
    if (hasPreco) {
      console.log('\nAtençăo: O campo "preco" existe na tabela produtos!');
    } else {
      console.log('\nCampo "preco" năo encontrado na tabela produtos.');
    }

    // Verificar se existe o campo preco_venda na tabela
    const hasPrecoVenda = columns.rows.some(col => col.column_name === 'preco_venda');
    if (hasPrecoVenda) {
      console.log('Campo "preco_venda" encontrado na tabela produtos.');
    } else {
      console.log('Atençăo: Campo "preco_venda" năo encontrado na tabela produtos!');
    }

    // Buscar amostra de produtos para verificar valores
    const sampleProducts = await knex('produtos').select('*').limit(3);
    console.log('\nAmostra de produtos:');
    console.log(JSON.stringify(sampleProducts, null, 2));

  } catch (error) {
    console.error('Erro ao verificar a tabela produtos:', error);
  } finally {
    await knex.destroy();
  }
}

checkProductsTable(); 