const syncService = require('./services/syncService');

async function testSyncClientes() {
  try {
    console.log('Iniciando sincronização de clientes...');
    const result = await syncService.syncClientes();
    console.log('Sincronização concluída:', result);
    process.exit(0);
  } catch (err) {
    console.error('Erro na sincronização:', err);
    process.exit(1);
  }
}

testSyncClientes(); 