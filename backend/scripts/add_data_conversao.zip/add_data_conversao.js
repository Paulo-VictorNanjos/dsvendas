// Script para adicionar coluna data_conversao na tabela orcamentos
const knex = require('knex');
const config = require('../knexfile').development;
const db = knex(config);

async function addDataConversaoColumn() {
  try {
    // Verificar se a coluna já existe
    const hasColumn = await db.schema.hasColumn('orcamentos', 'data_conversao');
    
    if (!hasColumn) {
      console.log('Adicionando coluna data_conversao à tabela orcamentos...');
      await db.schema.table('orcamentos', function(table) {
        table.timestamp('data_conversao').nullable();
      });
      console.log('Coluna data_conversao adicionada com sucesso!');
    } else {
      console.log('A coluna data_conversao já existe na tabela orcamentos.');
    }

    console.log('Operação concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao adicionar coluna:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
addDataConversaoColumn(); 