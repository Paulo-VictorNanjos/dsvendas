const knex = require('./database/connection');

async function verificarClientes() {
  try {
    console.log('Verificando estrutura da tabela clientes...');
    const colunas = await knex('clientes').columnInfo();
    console.log('Colunas disponíveis na tabela clientes:', Object.keys(colunas));
    process.exit(0);
  } catch (err) {
    console.error('Erro ao verificar tabela clientes:', err.message);
    process.exit(1);
  }
}

verificarClientes(); 