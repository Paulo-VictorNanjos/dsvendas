const syncService = require('./services/syncService');

async function testarSincronizacaoRegrasFiscais() {
  console.log('=== TESTE DE SINCRONIZAÇÃO DE REGRAS FISCAIS DOS PRODUTOS ===');
  try {
    console.log('Iniciando sincronização de regras fiscais dos produtos...');
    const result = await syncService.syncRegrasFiscaisProdutos();
    console.log(`Sincronização concluída! ${result} regras fiscais de produtos processadas.`);
    
    // Buscar produtos com regra 8 após a sincronização
    const knex = require('./database/connection');
    
    // Verificar produtos com ST ativo
    const produtosComST = await knex('produtos')
      .select('codigo', 'descricao', 'cod_regra_icms', 'subs_trib')
      .where('subs_trib', 1)
      .orderBy('cod_regra_icms')
      .limit(10);
      
    console.log(`\nEncontrados ${produtosComST.length} produtos com ST ativo após sincronização:`);
    console.table(produtosComST);
    
    // Verificar distribuição de regras fiscais
    const distribuicaoRegras = await knex('produtos')
      .select('cod_regra_icms')
      .count('* as total')
      .whereNotNull('cod_regra_icms')
      .groupBy('cod_regra_icms')
      .orderBy('total', 'desc');
      
    console.log('\nDistribuição de regras fiscais após sincronização:');
    console.table(distribuicaoRegras);
    
    // Encerrar conexão com o banco
    knex.destroy();
    
  } catch (error) {
    console.error('ERRO durante a sincronização:', error);
  }
}

testarSincronizacaoRegrasFiscais().then(() => {
  console.log('Teste finalizado!');
  process.exit(0);
}).catch(err => {
  console.error('Falha no teste:', err);
  process.exit(1);
}); 