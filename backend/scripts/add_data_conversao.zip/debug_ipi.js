const knex = require('./database/connection');
const erpConnection = require('./database/erpConnection');

async function debugIpiSync() {
  console.log('=== DEPURAÇÃO DE SINCRONIZAÇÃO DE ALÍQUOTA IPI ===');
  
  try {
    // 1. Verificar se conseguimos acessar o banco ERP
    console.log('\n1. Testando conexão com o banco ERP...');
    const testErp = await erpConnection.raw('SELECT 1 as test');
    console.log('Conexão com ERP: OK');
    
    // 2. Buscar alguns produtos no ERP com suas alíquotas de IPI
    console.log('\n2. Buscando produtos com alíquota IPI no ERP...');
    const produtosErp = await erpConnection('produtos')
      .select(
        'codigo as cod_produto',
        'descricao',
        'aliq_ipi'
      )
      .whereNotNull('aliq_ipi')
      .andWhereRaw('CAST(aliq_ipi AS FLOAT) > 0')
      .limit(5);
    
    if (produtosErp.length === 0) {
      console.log('Não foram encontrados produtos com alíquota IPI maior que zero no ERP.');
      
      // Mostrar alguns produtos mesmo com IPI zero
      console.log('\nMostrando produtos do ERP independente do valor de IPI:');
      const produtosErpZero = await erpConnection('produtos')
        .select(
          'codigo as cod_produto',
          'descricao',
          'aliq_ipi'
        )
        .limit(5);
      
      console.table(produtosErpZero);
    } else {
      console.log('Produtos com IPI no ERP:');
      console.table(produtosErp);
    }
    
    // Pegar o primeiro produto para análise detalhada
    const codigosProdutos = produtosErp.map(p => p.cod_produto);
    
    // 3. Verificar esses mesmos produtos no sistema web
    console.log('\n3. Verificando os mesmos produtos no sistema web...');
    const produtosWeb = await knex('produtos')
      .select(
        'codigo',
        'descricao',
        'aliq_ipi'
      )
      .whereIn('codigo', codigosProdutos);
    
    console.log('Produtos no sistema web:');
    console.table(produtosWeb);
    
    // 4. Testar a execução da consulta usada no syncRegrasFiscaisProdutos
    console.log('\n4. Testando consulta do método syncRegrasFiscaisProdutos...');
    const testQuery = await erpConnection
      .select(
        'prod.codigo as cod_produto',
        'prod.descricao',
        'prod.cod_regra_icms',
        'prod.class_fiscal',
        'prod.cod_origem_prod',
        'prod.aliq_ipi',
        'cf.cod_ncm'
      )
      .from('produtos as prod')
      .leftJoin('class_fiscal as cf', erpConnection.raw('CAST(prod.class_fiscal AS INTEGER)'), 'cf.codigo')
      .whereIn('prod.codigo', codigosProdutos)
      .limit(5);
    
    console.log('Resultado da consulta de sincronização:');
    console.table(testQuery);
    
    // 5. Verificar se as tabelas têm as colunas esperadas
    console.log('\n5. Verificando estrutura da tabela produtos no sistema web...');
    const colunasWeb = await knex('produtos').columnInfo();
    console.log('Colunas da tabela produtos no sistema web:');
    console.log(Object.keys(colunasWeb));
    const hasIpiColumn = Object.keys(colunasWeb).includes('aliq_ipi');
    console.log(`Coluna aliq_ipi existe na tabela produtos: ${hasIpiColumn ? 'SIM' : 'NÃO'}`);
    
    // 6. Simular a atualização manual de um produto
    if (codigosProdutos.length > 0) {
      const produtoTeste = codigosProdutos[0];
      const valorIpiErp = produtosErp.find(p => p.cod_produto === produtoTeste)?.aliq_ipi || 0;
      
      console.log(`\n6. Simulando atualização manual do produto ${produtoTeste} com IPI = ${valorIpiErp}...`);
      
      // Atualizar o produto manualmente
      await knex('produtos')
        .where('codigo', produtoTeste)
        .update({
          aliq_ipi: valorIpiErp
        });
      
      // Verificar se a atualização funcionou
      const produtoAtualizado = await knex('produtos')
        .select('codigo', 'descricao', 'aliq_ipi')
        .where('codigo', produtoTeste)
        .first();
      
      console.log('Produto após atualização manual:');
      console.log(produtoAtualizado);
    }
    
  } catch (error) {
    console.error('ERRO durante a depuração:', error);
  } finally {
    // Encerrar conexões
    knex.destroy();
    erpConnection.destroy();
  }
}

// Executar a função de depuração
debugIpiSync().then(() => {
  console.log('\nProcesso de depuração concluído!');
}).catch(err => {
  console.error('Erro fatal:', err);
}); 