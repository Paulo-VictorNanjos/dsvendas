/**
 * Script para associar clientes a um vendedor específico.
 * 
 * Uso: node scripts/associarClientesVendedor.js <ID_VENDEDOR>
 * Exemplo: node scripts/associarClientesVendedor.js 1
 */

const erpConnection = require('../database/erpConnection');

// Pegar o ID do vendedor da linha de comando
const vendedorId = process.argv[2];

if (!vendedorId) {
  console.error('❌ ID do vendedor não informado!');
  console.log('Uso: node scripts/associarClientesVendedor.js <ID_VENDEDOR>');
  process.exit(1);
}

async function associarClientesVendedor() {
  try {
    console.log(`🔄 Iniciando associação de clientes ao vendedor ID ${vendedorId}...`);
    
    // Verificar se o vendedor existe
    const vendedor = await erpConnection('vendedores')
      .where('codigo', vendedorId)
      .first();
      
    if (!vendedor) {
      console.error(`❌ Vendedor com ID ${vendedorId} não encontrado!`);
      process.exit(1);
    }
    
    console.log(`✅ Vendedor encontrado: ${vendedor.nome}`);
    
    // Contar quantos clientes já estão associados a este vendedor
    const clientesAssociados = await erpConnection('clientes')
      .where('cod_vendedor1', vendedorId)
      .count('* as total')
      .first();
      
    console.log(`📊 Clientes já associados ao vendedor: ${clientesAssociados?.total || 0}`);
    
    // Pegar alguns clientes que não estão associados a nenhum vendedor
    const clientesSemVendedor = await erpConnection('clientes')
      .whereNull('cod_vendedor1')
      .orWhere('cod_vendedor1', 0)
      .limit(10)
      .select('codigo', 'razao', 'nome');
      
    console.log(`📊 Encontrados ${clientesSemVendedor.length} clientes sem vendedor associado.`);
    
    if (clientesSemVendedor.length === 0) {
      console.log('⚠️ Não há clientes sem vendedor para associar.');
      
      // Neste caso, podemos associar clientes de outro vendedor
      const clientesOutroVendedor = await erpConnection('clientes')
        .whereNot('cod_vendedor1', vendedorId)
        .whereNotNull('cod_vendedor1')
        .limit(10)
        .select('codigo', 'razao', 'nome', 'cod_vendedor1');
        
      if (clientesOutroVendedor.length === 0) {
        console.log('❌ Não há clientes disponíveis para associar.');
        process.exit(0);
      }
      
      console.log(`⚠️ Associando ${clientesOutroVendedor.length} clientes de outros vendedores...`);
      
      // Associar estes clientes ao vendedor especificado
      for (const cliente of clientesOutroVendedor) {
        console.log(`🔄 Associando cliente ${cliente.codigo} (${cliente.razao || cliente.nome}) do vendedor ${cliente.cod_vendedor1} para o vendedor ${vendedorId}`);
        
        await erpConnection('clientes')
          .where('codigo', cliente.codigo)
          .update({ cod_vendedor1: vendedorId });
      }
    } else {
      // Associar os clientes sem vendedor ao vendedor especificado
      console.log(`🔄 Associando ${clientesSemVendedor.length} clientes ao vendedor ${vendedorId}...`);
      
      for (const cliente of clientesSemVendedor) {
        console.log(`🔄 Associando cliente ${cliente.codigo} (${cliente.razao || cliente.nome}) ao vendedor ${vendedorId}`);
        
        await erpConnection('clientes')
          .where('codigo', cliente.codigo)
          .update({ cod_vendedor1: vendedorId });
      }
    }
    
    console.log('✅ Associação concluída!');
    
    // Verificar resultado final
    const clientesAssociadosFinal = await erpConnection('clientes')
      .where('cod_vendedor1', vendedorId)
      .count('* as total')
      .first();
      
    console.log(`📊 Total de clientes associados ao vendedor após associação: ${clientesAssociadosFinal?.total || 0}`);
    
    // Listar alguns clientes associados para verificação
    const clientesAssociadosLista = await erpConnection('clientes')
      .where('cod_vendedor1', vendedorId)
      .limit(5)
      .select('codigo', 'razao', 'nome');
      
    console.log('📋 Exemplos de clientes associados:');
    clientesAssociadosLista.forEach(cliente => {
      console.log(`- Cliente ${cliente.codigo}: ${cliente.razao || cliente.nome}`);
    });
    
  } catch (error) {
    console.error('❌ Erro durante associação:', error);
  } finally {
    await erpConnection.destroy();
    console.log('🔒 Conexão encerrada.');
  }
}

associarClientesVendedor(); 