const knex = require('./database/connection');
const logger = require('./utils/logger');

async function corrigirRegrasIcms() {
  try {
    console.log('Iniciando correção de regras ICMS...');
    
    // 1. Verificar a estrutura da tabela regras_icms_itens
    console.log('Verificando estrutura da tabela regras_icms_itens...');
    const colunas = await knex('regras_icms_itens').columnInfo();
    const colunasDisponiveis = Object.keys(colunas);
    
    console.log(`Colunas disponíveis: ${colunasDisponiveis.join(', ')}`);
    
    // 2. Verificar se existe a coluna cod_empresa
    if (!colunasDisponiveis.includes('cod_empresa')) {
      console.log('Coluna cod_empresa não existe. Adicionando...');
      
      try {
        await knex.schema.table('regras_icms_itens', table => {
          table.integer('cod_empresa').defaultTo(1);
        });
        console.log('Coluna cod_empresa adicionada com sucesso!');
      } catch (error) {
        console.error('Erro ao adicionar coluna cod_empresa:', error);
        return;
      }
    }
    
    // 3. Contar regras sem empresa definida
    const regrasSemEmpresa = await knex('regras_icms_itens')
      .whereNull('cod_empresa')
      .count('* as total')
      .first();
      
    console.log(`${regrasSemEmpresa.total} regras ICMS não têm empresa definida.`);
    
    // 4. Atualizar todas as regras para a empresa 1
    if (regrasSemEmpresa.total > 0) {
      console.log('Atualizando regras sem empresa para empresa 1...');
      
      const regrasAtualizadas = await knex('regras_icms_itens')
        .whereNull('cod_empresa')
        .update({
          cod_empresa: 1
        });
        
      console.log(`${regrasAtualizadas} regras ICMS atualizadas com empresa 1.`);
    }
    
    // 5. Verificar possíveis duplicações
    console.log('Verificando possíveis duplicações de regras...');
    
    // Buscar regras com a mesma combinação de cod_regra_icms e uf
    const duplicatas = await knex.raw(`
      SELECT cod_regra_icms, uf, COUNT(*) as total
      FROM regras_icms_itens
      GROUP BY cod_regra_icms, uf
      HAVING COUNT(*) > 1
    `);
    
    if (duplicatas.rows && duplicatas.rows.length > 0) {
      console.log(`Encontradas ${duplicatas.rows.length} combinações de regra ICMS/UF duplicadas:`);
      
      for (const dup of duplicatas.rows) {
        console.log(`- Regra ${dup.cod_regra_icms}, UF ${dup.uf}: ${dup.total} registros`);
        
        // Verificar regras duplicadas detalhadas
        const regrasDetalhadas = await knex('regras_icms_itens')
          .where({
            cod_regra_icms: dup.cod_regra_icms,
            uf: dup.uf
          })
          .orderBy('cod_empresa');
          
        console.log('  Detalhes:');
        regrasDetalhadas.forEach((r, i) => {
          console.log(`  ${i+1}. Código: ${r.codigo}, Empresa: ${r.cod_empresa}, ICMS ST: ${r.icms_st}, Alíq.: ${r.aliq_icms}`);
        });
        
        // Aqui poderíamos corrigir automaticamente, mas vamos apenas identificar por segurança
        // Estratégia: manter apenas a regra da empresa 1, ou a primeira se não houver da empresa 1
        console.log('  Estratégia recomendada: manter apenas a regra da empresa 1, ou a primeira se não houver da empresa 1');
      }
    } else {
      console.log('Não foram encontradas duplicações de regras.');
    }
    
    // 6. Executar relatório final
    console.log('\nRelatório final de regras ICMS:');
    
    const totalRegras = await knex('regras_icms_itens').count('* as total').first();
    console.log(`Total de regras ICMS: ${totalRegras.total}`);
    
    const totalEmpresa1 = await knex('regras_icms_itens')
      .where('cod_empresa', 1)
      .count('* as total')
      .first();
    console.log(`Regras da empresa 1: ${totalEmpresa1.total}`);
    
    const totalOutrasEmpresas = await knex('regras_icms_itens')
      .whereNot('cod_empresa', 1)
      .count('* as total')
      .first();
    console.log(`Regras de outras empresas: ${totalOutrasEmpresas.total}`);
    
    const regrasComST = await knex('regras_icms_itens')
      .where('icms_st', 'S')
      .count('* as total')
      .first();
    console.log(`Regras com ST marcada como 'S': ${regrasComST.total}`);
    
    const regrasSemST = await knex('regras_icms_itens')
      .where('icms_st', 'N')
      .count('* as total')
      .first();
    console.log(`Regras com ST marcada como 'N': ${regrasSemST.total}`);
    
    // 7. Relatório por UF
    console.log('\nDistribuição de regras por UF:');
    const regrasPorUF = await knex('regras_icms_itens')
      .select('uf')
      .count('* as total')
      .groupBy('uf')
      .orderBy('total', 'desc');
      
    regrasPorUF.forEach(r => {
      console.log(`UF ${r.uf}: ${r.total} regras`);
    });
    
    console.log('\nCorreção de regras ICMS concluída com sucesso!');
    process.exit(0);
  } catch (err) {
    console.error('Erro ao corrigir regras ICMS:', err);
    process.exit(1);
  }
}

// Executar a função principal
corrigirRegrasIcms(); 