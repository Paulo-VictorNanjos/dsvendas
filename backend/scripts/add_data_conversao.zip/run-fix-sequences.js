const knex = require('./database/connection');
const path = require('path');

// Database configuration
const dbConfig = knex.client.config;
console.log('Database Config:', dbConfig);

// Migration file to run
const migrationFile = '20250504000000_create_regras_icms_itens_sequence.js';
const migrationPath = path.join(__dirname, 'migrations', migrationFile);

async function runMigration() {
  console.log('Iniciando migração de sequência...');
  
  try {
    const migration = require(migrationPath);
    
    // Execute the migration's up function
    await migration.up(knex);
    
    console.log('Sequência regras_icms_itens_id_seq criada com sucesso!');
    
    // Verificar se a sequência foi criada
    const result = await knex.raw("SELECT EXISTS (SELECT FROM pg_sequences WHERE sequencename = 'regras_icms_itens_id_seq')");
    const sequenceExists = result.rows[0].exists;
    
    console.log('Sequência existe:', sequenceExists);
    
  } catch (error) {
    console.error('Erro ao criar sequência:', error);
  } finally {
    // Close the database connection
    await knex.destroy();
    console.log('Conexão com o banco de dados encerrada.');
  }
}

// Run the migration
runMigration(); 