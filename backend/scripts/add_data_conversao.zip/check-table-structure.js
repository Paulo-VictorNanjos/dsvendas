const knex = require('./database/connection');

async function checkTableStructure() {
  try {
    console.log('Verificando estrutura da tabela regras_icms...');
    
    // No PostgreSQL, podemos usar information_schema para obter as colunas
    const colunas = await knex
      .select('column_name', 'data_type', 'is_nullable')
      .from('information_schema.columns')
      .where('table_name', 'regras_icms');
    
    console.log('Colunas da tabela regras_icms:');
    console.table(colunas);
    
    // Verificar as restrições de chave primária
    console.log('\nVerificando chaves primárias:');
    const chavesPrimarias = await knex
      .select(
        'tc.constraint_name', 
        'tc.table_name', 
        'kcu.column_name', 
        'tc.constraint_type'
      )
      .from('information_schema.table_constraints AS tc')
      .join(
        'information_schema.key_column_usage AS kcu',
        function() {
          this.on('tc.constraint_name', '=', 'kcu.constraint_name')
              .andOn('tc.table_schema', '=', 'kcu.table_schema');
        }
      )
      .where('tc.table_name', 'regras_icms')
      .andWhere('tc.constraint_type', 'PRIMARY KEY');
    
    console.table(chavesPrimarias);
    
    // Verificar índices únicos
    console.log('\nVerificando índices:');
    const indices = await knex.raw(`
      SELECT
        i.relname as index_name,
        a.attname as column_name,
        ix.indisunique as is_unique
      FROM
        pg_class t,
        pg_class i,
        pg_index ix,
        pg_attribute a
      WHERE
        t.oid = ix.indrelid
        and i.oid = ix.indexrelid
        and a.attrelid = t.oid
        and a.attnum = ANY(ix.indkey)
        and t.relkind = 'r'
        and t.relname = 'regras_icms'
      ORDER BY
        t.relname,
        i.relname;
    `);
    
    console.table(indices.rows);
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao verificar estrutura da tabela:', error);
    process.exit(1);
  }
}

checkTableStructure(); 