const syncService = require('./services/syncService');

async function testSyncFiscalData() {
  try {
    console.log('Iniciando sincronização de dados fiscais...');
    
    const result = await syncService.syncFiscalData();
    
    console.log('Dados fiscais sincronizados com sucesso:');
    console.log('Regras fiscais:', result.regrasFiscais);
    console.log('Classificações fiscais:', result.classeFiscal);
    console.log('Regras fiscais de produtos:', result.regrasProdutos);
    console.log('Produtos atualizados:', result.produtosAtualizados);
  } catch (error) {
    console.error('Erro na sincronização:', error);
  }
}

testSyncFiscalData()
  .then(() => console.log('Teste concluído'))
  .catch(err => console.error('Erro:', err))
  .finally(() => process.exit(0)); 