// Script para adicionar colunas status e data_aprovacao na tabela orcamentos
const knex = require('knex');
const config = require('../knexfile').development;  // Use a configuração development

const db = knex(config);

async function addColumnsToOrcamentos() {
  try {
    // Verificar se a coluna status já existe
    const hasStatusColumn = await db.schema.hasColumn('orcamentos', 'status');
    
    if (!hasStatusColumn) {
      console.log('Adicionando coluna status à tabela orcamentos...');
      await db.schema.table('orcamentos', function(table) {
        table.string('status').defaultTo('PENDENTE');
      });
      console.log('Coluna status adicionada com sucesso!');
    } else {
      console.log('A coluna status já existe na tabela orcamentos.');
    }

    // Verificar se a coluna data_aprovacao já existe
    const hasApprovalDateColumn = await db.schema.hasColumn('orcamentos', 'data_aprovacao');
    
    if (!hasApprovalDateColumn) {
      console.log('Adicionando coluna data_aprovacao à tabela orcamentos...');
      await db.schema.table('orcamentos', function(table) {
        table.timestamp('data_aprovacao').nullable();
      });
      console.log('Coluna data_aprovacao adicionada com sucesso!');
    } else {
      console.log('A coluna data_aprovacao já existe na tabela orcamentos.');
    }

    // Atualizar registros existentes para terem o status padrão
    await db('orcamentos').update({ status: 'PENDENTE' }).whereNull('status');
    console.log('Registros atualizados com o status padrão.');

    console.log('Operação concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao adicionar colunas:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
addColumnsToOrcamentos(); 