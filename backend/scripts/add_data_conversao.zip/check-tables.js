const knex = require('./database/connection');
const logger = require('./utils/logger');

async function checkTables() {
  try {
    // Verificar tabela de produtos
    console.log('=== VERIFICANDO TABELA DE PRODUTOS ===');
    const produtos = await knex('produtos')
      .select('codigo', 'descricao', 'aliq_ipi', 'cod_regra_icms', 'class_fiscal', 'cod_origem_prod')
      .whereNotNull('cod_regra_icms')
      .limit(5);
    
    console.log(JSON.stringify(produtos, null, 2));
    
    // Verificar tabela de regras ICMS
    console.log('\n=== VERIFICANDO TABELA DE REGRAS_ICMS ===');
    
    // Verificar a quantidade total de regras
    const totalRegras = await knex('regras_icms').count('* as total').first();
    console.log(`Total de regras na tabela: ${totalRegras.total}`);
    
    // Tentar buscar regras específicas
    console.log('\n=== TENTANDO BUSCAR REGRA ICMS ESPECÍFICA ===');
    const regra1 = await knex('regras_icms')
      .where('codigo', 1)
      .select('*');
    
    console.log(`Regras com código 1: ${regra1.length}`);
    console.log(JSON.stringify(regra1, null, 2));
    
    // Verificar tabela de classificação fiscal
    console.log('\n=== VERIFICANDO TABELA DE CLASS_FISCAL_DADOS ===');
    const classFiscalDados = await knex('class_fiscal_dados')
      .select('*')
      .limit(5);
    
    console.log(JSON.stringify(classFiscalDados, null, 2));
    
    // Verificar se há produtos sem regras fiscais
    console.log('\n=== PRODUTOS SEM CÓDIGO DE REGRA ICMS ===');
    const produtosSemRegra = await knex('produtos')
      .count('* as total')
      .whereNull('cod_regra_icms');
    
    console.log(JSON.stringify(produtosSemRegra, null, 2));
    
    // Verificar se há produtos sem classificação fiscal
    console.log('\n=== PRODUTOS SEM CLASSIFICAÇÃO FISCAL ===');
    const produtosSemClass = await knex('produtos')
      .count('* as total')
      .whereNull('class_fiscal');
    
    console.log(JSON.stringify(produtosSemClass, null, 2));
    
    // Verificar se há produtos sem IPI
    console.log('\n=== PRODUTOS SEM ALÍQUOTA IPI ===');
    const produtosSemIpi = await knex('produtos')
      .count('* as total')
      .whereNull('aliq_ipi');
    
    console.log(JSON.stringify(produtosSemIpi, null, 2));
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao verificar tabelas:', error);
    process.exit(1);
  }
}

checkTables(); 