const knex = require('./database/connection');
const path = require('path');

// Database configuration
const dbConfig = knex.client.config;
console.log('Database Config:', dbConfig);

// Migration file to run
const migrationFile = '20250503125954_add_campos_fiscais_to_orcamentos_itens.js';
const migrationPath = path.join(__dirname, 'migrations', migrationFile);

async function runMigration() {
  console.log('Iniciando migração...');
  
  try {
    const migration = require(migrationPath);
    
    // Execute the migration's up function
    await migration.up(knex);
    
    console.log('Migração concluída com sucesso!');
    
    // For demonstration purposes, list affected columns
    const columnsAdded = [
      'st_icms', 'aliq_icms', 'valor_icms', 'icms_st',
      'valor_icms_st', 'ipi', 'valor_ipi', 'class_fiscal',
      'ncm', 'cod_origem_prod'
    ];
    console.log('Colunas adicionadas:', columnsAdded);
  } catch (error) {
    console.error('Erro ao executar migração:', error);
  } finally {
    // Close the database connection
    await knex.destroy();
    console.log('Conexão com o banco de dados encerrada.');
  }
}

// Run the migration
runMigration(); 