// Script para adicionar a coluna pedido_venda na tabela orcamentos
const knex = require('knex');
const config = require('../knexfile').development;

const db = knex(config);

async function addPedidoVendaToOrcamentos() {
  try {
    // Verificar se a coluna pedido_venda já existe
    const hasPedidoVendaColumn = await db.schema.hasColumn('orcamentos', 'pedido_venda');
    
    if (!hasPedidoVendaColumn) {
      console.log('Adicionando coluna pedido_venda à tabela orcamentos...');
      await db.schema.table('orcamentos', function(table) {
        table.string('pedido_venda').nullable();
      });
      console.log('Coluna pedido_venda adicionada com sucesso!');
    } else {
      console.log('A coluna pedido_venda já existe na tabela orcamentos.');
    }

    console.log('Operação concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao adicionar coluna:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
addPedidoVendaToOrcamentos(); 