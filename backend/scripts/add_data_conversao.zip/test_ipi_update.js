const syncService = require('./services/syncService');

async function testarAtualizacaoIPI() {
  console.log('=== TESTE DE ATUALIZAÇÃO DE IPI ===');
  try {
    console.log('Iniciando atualização de dados fiscais dos produtos...');
    const result = await syncService.updateProductsFiscalData();
    console.log(`Atualização concluída! ${result} produtos processados.`);
  } catch (error) {
    console.error('ERRO durante a atualização:', error);
  }
}

testarAtualizacaoIPI().then(() => {
  console.log('Teste finalizado!');
  process.exit(0);
}).catch(err => {
  console.error('Falha no teste:', err);
  process.exit(1);
}); 