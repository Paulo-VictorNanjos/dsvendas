/**
 * Script para testar o cálculo de ICMS e ST de acordo com a lógica do ERP
 */
const knex = require('./database/connection');

async function testCalculoImpostos() {
  try {
    console.log('Iniciando teste de cálculo de ICMS e ST com dados simulados...');
    
    // Dados simulados de um produto com ST
    const dadosFiscais = {
      codigo: 'PROD123',
      descricao: 'Produto Teste com ST',
      aliq_icms: 18,
      aliq_ipi: 5,
      icms_st: 'S',
      red_icms: 10,
      st_icms: '60',
      class_fiscal: '73269090',
      iva: 35, // IVA para produtos com ST
      aliq_interna: 18, // Alíquota interna do estado
      pauta_icms_st: 0 // Sem pauta
    };
    
    console.log('\nDados fiscais simulados:', dadosFiscais);
    
    // 3. Realizar o cálculo com nossa lógica
    const quantidade = 10;
    const valorUnitario = 100;
    const valorBruto = quantidade * valorUnitario;
    const desconto = 0; // Sem desconto para simplificar
    const valorLiquido = valorBruto;
    
    // Dados fiscais
    const aliqIcms = parseFloat(dadosFiscais.aliq_icms || 0);
    const aliqIpi = parseFloat(dadosFiscais.aliq_ipi || 0);
    const redIcms = parseFloat(dadosFiscais.red_icms || 0);
    const temST = dadosFiscais.icms_st === 'S';
    const iva = parseFloat(dadosFiscais.iva || 0);
    
    // Cálculo da base do ICMS com redução
    const baseIcms = valorLiquido * (1 - (redIcms / 100));
    
    // Cálculo do ICMS
    const valorIcms = baseIcms * (aliqIcms / 100);
    
    // Cálculo do IPI
    const valorIpi = valorLiquido * (aliqIpi / 100);
    
    // Cálculo do ICMS-ST
    let baseIcmsSt = 0;
    let valorIcmsSt = 0;
    
    if (temST) {
      const pautaIcmsSt = parseFloat(dadosFiscais.pauta_icms_st || 0);
      
      if (pautaIcmsSt > 0) {
        baseIcmsSt = pautaIcmsSt * quantidade;
      } else {
        baseIcmsSt = (valorLiquido + valorIpi) * (1 + (iva / 100));
      }
      
      const aliqInterna = parseFloat(dadosFiscais.aliq_interna || aliqIcms || 18);
      valorIcmsSt = (baseIcmsSt * (aliqInterna / 100)) - valorIcms;
      
      if (valorIcmsSt < 0) {
        valorIcmsSt = 0;
      }
    }
    
    // Total com impostos
    const valorTotal = valorLiquido + valorIpi + valorIcmsSt;
    
    // Imprimir resultados
    console.log('\nCálculo realizado:');
    console.log('==================');
    console.log(`Quantidade: ${quantidade}`);
    console.log(`Valor Unitário: R$ ${valorUnitario.toFixed(2)}`);
    console.log(`Valor Bruto: R$ ${valorBruto.toFixed(2)}`);
    console.log(`Desconto: ${desconto}% (R$ 0.00)`);
    console.log(`Valor Líquido: R$ ${valorLiquido.toFixed(2)}`);
    console.log('\nImpostos:');
    console.log(`Redução de Base ICMS: ${redIcms}%`);
    console.log(`Base de ICMS: R$ ${baseIcms.toFixed(2)}`);
    console.log(`Alíquota ICMS: ${aliqIcms}%`);
    console.log(`Valor ICMS: R$ ${valorIcms.toFixed(2)}`);
    console.log(`\nIVA: ${iva}%`);
    console.log(`Base ICMS-ST: R$ ${baseIcmsSt.toFixed(2)}`);
    console.log(`Alíquota Interna ST: ${parseFloat(dadosFiscais.aliq_interna || aliqIcms || 18)}%`);
    console.log(`Valor ICMS-ST: R$ ${valorIcmsSt.toFixed(2)}`);
    console.log(`\nAlíquota IPI: ${aliqIpi}%`);
    console.log(`Valor IPI: R$ ${valorIpi.toFixed(2)}`);
    console.log('\nTotal:');
    console.log(`Valor Total com Impostos: R$ ${valorTotal.toFixed(2)}`);
    
    // Comparar com o cálculo do ERP (simulado)
    console.log('\nComparação com ERP:');
    console.log('==================');
    // Para o ICMS, o ERP faz: valor líquido * (1 - redução) * alíquota
    const icmsERP = (valorLiquido * (1 - (redIcms / 100))) * (aliqIcms / 100);
    console.log(`ICMS ERP: R$ ${icmsERP.toFixed(2)} | ICMS Calculado: R$ ${valorIcms.toFixed(2)} | Diferença: R$ ${Math.abs(icmsERP - valorIcms).toFixed(2)}`);
    
    // Para o ST, o ERP faz: ((valor líquido + IPI) * (1 + IVA/100)) * alíquota interna - ICMS
    const baseIcmsStERP = (valorLiquido + valorIpi) * (1 + (iva / 100));
    const aliqInternaERP = parseFloat(dadosFiscais.aliq_interna || aliqIcms || 18);
    const stERP = (baseIcmsStERP * (aliqInternaERP / 100)) - icmsERP;
    console.log(`ST ERP: R$ ${stERP.toFixed(2)} | ST Calculado: R$ ${valorIcmsSt.toFixed(2)} | Diferença: R$ ${Math.abs(stERP - valorIcmsSt).toFixed(2)}`);
    
    // Para o total, o ERP faz: valor líquido + IPI + ST
    const totalERP = valorLiquido + valorIpi + stERP;
    console.log(`Total ERP: R$ ${totalERP.toFixed(2)} | Total Calculado: R$ ${valorTotal.toFixed(2)} | Diferença: R$ ${Math.abs(totalERP - valorTotal).toFixed(2)}`);
    
  } catch (error) {
    console.error('Erro ao testar cálculo de impostos:', error);
  } finally {
    // Encerrar conexão
    knex.destroy();
  }
}

// Executar o teste
testCalculoImpostos(); 