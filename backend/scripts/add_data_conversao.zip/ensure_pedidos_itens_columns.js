// Script para garantir que a tabela pedidos_itens tenha todas as colunas necessárias
const knex = require('knex');
const config = require('../knexfile').development;

const db = knex(config);

async function ensurePedidosItensColumns() {
  try {
    console.log('Verificando estrutura da tabela pedidos_itens...');
    
    // Lista de colunas esperadas e seus tipos
    const expectedColumns = [
      { name: 'codigo', type: 'string', isPrimary: true },
      { name: 'pedido_codigo', type: 'string' },
      { name: 'produto_codigo', type: 'string' },
      { name: 'quantidade', type: 'decimal' },
      { name: 'valor_unitario', type: 'decimal' },
      { name: 'valor_total', type: 'decimal' },
      { name: 'desconto', type: 'decimal' },
      { name: 'aliq_icms', type: 'decimal' },
      { name: 'valor_icms', type: 'decimal' },
      { name: 'valor_icms_st', type: 'decimal' },
      { name: 'aliq_ipi', type: 'decimal' },
      { name: 'valor_ipi', type: 'decimal' },
      { name: 'cod_empresa', type: 'string' },
      { name: 'dt_inc', type: 'date' },
      { name: 'created_at', type: 'timestamp' },
      { name: 'updated_at', type: 'timestamp' }
    ];
    
    // Verificar se a tabela existe
    const tableExists = await db.schema.hasTable('pedidos_itens');
    
    if (!tableExists) {
      console.log('A tabela pedidos_itens não existe. Criando tabela...');
      await db.schema.createTable('pedidos_itens', function(table) {
        table.string('codigo').primary();
        table.string('pedido_codigo');
        table.string('produto_codigo');
        table.decimal('quantidade', 10, 3);
        table.decimal('valor_unitario', 10, 4);
        table.decimal('valor_total', 10, 2);
        table.decimal('desconto', 10, 2);
        table.decimal('aliq_icms', 10, 2);
        table.decimal('valor_icms', 10, 2);
        table.decimal('valor_icms_st', 10, 2);
        table.decimal('aliq_ipi', 10, 2);
        table.decimal('valor_ipi', 10, 2);
        table.string('cod_empresa');
        table.date('dt_inc');
        table.timestamps(true, true);
        
        // Chaves estrangeiras
        table.foreign('pedido_codigo').references('codigo').inTable('pedidos');
        table.foreign('produto_codigo').references('codigo').inTable('produtos');
      });
      console.log('Tabela pedidos_itens criada com sucesso!');
    } else {
      // Verificar cada coluna esperada
      for (const column of expectedColumns) {
        const columnExists = await db.schema.hasColumn('pedidos_itens', column.name);
        
        if (!columnExists) {
          console.log(`Adicionando coluna ${column.name} à tabela pedidos_itens...`);
          
          await db.schema.table('pedidos_itens', function(table) {
            switch (column.type) {
              case 'string':
                table.string(column.name).nullable();
                break;
              case 'decimal':
                if (column.name === 'quantidade') {
                  table.decimal(column.name, 10, 3).nullable();
                } else if (column.name === 'valor_unitario') {
                  table.decimal(column.name, 10, 4).nullable();
                } else {
                  table.decimal(column.name, 10, 2).nullable();
                }
                break;
              case 'date':
                table.date(column.name).nullable();
                break;
              case 'timestamp':
                table.timestamp(column.name).nullable();
                break;
              default:
                table.string(column.name).nullable();
            }
          });
          
          console.log(`Coluna ${column.name} adicionada com sucesso!`);
        } else {
          console.log(`A coluna ${column.name} já existe.`);
        }
      }
    }
    
    console.log('Verificação de estrutura da tabela pedidos_itens concluída!');
    
  } catch (error) {
    console.error('Erro ao verificar estrutura da tabela pedidos_itens:', error);
  } finally {
    // Fechar conexão com o banco de dados
    db.destroy();
  }
}

// Executar a função
ensurePedidosItensColumns(); 