-- Adicionar coluna dt_conversao se não existir
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'orcamentos' 
        AND column_name = 'dt_conversao'
    ) THEN
        ALTER TABLE orcamentos
        ADD COLUMN dt_conversao TIMESTAMP;
    END IF;
END
$$; 