const knex = require('./database/connection');

async function verificarCampoSubsTrib() {
  try {
    console.log('Verificando informações sobre o campo subs_trib na tabela produtos...');
    
    // Obter informações detalhadas da coluna
    const colunaInfo = await knex.raw(`
      SELECT 
        table_name,
        column_name,
        data_type,
        character_maximum_length,
        numeric_precision,
        numeric_scale
      FROM information_schema.columns
      WHERE table_name = 'produtos'
      AND column_name = 'subs_trib'
    `);
    
    if (colunaInfo.rows && colunaInfo.rows.length > 0) {
      console.log('Informações da coluna subs_trib:');
      console.log(colunaInfo.rows[0]);
    } else {
      console.log('Campo subs_trib não encontrado na tabela produtos');
    }
    
    // Verificar alguns valores existentes
    const exemplos = await knex('produtos')
      .select('codigo', 'descricao', 'subs_trib')
      .whereNotNull('subs_trib')
      .limit(5);
      
    console.log('\nExemplos de valores existentes:');
    console.table(exemplos);
    
    console.log('\nTestando inserção de valores...');
    try {
      // Testar com valor numérico 1
      await knex('produtos')
        .where('codigo', exemplos[0]?.codigo || '557.000-018')
        .update({
          subs_trib: 1
        });
      console.log('Atualização com valor 1: OK');
    } catch (error) {
      console.error('Erro ao atualizar com valor 1:', error.message);
    }
    
  } catch (error) {
    console.error('Erro ao verificar campo:', error);
  } finally {
    knex.destroy();
  }
}

verificarCampoSubsTrib().then(() => {
  console.log('Verificação concluída');
}); 