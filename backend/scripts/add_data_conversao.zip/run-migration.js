const fs = require('fs');
const path = require('path');
const knex = require('./database/connection');

// Carregar o SQL do arquivo de migração
const sqlPath = path.join(__dirname, 'migrations', 'add_unidade_tributacao.sql');
const sql = fs.readFileSync(sqlPath, 'utf8');

// Executar a migração
console.log('Iniciando migração...');
knex.raw(sql)
  .then(() => {
    console.log('Migração concluída com sucesso!');
    // Verificar se as colunas foram adicionadas
    return knex.raw("SELECT column_name FROM information_schema.columns WHERE table_name = 'produtos' AND column_name IN ('unidade', 'unidade_tributacao', 'fator_conversao')");
  })
  .then((result) => {
    console.log('Colunas adicionadas:', result.rows.map(r => r.column_name));
  })
  .catch(err => {
    console.error('Erro na migração:', err);
  })
  .finally(() => {
    knex.destroy();
    console.log('Conexão com o banco de dados encerrada.');
  }); 