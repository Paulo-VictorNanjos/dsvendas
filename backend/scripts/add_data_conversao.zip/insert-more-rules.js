const knex = require('./database/connection');

async function insertMoreRules() {
  try {
    console.log('Inserindo mais regras ICMS...');
    
    // Regras para outros estados
    const regras = [
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'RJ',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 20.00, // Alíquota padrão RJ
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 20.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 20.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        created_at: new Date(),
        updated_at: new Date()
      },
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'MG',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 18.00, // Alíquota padrão MG
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 18.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 18.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        created_at: new Date(),
        updated_at: new Date()
      },
      {
        codigo: 1, // Mesmo código usado nos produtos
        uf: 'PR',
        st_icms: '00', // CST para consumidor final
        aliq_icms: 18.00, // Alíquota padrão PR
        red_icms: 0.00,
        st_icms_contr: '10', // CST para contribuinte com ST
        aliq_icms_contr: 18.00,
        red_icms_contr: 0.00,
        icms_st: 'S', // Indica que calcula ST
        aliq_interna: 18.00,
        aliq_dif_icms_contr: 0.00,
        aliq_dif_icms_cons: 0.00,
        created_at: new Date(),
        updated_at: new Date()
      }
    ];
    
    // Inserir regras no banco
    await knex('regras_icms').insert(regras);
    
    console.log(`${regras.length} regras ICMS adicionais inseridas com sucesso!`);
    
    // Verificar todas as regras
    const todasRegras = await knex('regras_icms').select('codigo', 'uf', 'icms_st', 'st_icms_contr');
    console.log('Todas as regras agora disponíveis:');
    console.table(todasRegras);
    
    process.exit(0);
  } catch (error) {
    console.error('Erro ao inserir mais regras:', error);
    process.exit(1);
  }
}

insertMoreRules(); 