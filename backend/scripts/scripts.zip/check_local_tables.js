require('dotenv').config();
const knex = require('../database/connection');

async function checkLocalTables() {
  try {
    // Lista todas as tabelas
    const tables = await knex.raw(`
      SELECT tablename 
      FROM pg_catalog.pg_tables 
      WHERE schemaname = 'public'
    `);
    console.log('Tabelas existentes:', tables.rows);

    // Para cada tabela, mostra sua estrutura
    for (const table of tables.rows) {
      const columns = await knex.raw(`
        SELECT column_name, data_type, character_maximum_length
        FROM information_schema.columns
        WHERE table_name = '${table.tablename}'
      `);
      console.log(`\nEstrutura da tabela ${table.tablename}:`, columns.rows);
    }

  } catch (error) {
    console.error('Erro ao verificar tabelas:', error);
  } finally {
    process.exit();
  }
}

checkLocalTables(); 