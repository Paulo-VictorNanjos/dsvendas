const knex = require('../database/connection');

/**
 * Script para criar as sequências necessárias para o banco de dados
 * Este script verifica se as sequências existem e as cria caso não existam
 */

async function createSequences() {
  console.log('Iniciando criação de sequências...');
  
  // Lista de sequências a serem verificadas/criadas
  const sequences = [
    'regras_icms_itens_id_seq',
    'regras_icms_id_seq',
    'regras_fiscais_produtos_id_seq',
    'class_fiscal_id_seq',
    'orcamentos_id_seq',
    'orcamentos_itens_id_seq',
    'pedidos_id_seq',
    'pedidos_itens_id_seq'
  ];
  
  try {
    // Para cada sequência na lista
    for (const sequenceName of sequences) {
      // Verificar se a sequência já existe
      const result = await knex.raw(`SELECT EXISTS (
        SELECT FROM pg_sequences WHERE sequencename = '${sequenceName}'
      )`);
      
      const sequenceExists = result.rows[0].exists;
      
      if (sequenceExists) {
        console.log(`Sequência ${sequenceName} já existe.`);
      } else {
        // Criar a sequência
        await knex.raw(`CREATE SEQUENCE IF NOT EXISTS ${sequenceName}`);
        console.log(`Sequência ${sequenceName} criada com sucesso.`);
      }
    }
    
    console.log('Criação de sequências concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao criar sequências:', error);
  } finally {
    // Fechar a conexão com o banco de dados
    await knex.destroy();
    console.log('Conexão com o banco de dados encerrada.');
  }
}

// Executar a função
createSequences(); 