/**
 * Script para adicionar colunas ausentes nas tabelas fiscais
 * Adiciona a coluna cod_regra_pis_cofins e ncm na tabela regras_fiscais_produtos se não existirem
 */

require('dotenv').config();
const knex = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para adicionar colunas ausentes
async function adicionarColunasRegras() {
  log('=== ADICIONANDO COLUNAS AUSENTES NAS TABELAS FISCAIS ===');
  
  try {
    // Verificar se a tabela regras_fiscais_produtos existe
    if (await knex.schema.hasTable('regras_fiscais_produtos')) {
      log('Tabela regras_fiscais_produtos encontrada.');
      
      // Verificar se as colunas existem
      const colunas = await knex.raw(
        "SELECT column_name FROM information_schema.columns WHERE table_name = 'regras_fiscais_produtos'"
      );
      
      const colunasExistentes = colunas.rows.map(row => row.column_name);
      log(`Colunas existentes: ${colunasExistentes.join(', ')}`);
      
      // Adicionar coluna cod_regra_pis_cofins se não existir
      if (!colunasExistentes.includes('cod_regra_pis_cofins')) {
        log('Adicionando coluna cod_regra_pis_cofins...');
        await knex.schema.table('regras_fiscais_produtos', table => {
          table.integer('cod_regra_pis_cofins');
        });
        log('Coluna cod_regra_pis_cofins adicionada com sucesso!');
      } else {
        log('Coluna cod_regra_pis_cofins já existe.');
      }
      
      // Adicionar coluna ncm se não existir
      if (!colunasExistentes.includes('ncm')) {
        log('Adicionando coluna ncm...');
        await knex.schema.table('regras_fiscais_produtos', table => {
          table.string('ncm', 10);
        });
        log('Coluna ncm adicionada com sucesso!');
      } else {
        log('Coluna ncm já existe.');
      }
    } else {
      log('ERRO: Tabela regras_fiscais_produtos não encontrada!');
      return false;
    }
    
    log('=== ADIÇÃO DE COLUNAS FINALIZADA ===');
    return true;
  } catch (error) {
    log(`ERRO durante a adição de colunas: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexão com o banco de dados
    await knex.destroy();
  }
}

// Executar a função
adicionarColunasRegras()
  .then(success => {
    if (success) {
      log('Todas as colunas foram verificadas/adicionadas com sucesso!');
      process.exit(0);
    } else {
      log('Houve problemas na adição das colunas.');
      process.exit(1);
    }
  })
  .catch(error => {
    log(`Erro fatal: ${error.message}`);
    process.exit(1);
  }); 