/**
 * Script para popular regras fiscais padrão para produtos existentes
 * Execute com: node scripts/populate_fiscal_rules.js
 */
const knex = require('../database/connection');
const logger = require('../utils/logger');
const productFiscalRulesService = require('../services/productFiscalRulesService');

// Regra fiscal padrão para ser aplicada a todos os produtos que não têm regra
const defaultFiscalRule = {
  cod_regra_icms: 1,          // Código da regra ICMS padrão
  class_fiscal: '',           // Será preenchido individualmente
  cest: '',                   // CEST padrão vazio
  iva: 0,                     // IVA 0%
  aliq_interna: 18,           // Alíquota interna padrão 18%
  pauta_icms_st: 0,           // Sem pauta
  cod_origem_prod: '0',       // Produto nacional
  cod_empresa: 1              // Empresa padrão
};

async function populateFiscalRules() {
  try {
    console.log('[INFO] Iniciando população de regras fiscais para produtos...');
    
    // Verificar se a tabela de regras ICMS existe e tem pelo menos a regra padrão
    const hasIcmsRules = await knex('regras_icms').where('codigo', 1).first();
    
    if (!hasIcmsRules) {
      console.log('[INFO] Criando regra ICMS padrão...');
      
      // Inserir regra ICMS padrão para SP
      await knex('regras_icms').insert({
        codigo: 1,
        uf: 'SP',
        st_icms: '00',
        aliq_icms: 18,
        red_icms: 0,
        st_icms_contr: '00',
        aliq_icms_contr: 18,
        red_icms_contr: 0,
        icms_st: 'N'
      });
      
      console.log('[INFO] Regra ICMS padrão criada com sucesso.');
    }
    
    // Verificar estrutura da tabela produtos
    console.log('[INFO] Verificando estrutura da tabela produtos...');
    const produtosColumns = await knex('produtos').columnInfo();
    const hasNCM = 'ncm' in produtosColumns;
    
    // Buscar todos os produtos
    let produtos;
    if (hasNCM) {
      produtos = await knex('produtos').select('codigo', 'descricao', 'class_fiscal', 'ncm');
    } else {
      produtos = await knex('produtos').select('codigo', 'descricao', 'class_fiscal');
    }
    
    console.log(`[INFO] Encontrados ${produtos.length} produtos para processar.`);
    
    // Contador de regras criadas
    let createdCount = 0;
    let updatedCount = 0;
    
    // Para cada produto, criar ou atualizar regra fiscal
    for (const produto of produtos) {
      try {
        // Verificar se já existe regra fiscal para o produto
        const existingRule = await knex('regras_fiscais_produtos')
          .where({
            'cod_produto': produto.codigo,
            'ativo': true
          })
          .first();
        
        // Se não existir, criar uma regra padrão
        if (!existingRule) {
          // Preparar dados da regra
          const fiscalRule = {
            ...defaultFiscalRule,
            cod_produto: produto.codigo,
            class_fiscal: produto.class_fiscal || (hasNCM ? produto.ncm || '' : '')
          };
          
          // Salvar a regra fiscal
          await productFiscalRulesService.saveFiscalRules(fiscalRule);
          createdCount++;
          
          console.log(`[INFO] Criada regra fiscal para produto ${produto.codigo} - ${produto.descricao}`);
        } else {
          // Atualizar a regra com class_fiscal se estiver vazio
          if (!existingRule.class_fiscal && produto.class_fiscal) {
            await knex('regras_fiscais_produtos')
              .where('id', existingRule.id)
              .update({
                class_fiscal: produto.class_fiscal,
                dt_alt: knex.fn.now()
              });
            updatedCount++;
            
            console.log(`[INFO] Atualizada regra fiscal para produto ${produto.codigo} - ${produto.descricao}`);
          }
        }
      } catch (error) {
        console.error(`[ERRO] Falha ao processar produto ${produto.codigo}: ${error.message}`);
      }
    }
    
    console.log(`[INFO] Processo concluído. ${createdCount} regras criadas, ${updatedCount} regras atualizadas.`);
    
  } catch (error) {
    console.error('[ERRO] Falha ao popular regras fiscais:', error);
  } finally {
    // Fechar conexão com o banco
    await knex.destroy();
  }
}

// Executar a função principal
populateFiscalRules(); 