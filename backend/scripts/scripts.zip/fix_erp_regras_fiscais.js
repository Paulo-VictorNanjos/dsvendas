/**
 * Script para resolver problemas de sincronização das regras fiscais entre ERP e sistema web
 * Este script faz a importação direta dos dados do ERP para o sistema web, evitando erros de tipo
 */

require('dotenv').config();

// Conexão com o banco de dados do ERP
// Reduzindo o pool de conexões para evitar timeouts
const erpConnection = require('../database/erpConnection');

// Conexão com o banco de dados local (dsvendas)
const weberpConnection = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para delay (pausa entre operações)
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Função que ajusta/cria as tabelas necessárias
 */
async function ajustarTabelas() {
  log('=== AJUSTANDO ESTRUTURA DAS TABELAS ===');
  
  try {
    // Verificar se a tabela regras_fiscais_produto existe
    const existeTabelaCalculo = await weberpConnection.schema.hasTable('regras_fiscais_produto');
    
    if (existeTabelaCalculo) {
      log('Tabela regras_fiscais_produto existe. Ajustando colunas...');
      
      try {
        // Ajustar tamanho das colunas
        await weberpConnection.schema.alterTable('regras_fiscais_produto', (table) => {
          table.string('codigo_produto', 20).alter();
          table.string('cst_icms', 3).alter();
          table.string('cst_pis', 3).alter();
          table.string('cst_cofins', 3).alter();
        });
        log('Colunas da tabela regras_fiscais_produto ajustadas com sucesso.');
      } catch (e) {
        log(`Aviso: Não foi possível alterar as colunas. Erro: ${e.message}`);
        log('Continuando com as colunas existentes...');
      }
    } else {
      log('Criando tabela regras_fiscais_produto...');
      
      await weberpConnection.schema.createTable('regras_fiscais_produto', (table) => {
        table.increments('id').primary();
        table.string('codigo_produto', 20).notNullable().index();
        table.string('uf', 2).notNullable().index();
        table.string('cst_icms', 3);
        table.decimal('aliq_icms', 15, 4).defaultTo(0);
        table.decimal('red_bc_icms', 15, 4).defaultTo(0);
        table.decimal('aliq_pis', 15, 4).defaultTo(0);
        table.decimal('aliq_cofins', 15, 4).defaultTo(0);
        table.string('cst_pis', 3);
        table.string('cst_cofins', 3);
        table.string('codigo_ncm', 10);
        table.decimal('margem_st', 15, 4).defaultTo(0);
        table.decimal('aliq_icms_st', 15, 4).defaultTo(0);
        table.decimal('mvast', 15, 4).defaultTo(0);
        table.timestamp('created_at').defaultTo(weberpConnection.fn.now());
        table.timestamp('updated_at').defaultTo(weberpConnection.fn.now());
        
        // Adicionar índice composto para garantir unicidade por produto/UF
        table.unique(['codigo_produto', 'uf']);
      });
      
      log('Tabela regras_fiscais_produto criada com sucesso!');
    }
    
    // Verificar tabela regras_fiscais_produtos
    const existeTabelaProdutos = await weberpConnection.schema.hasTable('regras_fiscais_produtos');
    
    if (!existeTabelaProdutos) {
      log('Criando tabela regras_fiscais_produtos...');
      await weberpConnection.schema.createTable('regras_fiscais_produtos', table => {
        table.increments('id').primary();
        table.integer('cod_empresa').notNullable();
        table.string('cod_produto', 20).notNullable();  // Garantindo que o tamanho seja suficiente
        table.integer('cod_regra_icms');
        table.integer('cod_regra_pis_cofins');
        table.string('class_fiscal', 10);
        table.string('cest', 10);
        table.string('ncm', 10);
        table.string('cod_origem_prod', 1);
        table.decimal('iva', 10, 2).defaultTo(0);
        table.decimal('aliq_interna', 10, 2).defaultTo(0);
        table.decimal('pauta_icms_st', 15, 2).defaultTo(0);
        table.boolean('ativo').defaultTo(true);
        table.timestamp('dt_inc').defaultTo(weberpConnection.fn.now());
        table.timestamp('dt_alt');
        
        // Índices
        table.index(['cod_produto', 'cod_empresa']);
        table.index(['cod_regra_icms']);
      });
      log('Tabela regras_fiscais_produtos criada com sucesso!');
    } else {
      log('Tabela regras_fiscais_produtos já existe.');
      // Garantir que a coluna cod_produto tenha o tamanho adequado
      try {
        await weberpConnection.schema.alterTable('regras_fiscais_produtos', (table) => {
          table.string('cod_produto', 20).alter();
        });
        log('Coluna cod_produto da tabela regras_fiscais_produtos ajustada com sucesso.');
      } catch (e) {
        log(`Aviso: Não foi possível alterar a coluna cod_produto. Erro: ${e.message}`);
      }
    }
    
    return true;
  } catch (error) {
    log(`ERRO ao ajustar tabelas: ${error.message}`);
    log(error.stack);
    return false;
  }
}

/**
 * Verificar estrutura da tabela regras_fiscais_produtos no banco ERP
 */
async function verificarEstruturaERPTabela() {
  log('=== VERIFICANDO ESTRUTURA DA TABELA ERP ===');
  
  try {
    // Verifica se a tabela regras_fiscais_produtos existe no banco ERP
    const tabelaExiste = await erpConnection.schema.hasTable('regras_fiscais_produtos');
    
    if (!tabelaExiste) {
      log('ERRO: Tabela regras_fiscais_produtos não existe no banco ERP.');
      return false;
    }
    
    log('Tabela regras_fiscais_produtos encontrada no banco ERP.');
    
    // Obter amostra de dados sem usar join
    const amostra = await erpConnection('regras_fiscais_produtos')
      .select('cod_empresa', 'cod_produto', 'cod_regra_icms', 'cod_regra_pis_cofins')
      .limit(5);
    
    log('Amostra de dados da tabela regras_fiscais_produtos:');
    for (const registro of amostra) {
      log(`- Empresa: ${registro.cod_empresa}, Produto: ${registro.cod_produto}, ICMS: ${registro.cod_regra_icms}, PIS/COFINS: ${registro.cod_regra_pis_cofins}`);
    }
    
    // Sucesso na verificação
    return true;
  } catch (error) {
    log(`ERRO ao verificar estrutura da tabela no ERP: ${error.message}`);
    log(error.stack);
    return false;
  }
}

/**
 * Função para importar regras fiscais diretamente do ERP em pequenos lotes
 */
async function importarRegrasFiscaisProdutos() {
  log('=== IMPORTANDO REGRAS FISCAIS DE PRODUTOS ===');
  
  try {
    // Fazendo a importação em lotes menores para evitar sobrecarga
    const paginaSize = 500; // Tamanho de cada página/consulta
    let pagina = 0;
    let totalImportados = 0;
    let totalRegistros = 0;
    let continuar = true;
    
    let inseridos = 0;
    let atualizados = 0;
    let erros = 0;
    
    // Buscar total de registros
    const countResult = await erpConnection('regras_fiscais_produtos').count('* as total').first();
    totalRegistros = parseInt(countResult.total);
    log(`Total de registros no ERP: ${totalRegistros}`);
    
    // Processar em páginas para evitar problemas de memória/conexão
    while (continuar) {
      log(`Buscando página ${pagina + 1} (registros ${pagina * paginaSize} a ${(pagina + 1) * paginaSize - 1})...`);
      
      try {
        // Buscar o lote atual
        const regrasFiscaisERP = await erpConnection('regras_fiscais_produtos')
          .select('cod_empresa', 'cod_produto', 'cod_regra_icms', 'cod_regra_pis_cofins')
          .offset(pagina * paginaSize)
          .limit(paginaSize);
        
        if (!regrasFiscaisERP || regrasFiscaisERP.length === 0) {
          log('Nenhum registro encontrado nesta página. Finalizando importação.');
          continuar = false;
          break;
        }
        
        log(`Processando ${regrasFiscaisERP.length} registros da página ${pagina + 1}...`);
        
        // Processar cada registro
        for (let i = 0; i < regrasFiscaisERP.length; i++) {
          const regra = regrasFiscaisERP[i];
          
          try {
            // Verificar se o registro já existe
            const existe = await weberpConnection('regras_fiscais_produtos')
              .where({
                cod_empresa: regra.cod_empresa,
                cod_produto: String(regra.cod_produto) // Garantir que seja string
              })
              .first();
            
            if (existe) {
              // Atualizar registro existente
              await weberpConnection('regras_fiscais_produtos')
                .where({
                  cod_empresa: regra.cod_empresa,
                  cod_produto: String(regra.cod_produto)
                })
                .update({
                  cod_regra_icms: regra.cod_regra_icms,
                  cod_regra_pis_cofins: regra.cod_regra_pis_cofins,
                  ativo: true,
                  dt_alt: weberpConnection.fn.now()
                });
              atualizados++;
            } else {
              // Inserir novo registro
              await weberpConnection('regras_fiscais_produtos').insert({
                cod_empresa: regra.cod_empresa,
                cod_produto: String(regra.cod_produto),
                cod_regra_icms: regra.cod_regra_icms,
                cod_regra_pis_cofins: regra.cod_regra_pis_cofins,
                ativo: true,
                dt_inc: weberpConnection.fn.now()
              });
              inseridos++;
            }
          } catch (error) {
            log(`ERRO ao processar regra (empresa: ${regra.cod_empresa}, produto: ${regra.cod_produto}): ${error.message}`);
            erros++;
          }
          
          // A cada 50 registros, fazer uma pausa curta para evitar sobrecarga
          if (i % 50 === 0 && i > 0) {
            await delay(100);
          }
        }
        
        totalImportados += regrasFiscaisERP.length;
        log(`Progresso: ${totalImportados}/${totalRegistros} (${Math.round(totalImportados/totalRegistros*100)}%)`);
        
        // Pausa entre páginas para evitar sobrecarga
        await delay(500);
        
        // Próxima página
        pagina++;
        
        // Se já importou todos os registros ou se chegou a um limite razoável, parar
        if (totalImportados >= totalRegistros || pagina > 50) {
          continuar = false;
        }
      } catch (error) {
        log(`ERRO ao processar página ${pagina + 1}: ${error.message}`);
        // Tentar novamente após uma pausa mais longa
        await delay(2000);
        
        // Se falhar muito, desistir
        erros++;
        if (erros > 5) {
          log('Muitos erros consecutivos. Encerrando importação.');
          continuar = false;
        }
      }
    }
    
    log(`Importação concluída! Total: ${totalImportados}/${totalRegistros}`);
    log(`Inseridos: ${inseridos}, Atualizados: ${atualizados}, Erros: ${erros}`);
    return true;
  } catch (error) {
    log(`ERRO na importação: ${error.message}`);
    log(error.stack);
    return false;
  }
}

/**
 * Criar índice de um produto específico (opcional)
 */
async function configurarIndiceFiscal() {
  try {
    log('=== CONFIGURANDO ÍNDICE FISCAL ===');
    
    // Criar um índice para o produto de exemplo "89/C11" para testar
    const produtoTeste = '89/C11';
    
    // Verificar se o produto existe
    const produtoExiste = await weberpConnection('regras_fiscais_produtos')
      .where('cod_produto', produtoTeste)
      .first();
    
    if (!produtoExiste) {
      log(`Produto de teste ${produtoTeste} não encontrado na base.`);
      return false;
    }
    
    log(`Produto de teste ${produtoTeste} encontrado. Código ICMS: ${produtoExiste.cod_regra_icms}, Código PIS/COFINS: ${produtoExiste.cod_regra_pis_cofins}`);
    
    return true;
  } catch (error) {
    log(`ERRO ao configurar índice fiscal: ${error.message}`);
    return false;
  }
}

/**
 * Função principal que executa todo o processo
 */
async function executar() {
  log('=== INICIANDO CORREÇÃO DE REGRAS FISCAIS ===');
  
  try {
    // Verificar conexões com bancos de dados
    try {
      await erpConnection.raw('SELECT 1');
      log('Conexão com o banco do ERP estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco do ERP falhou: ${error.message}`);
      return false;
    }
    
    try {
      await weberpConnection.raw('SELECT 1');
      log('Conexão com o banco local estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco local falhou: ${error.message}`);
      return false;
    }
    
    // Verificar estrutura da tabela no ERP
    const estruturaOk = await verificarEstruturaERPTabela();
    if (!estruturaOk) {
      log('Falha ao verificar estrutura da tabela no ERP!');
      return false;
    }
    
    // Ajustar estrutura das tabelas
    const tabelasAjustadas = await ajustarTabelas();
    if (!tabelasAjustadas) {
      log('Falha ao ajustar tabelas!');
      return false;
    }
    
    // Importar dados do ERP
    const dadosImportados = await importarRegrasFiscaisProdutos();
    
    // Configurar índice fiscal para um produto específico
    const indiceFiscal = await configurarIndiceFiscal();
    
    log('=== PROCESSO FINALIZADO ===');
    log(`Verificação de Estrutura ERP: ${estruturaOk ? 'SUCESSO' : 'FALHA'}`);
    log(`Ajuste de Tabelas: ${tabelasAjustadas ? 'SUCESSO' : 'FALHA'}`);
    log(`Importação de Dados: ${dadosImportados ? 'SUCESSO' : 'FALHA'}`);
    log(`Configuração Índice Fiscal: ${indiceFiscal ? 'SUCESSO' : 'FALHA'}`);
    
    return estruturaOk && tabelasAjustadas && dadosImportados;
  } catch (error) {
    log(`ERRO FATAL: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexões
    try {
      await erpConnection.destroy();
      log('Conexão com o banco do ERP fechada.');
    } catch (e) {
      log(`Erro ao fechar conexão com o ERP: ${e.message}`);
    }
    
    try {
      await weberpConnection.destroy();
      log('Conexão com o banco local fechada.');
    } catch (e) {
      log(`Erro ao fechar conexão com o banco local: ${e.message}`);
    }
  }
}

// Executar o script
executar()
  .then((sucesso) => {
    log(`Script finalizado! Resultado: ${sucesso ? 'SUCESSO' : 'FALHA'}`);
    process.exit(sucesso ? 0 : 1);
  })
  .catch(error => {
    log(`Erro fatal na execução: ${error.message}`);
    process.exit(1);
  }); 