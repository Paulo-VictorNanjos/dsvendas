/**
 * Script para sincronizar todos os componentes fiscais do ERP para o sistema web
 * 
 * Este script executa as seguintes etapas:
 * 1. Cria ou atualiza as tabelas fiscais no banco de dados weberp
 * 2. Sincroniza as regras de ICMS
 * 3. Sincroniza as classificações fiscais (NCM)
 * 4. Sincroniza as regras fiscais dos produtos
 * 5. Gera as regras de cálculo específicas por produto/UF
 */

const knex = require('knex');
const { exec } = require('child_process');
const path = require('path');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para executar um script Node.js
const executeScript = (scriptPath) => {
  return new Promise((resolve, reject) => {
    const fullPath = path.resolve(__dirname, scriptPath);
    log(`Executando script: ${fullPath}`);
    
    const childProcess = exec(`node ${fullPath}`, (error, stdout, stderr) => {
      if (error) {
        log(`Erro ao executar script ${scriptPath}: ${error.message}`);
        return reject(error);
      }
      if (stderr) {
        log(`Aviso ao executar script ${scriptPath}: ${stderr}`);
      }
      log(`Script ${scriptPath} executado com sucesso!`);
      resolve(stdout);
    });
    
    // Redirecionar saída em tempo real para o console
    childProcess.stdout.on('data', (data) => {
      process.stdout.write(data);
    });
    
    childProcess.stderr.on('data', (data) => {
      process.stderr.write(data);
    });
  });
};

// Função principal que executa todos os scripts de sincronização
async function executarSincronizacaoCompleta() {
  log('=== INICIANDO SINCRONIZAÇÃO FISCAL COMPLETA ===');
  
  try {
    // 1. Criar tabelas fiscais
    log('1. Criando/atualizando tabelas fiscais...');
    await executeScript('./criar_tabelas_fiscais_sql.js');
    
    // 2. Sincronizar regras ICMS
    log('2. Sincronizando regras ICMS...');
    await executeScript('./sincronizar_para_weberp.js');
    
    // 3. Sincronizar regras fiscais de produtos
    log('3. Sincronizando regras fiscais de produtos...');
    await executeScript('./sincronizar_regras_fiscais_produtos.js');
    
    // 4. Verificar dados fiscais sincronizados
    log('4. Verificando dados fiscais...');
    await executeScript('./verificar_dados_fiscais.js');
    
    log('=== SINCRONIZAÇÃO FISCAL COMPLETA FINALIZADA COM SUCESSO ===');
    process.exit(0);
  } catch (error) {
    log(`ERRO FATAL durante a sincronização fiscal: ${error.message}`);
    if (error.stack) {
      log(error.stack);
    }
    process.exit(1);
  }
}

// Executar a sincronização completa
executarSincronizacaoCompleta(); 