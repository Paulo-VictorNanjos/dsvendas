/**
 * Script para extrair regras fiscais diretamente do banco ERP e inseri-las no banco local
 * Esta é uma alternativa para contornar o problema de tipos incompatíveis nos JOINs
 */

require('dotenv').config();
const erpConnection = require('../database/erpConnection');
const weberpConnection = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

async function extrairEInserirRegrasFiscais() {
  log('=== INICIANDO EXTRAÇÃO E INSERÇÃO DE REGRAS FISCAIS ===');
  
  try {
    // Verificar conexão com o banco ERP
    try {
      await erpConnection.raw('SELECT 1');
      log('Conexão com o banco do ERP estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco de dados do ERP falhou: ${error.message}`);
      return false;
    }
    
    // Verificar conexão com o banco local
    try {
      await weberpConnection.raw('SELECT 1');
      log('Conexão com o banco local estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco de dados local falhou: ${error.message}`);
      return false;
    }
    
    // Verificar se a tabela regras_fiscais_produtos existe no banco local
    if (!(await weberpConnection.schema.hasTable('regras_fiscais_produtos'))) {
      log('ERRO: Tabela regras_fiscais_produtos não existe no banco local.');
      log('Execute primeiro o script criar_tabelas_fiscais.js e depois adicionar_colunas_regras_fiscais.js');
      return false;
    }
    
    // Extrair regras fiscais diretamente (sem JOIN)
    log('Extraindo regras fiscais diretamente do banco ERP...');
    const regrasFiscais = await erpConnection.raw(`
      SELECT 
        cod_empresa,
        cod_produto,
        cod_regra_icms,
        cod_regra_pis_cofins
      FROM 
        regras_fiscais_produtos
      LIMIT 5000
    `);
    
    if (!regrasFiscais || !regrasFiscais.rows || regrasFiscais.rows.length === 0) {
      log('Nenhuma regra fiscal encontrada no banco do ERP.');
      return false;
    }
    
    log(`Encontradas ${regrasFiscais.rows.length} regras fiscais no ERP.`);
    
    // Limpar tabela local antes de inserir novos dados
    log('Limpando tabela local antes de inserir novos dados...');
    await weberpConnection('regras_fiscais_produtos').del();
    
    // Preparar dados para inserção
    const dadosParaInserir = regrasFiscais.rows.map(regra => ({
      cod_empresa: regra.cod_empresa,
      cod_produto: regra.cod_produto,
      cod_regra_icms: regra.cod_regra_icms || null,
      cod_regra_pis_cofins: regra.cod_regra_pis_cofins || null,
      ativo: true,
      dt_inc: weberpConnection.fn.now()
    }));
    
    // Inserir em lotes menores para melhor performance
    const tamanhoLote = 100;
    let inseridos = 0;
    
    for (let i = 0; i < dadosParaInserir.length; i += tamanhoLote) {
      const loteAtual = dadosParaInserir.slice(i, i + tamanhoLote);
      
      await weberpConnection('regras_fiscais_produtos').insert(loteAtual);
      inseridos += loteAtual.length;
      
      log(`Processado lote ${Math.ceil((i + 1) / tamanhoLote)} de ${Math.ceil(dadosParaInserir.length / tamanhoLote)}`);
    }
    
    log(`Extração e inserção de regras fiscais concluída com sucesso. Total: ${inseridos} regras inseridas.`);
    return true;
  } catch (error) {
    log(`ERRO durante a extração e inserção de regras fiscais: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexões
    await erpConnection.destroy();
    log('Conexão com o banco do ERP fechada.');
    
    await weberpConnection.destroy();
    log('Conexão com o banco local fechada.');
  }
}

// Executar a função
extrairEInserirRegrasFiscais()
  .then(success => {
    if (success) {
      log('Processo concluído com sucesso!');
      process.exit(0);
    } else {
      log('Houve problemas durante o processo.');
      process.exit(1);
    }
  })
  .catch(error => {
    log(`Erro fatal: ${error.message}`);
    process.exit(1);
  }); 