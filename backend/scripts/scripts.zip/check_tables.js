require('dotenv').config();
const knex = require('../database/connection');

async function checkTables() {
  try {
    // Verifica estrutura da tabela produtos
    const produtosColumns = await knex.raw(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'produtos'
    `);
    console.log('Colunas da tabela produtos:', produtosColumns.rows);

    // Verifica estrutura da tabela clientes
    const clientesColumns = await knex.raw(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'clientes'
    `);
    console.log('Colunas da tabela clientes:', clientesColumns.rows);

  } catch (error) {
    console.error('Erro ao verificar tabelas:', error);
  } finally {
    process.exit();
  }
}

checkTables(); 