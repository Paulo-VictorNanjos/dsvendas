/**
 * Script para inspecionar as tabelas fiscais do banco de dados
 * Execute com: node scripts/inspect_fiscal_tables.js
 */
const knex = require('../database/connection');
const fs = require('fs');

// Lista de tabelas para inspecionar
const TABLES = [
  'regras_icms_itens',
  'regras_icms_cadastro',
  'trib_pist_cofins',
  'regras_icms',
  'regras_fiscais_produtos',
  'produtos_pauta_icms_st',
  'icms_aliq_interna',
  'cst_pis_cofins',
  'class_fiscal_fcp',
  'cest',
  'aliq_icms'
];

async function inspectTables() {
  const output = [];
  
  try {
    // Verificar tabelas no banco de dados
    const dbTables = await knex.raw(`
      SELECT tablename 
      FROM pg_catalog.pg_tables 
      WHERE schemaname = 'public'
    `);
    
    const existingTables = dbTables.rows.map(r => r.tablename);
    
    output.push(`=== Tabelas encontradas no banco de dados ===`);
    output.push(existingTables.join(', '));
    output.push('\n');
    
    for (const tableName of TABLES) {
      output.push(`\n=== Tabela: ${tableName} ===`);
      
      if (!existingTables.includes(tableName)) {
        output.push(`Tabela não encontrada no banco de dados.`);
        continue;
      }
      
      // Obter estrutura da tabela
      const columns = await knex(tableName).columnInfo();
      output.push(`\nColunas:`);
      
      for (const [columnName, info] of Object.entries(columns)) {
        output.push(`- ${columnName}: ${info.type} ${info.nullable ? '(nullable)' : '(not null)'}`);
      }
      
      // Contar registros
      const count = await knex(tableName).count('* as total').first();
      output.push(`\nQuantidade de registros: ${count.total}`);
      
      // Listar alguns registros de exemplo se houver
      if (count.total > 0) {
        const samples = await knex(tableName).select('*').limit(3);
        output.push(`\nExemplos de registros:`);
        samples.forEach((sample, index) => {
          output.push(`\nRegistro ${index + 1}:`);
          for (const [key, value] of Object.entries(sample)) {
            output.push(`  ${key}: ${value}`);
          }
        });
      }
    }
    
    // Verificar também a tabela de produtos para ver as colunas fiscais
    output.push(`\n\n=== Tabela: produtos (colunas fiscais) ===`);
    
    const produtosColumns = await knex('produtos').columnInfo();
    const fiscalColumns = Object.entries(produtosColumns)
      .filter(([colName]) => 
        colName.includes('icms') || 
        colName.includes('ipi') || 
        colName.includes('fiscal') || 
        colName.includes('ncm') || 
        colName.includes('cest') || 
        colName.includes('tribut') || 
        colName.includes('origem')
      );
    
    output.push(`\nColunas fiscais em 'produtos':`);
    fiscalColumns.forEach(([colName, info]) => {
      output.push(`- ${colName}: ${info.type} ${info.nullable ? '(nullable)' : '(not null)'}`);
    });
    
    // Escrever resultado em um arquivo
    const outputContent = output.join('\n');
    fs.writeFileSync('fiscal_tables_analysis.txt', outputContent);
    
    console.log("Análise concluída e salva em 'fiscal_tables_analysis.txt'");
    console.log(outputContent);
    
  } catch (error) {
    console.error('Erro ao inspecionar tabelas:', error);
  } finally {
    // Fechar conexão com o banco
    await knex.destroy();
  }
}

// Executar a função principal
inspectTables(); 