// Script para testar a sincronização de formas e condições de pagamento
require('dotenv').config();
const syncService = require('../services/syncService');

async function syncPaymentMethods() {
  console.log('Iniciando sincronização de métodos de pagamento...');
  
  try {
    // Buscar formas de pagamento do ERP
    console.log('\n=== BUSCANDO FORMAS DE PAGAMENTO DO ERP ===');
    const formasPagamento = await syncService.getFormasFromERP();
    console.log(`Formas de pagamento encontradas no ERP: ${formasPagamento.length}`);
    
    if (formasPagamento.length > 0) {
      console.log('Exemplos de formas de pagamento:');
      formasPagamento.slice(0, 3).forEach(forma => 
        console.log(`  - ${forma.codigo}: ${forma.descricao}`)
      );
    } else {
      console.log('Nenhuma forma de pagamento encontrada no ERP!');
    }

    // Buscar condições de pagamento do ERP
    console.log('\n=== BUSCANDO CONDIÇÕES DE PAGAMENTO DO ERP ===');
    const condicoesPagamento = await syncService.getCondPagtoFromERP();
    console.log(`Condições de pagamento encontradas no ERP: ${condicoesPagamento.length}`);
    
    if (condicoesPagamento.length > 0) {
      console.log('Exemplos de condições de pagamento:');
      condicoesPagamento.slice(0, 3).forEach(condicao => 
        console.log(`  - ${condicao.codigo}: ${condicao.descricao} (${condicao.parcelas} parcelas)`)
      );
    } else {
      console.log('Nenhuma condição de pagamento encontrada no ERP!');
    }
    
    // Atualizar métodos de pagamento no banco local
    console.log('\n=== ATUALIZANDO MÉTODOS DE PAGAMENTO NO BANCO LOCAL ===');
    if (formasPagamento.length > 0 || condicoesPagamento.length > 0) {
      await syncService.updatePaymentMethods(formasPagamento, condicoesPagamento);
      console.log('Sincronização concluída com sucesso!');
    } else {
      console.log('Nenhum dado para sincronizar. Verificando dados atuais no banco local...');
      
      // Verificar o que existe no banco local
      const formasLocal = await syncService.getPaymentMethods();
      console.log(`Formas de pagamento no banco local: ${formasLocal.length}`);
      
      const condicoesLocal = await syncService.getPaymentTerms();
      console.log(`Condições de pagamento no banco local: ${condicoesLocal.length}`);
    }
    
    console.log('\nProcesso de sincronização concluído!');
  } catch (error) {
    console.error('Erro durante a sincronização:', error);
  }
}

// Executar a sincronização
syncPaymentMethods()
  .then(() => {
    console.log('Script finalizado.');
    process.exit(0);
  })
  .catch(error => {
    console.error('Erro fatal:', error);
    process.exit(1);
  }); 