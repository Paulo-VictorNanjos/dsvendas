require('dotenv').config();
const knex = require('knex');

console.log('Verificando conexão com o banco de dados...');
console.log('Configuração de conexão:', {
  client: 'pg',
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD ? '******' : 'postgres (padrão)',
  database: process.env.DB_DATABASE || 'dsvendas',
  port: parseInt(process.env.DB_PORT || '5434')
});

// Criar uma conexão temporária
const connection = knex({
  client: 'pg',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    database: process.env.DB_DATABASE || 'dsvendas',
    port: parseInt(process.env.DB_PORT || '5434')
  }
});

// Testar a conexão
connection.raw('SELECT 1')
  .then(() => {
    console.log('Conexão bem-sucedida!');
    
    // Listar tabelas
    return connection.raw("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
  })
  .then((result) => {
    console.log('Tabelas existentes:');
    const tables = result.rows.map(row => row.table_name);
    console.log(tables);
    
    // Verificar se as tabelas específicas existem
    if (tables.includes('formas_pagto')) {
      console.log("Tabela 'formas_pagto' encontrada.");
    } else if (tables.includes('form_pagto')) {
      console.log("Tabela 'form_pagto' encontrada.");
    } else {
      console.log("ATENÇÃO: Tabela de formas de pagamento não encontrada!");
    }
    
    if (tables.includes('cond_pagto')) {
      console.log("Tabela 'cond_pagto' encontrada.");
    } else {
      console.log("ATENÇÃO: Tabela 'cond_pagto' não encontrada!");
    }
    
    return connection.destroy();
  })
  .catch((error) => {
    console.error('Erro ao conectar ao banco de dados:', error);
    connection.destroy();
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  }); 