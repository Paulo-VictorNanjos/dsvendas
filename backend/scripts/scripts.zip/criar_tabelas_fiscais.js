/**
 * Script para criar as tabelas fiscais no banco weberp
 * Este script verifica se as tabelas fiscais existem e, caso não existam, cria-as
 */

require('dotenv').config();
const knex = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para criar tabelas fiscais
async function criarTabelasFiscais() {
  log('=== CRIANDO TABELAS FISCAIS ===');
  
  try {
    // Criar tabela regras_icms se não existir
    if (!(await knex.schema.hasTable('regras_icms'))) {
      log('Criando tabela regras_icms...');
      await knex.schema.createTable('regras_icms', table => {
        table.integer('codigo').notNullable();
        table.string('uf', 2).notNullable();
        table.string('st_icms', 2);
        table.decimal('aliq_icms', 10, 2).defaultTo(0);
        table.decimal('red_icms', 10, 2).defaultTo(0);
        table.integer('cod_convenio').defaultTo(0);
        table.string('st_icms_contr', 2);
        table.decimal('aliq_icms_contr', 10, 2).defaultTo(0);
        table.decimal('red_icms_contr', 10, 2).defaultTo(0);
        table.integer('cod_convenio_contr').defaultTo(0);
        table.string('icms_st', 1).defaultTo('N');
        table.integer('cod_aliquota').defaultTo(0);
        table.decimal('aliq_interna', 10, 2).defaultTo(0);
        table.string('aliq_ecf', 10);
        table.decimal('aliq_dif_icms_contr', 10, 2).defaultTo(0);
        table.decimal('aliq_dif_icms_cons', 10, 2).defaultTo(0);
        table.string('reducao_somente_icms_proprio', 1).defaultTo('N');
        table.string('cod_cbnef', 10);
        table.string('st_icms_contr_reg_sn', 2);
        table.decimal('aliq_icms_contr_reg_sn', 10, 2).defaultTo(0);
        table.decimal('red_icms_contr_reg_sn', 10, 2).defaultTo(0);
        table.decimal('aliq_dif_icms_contr_reg_sn', 10, 2).defaultTo(0);
        table.integer('cod_convenio_contr_reg_sn').defaultTo(0);
        table.string('icms_st_reg_sn', 1).defaultTo('N');
        table.timestamps(true, true);
        
        // Chave primária composta
        table.primary(['codigo', 'uf']);
      });
      log('Tabela regras_icms criada com sucesso!');
    } else {
      log('Tabela regras_icms já existe.');
    }
    
    // Criar tabela class_fiscal_dados se não existir
    if (!(await knex.schema.hasTable('class_fiscal_dados'))) {
      log('Criando tabela class_fiscal_dados...');
      await knex.schema.createTable('class_fiscal_dados', table => {
        table.integer('cod_class_fiscal').notNullable();
        table.string('cod_ncm', 10);
        table.string('uf', 2).notNullable();
        table.decimal('aliq_fcp', 10, 2).defaultTo(0);
        table.decimal('aliq_fcpst', 10, 2).defaultTo(0);
        table.decimal('aliq_pst', 10, 2).defaultTo(0);
        table.decimal('iva', 10, 2).defaultTo(0);
        table.decimal('aliq_interna', 10, 2).defaultTo(0);
        table.decimal('iva_diferenciado', 10, 2).defaultTo(0);
        table.string('cest', 10);
        table.decimal('iva_importado', 10, 2).defaultTo(0);
        table.decimal('aliq_importado', 10, 2).defaultTo(0);
        table.timestamps(true, true);
        
        // Chave primária composta
        table.primary(['cod_class_fiscal', 'uf']);
      });
      log('Tabela class_fiscal_dados criada com sucesso!');
    } else {
      log('Tabela class_fiscal_dados já existe.');
    }
    
    // Verificar e criar tabela regras_fiscais_produtos (tabela principal de vínculo)
    if (!(await knex.schema.hasTable('regras_fiscais_produtos'))) {
      log('Criando tabela regras_fiscais_produtos...');
      await knex.schema.createTable('regras_fiscais_produtos', table => {
        table.increments('id').primary();
        table.integer('cod_empresa').notNullable();
        table.string('cod_produto').notNullable();
        table.integer('cod_regra_icms');
        table.integer('cod_regra_pis_cofins');
        table.string('class_fiscal', 10);
        table.string('cest', 10);
        table.string('ncm', 10);
        table.string('cod_origem_prod', 1);
        table.decimal('iva', 10, 2).defaultTo(0);
        table.decimal('aliq_interna', 10, 2).defaultTo(0);
        table.decimal('pauta_icms_st', 15, 2).defaultTo(0);
        table.boolean('ativo').defaultTo(true);
        table.timestamp('dt_inc').defaultTo(knex.fn.now());
        table.timestamp('dt_alt');
        
        // Índices
        table.index(['cod_produto', 'cod_empresa']);
        table.index(['cod_regra_icms']);
      });
      log('Tabela regras_fiscais_produtos criada com sucesso!');
    } else {
      log('Tabela regras_fiscais_produtos já existe.');
    }
    
    // Verificar e criar tabela regras_fiscais_produto
    if (!(await knex.schema.hasTable('regras_fiscais_produto'))) {
      log('Criando tabela regras_fiscais_produto...');
      await knex.schema.createTable('regras_fiscais_produto', table => {
        table.increments('id').primary();
        table.string('codigo_produto').notNullable();
        table.string('uf', 2).notNullable();
        table.string('cst_icms', 2);
        table.decimal('aliq_icms', 10, 2).defaultTo(0);
        table.decimal('red_bc_icms', 10, 2).defaultTo(0);
        table.decimal('aliq_ipi', 10, 2).defaultTo(0);
        table.decimal('aliq_pis', 10, 2).defaultTo(0);
        table.decimal('aliq_cofins', 10, 2).defaultTo(0);
        table.string('cst_pis', 2);
        table.string('cst_cofins', 2);
        table.string('cfop', 4);
        table.decimal('margem_st', 10, 2).defaultTo(0);
        table.decimal('aliq_icms_st', 10, 2).defaultTo(0);
        table.decimal('mvast', 10, 2).defaultTo(0);
        table.decimal('preco_pauta', 10, 2).defaultTo(0);
        table.string('codigo_ncm', 10);
        table.decimal('aliq_fcpst', 10, 2).defaultTo(0);
        table.timestamps(true, true);
        
        // Índices
        table.index(['codigo_produto', 'uf']);
      });
      log('Tabela regras_fiscais_produto criada com sucesso!');
    } else {
      log('Tabela regras_fiscais_produto já existe.');
    }
    
    log('=== CRIAÇÃO DE TABELAS FISCAIS FINALIZADA ===');
    return true;
  } catch (error) {
    log(`ERRO durante a criação das tabelas fiscais: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexão com o banco de dados
    await knex.destroy();
  }
}

// Executar a função
criarTabelasFiscais()
  .then(success => {
    if (success) {
      log('Todas as tabelas foram criadas com sucesso!');
      process.exit(0);
    } else {
      log('Houve problemas na criação das tabelas.');
      process.exit(1);
    }
  })
  .catch(error => {
    log(`Erro fatal: ${error.message}`);
    process.exit(1);
  }); 