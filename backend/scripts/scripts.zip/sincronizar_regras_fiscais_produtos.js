/**
 * Script para sincronizar regras fiscais de produtos entre o banco do ERP e o banco weberp
 */

require('dotenv').config();

// Conexão com o banco de dados do ERP
const erpConnection = require('../database/erpConnection');

// Conexão com o banco de dados local (dsvendas)
const weberpConnection = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

/**
 * Sincroniza regras fiscais de produtos
 */
async function sincronizarRegrasFiscaisProdutos() {
  log('Iniciando sincronização de regras fiscais de produtos...');
  
  try {
    // Verificar se temos conexão com o banco de dados do ERP
    try {
      await erpConnection.raw('SELECT 1');
      log('Conexão com o banco do ERP estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco de dados do ERP falhou: ${error.message}`);
      return false;
    }
    
    // Verificar se temos conexão com o banco de dados local
    try {
      await weberpConnection.raw('SELECT 1');
      log('Conexão com o banco local estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco de dados local falhou: ${error.message}`);
      return false;
    }
    
    // Verificar se a tabela regras_fiscais_produtos existe no banco local
    if (!(await weberpConnection.schema.hasTable('regras_fiscais_produtos'))) {
      log('ERRO: Tabela regras_fiscais_produtos não existe no banco local.');
      log('Execute primeiro o script criar_tabelas_fiscais.js e depois adicionar_colunas_regras_fiscais.js');
      return false;
    }
    
    // Verificar se a tabela regras_fiscais_produtos tem a coluna cod_regra_pis_cofins
    const colunas = await weberpConnection.raw(
      "SELECT column_name FROM information_schema.columns WHERE table_name = 'regras_fiscais_produtos'"
    );
    
    const colunasExistentes = colunas.rows.map(row => row.column_name);
    if (!colunasExistentes.includes('cod_regra_pis_cofins')) {
      log('ERRO: Coluna cod_regra_pis_cofins não existe na tabela regras_fiscais_produtos.');
      log('Execute o script adicionar_colunas_regras_fiscais.js');
      return false;
    }
    
    // Buscar todas as regras fiscais de produtos do ERP
    log('Consultando regras fiscais de produtos no ERP...');
    const regrasFiscaisProdutosERP = await erpConnection.raw(`
      SELECT 
        rfp.cod_empresa,
        rfp.cod_produto,
        rfp.cod_regra_icms,
        rfp.cod_regra_pis_cofins,
        p.class_fiscal,
        p.cod_origem_prod,
        p.cest,
        cf.cod_ncm,
        cf.descricao as ncm_descricao
      FROM 
        regras_fiscais_produtos rfp
      LEFT JOIN 
        produtos p ON CAST(rfp.cod_produto AS VARCHAR) = CAST(p.codigo AS VARCHAR) AND rfp.cod_empresa = p.cod_empresa
      LEFT JOIN 
        class_fiscal cf ON p.class_fiscal = cf.codigo
      WHERE 
        p.dt_exc IS NULL
    `);
    
    if (!regrasFiscaisProdutosERP || !regrasFiscaisProdutosERP.rows || regrasFiscaisProdutosERP.rows.length === 0) {
      log('Nenhuma regra fiscal de produto encontrada no banco do ERP.');
      return false;
    }
    
    log(`Encontradas ${regrasFiscaisProdutosERP.rows.length} regras fiscais de produtos no ERP.`);
    
    // Preparar dados para inserção/atualização
    const dadosParaInserir = regrasFiscaisProdutosERP.rows.map(regra => ({
      cod_empresa: regra.cod_empresa,
      cod_produto: regra.cod_produto,
      cod_regra_icms: regra.cod_regra_icms || null,
      cod_regra_pis_cofins: regra.cod_regra_pis_cofins || null,
      class_fiscal: regra.class_fiscal || null,
      cod_origem_prod: regra.cod_origem_prod || null,
      cest: regra.cest || null,
      ncm: regra.cod_ncm || null,
      ativo: true
    }));
    
    // Inserir em lotes menores para melhor performance
    const tamanhoLote = 100;
    let inseridos = 0;
    let atualizados = 0;
    
    for (let i = 0; i < dadosParaInserir.length; i += tamanhoLote) {
      const loteAtual = dadosParaInserir.slice(i, i + tamanhoLote);
      
      // Processar cada item individualmente para registrar estatísticas
      for (const item of loteAtual) {
        try {
          if (!item.cod_produto) {
            log(`Pulando registro com código de produto vazio (empresa: ${item.cod_empresa})`);
            continue;
          }
          
          // Verificar se já existe o registro
          const existente = await weberpConnection('regras_fiscais_produtos')
            .where({
              cod_empresa: item.cod_empresa,
              cod_produto: item.cod_produto
            })
            .first();
            
          if (existente) {
            // Atualizar registro existente
            await weberpConnection('regras_fiscais_produtos')
              .where({
                cod_empresa: item.cod_empresa,
                cod_produto: item.cod_produto
              })
              .update({
                cod_regra_icms: item.cod_regra_icms,
                cod_regra_pis_cofins: item.cod_regra_pis_cofins,
                class_fiscal: item.class_fiscal,
                cest: item.cest,
                ncm: item.ncm,
                cod_origem_prod: item.cod_origem_prod,
                ativo: true,
                dt_alt: weberpConnection.fn.now()
              });
            atualizados++;
          } else {
            // Inserir novo registro com dt_inc
            await weberpConnection('regras_fiscais_produtos').insert({
              cod_empresa: item.cod_empresa,
              cod_produto: item.cod_produto,
              cod_regra_icms: item.cod_regra_icms,
              cod_regra_pis_cofins: item.cod_regra_pis_cofins,
              class_fiscal: item.class_fiscal,
              cest: item.cest,
              ncm: item.ncm,
              cod_origem_prod: item.cod_origem_prod,
              ativo: true,
              dt_inc: weberpConnection.fn.now()
            });
            inseridos++;
          }
        } catch (error) {
          log(`ERRO ao processar regra fiscal de produto (empresa: ${item.cod_empresa}, produto: ${item.cod_produto}): ${error.message}`);
        }
      }
      
      log(`Processado lote ${Math.ceil((i + 1) / tamanhoLote)} de ${Math.ceil(dadosParaInserir.length / tamanhoLote)}`);
    }
    
    log(`Sincronização de regras fiscais de produtos concluída com sucesso. Total: ${inseridos} inseridas, ${atualizados} atualizadas.`);
    return true;
  } catch (error) {
    log(`ERRO durante a sincronização de regras fiscais de produtos: ${error.message}`);
    log(error.stack);
    return false;
  }
}

/**
 * Função para sincronizar regras de cálculo fiscal específicas por produto e UF
 * baseadas nas regras gerais do ICMS e PIS/COFINS
 */
async function sincronizarRegrasFiscaisCalculoProduto() {
  log('Iniciando sincronização de regras fiscais de cálculo por produto/UF...');
  
  try {
    // Verificar se a tabela regras_fiscais_produto existe no banco weberp
    if (!(await weberpConnection.schema.hasTable('regras_fiscais_produto'))) {
      log('ERRO: Tabela regras_fiscais_produto não existe no banco weberp.');
      log('Execute primeiro o script criar_tabelas_fiscais.js');
      return false;
    }
    
    // Obtém lista de UFs para processamento
    const ufs = await weberpConnection.raw(`
      SELECT DISTINCT uf FROM regras_icms ORDER BY uf
    `);
    
    if (!ufs || !ufs.rows || ufs.rows.length === 0) {
      log('Nenhuma UF encontrada para sincronização.');
      return false;
    }
    
    log(`Encontradas ${ufs.rows.length} UFs para processamento.`);
    const listaUFs = ufs.rows.map(row => row.uf);
    
    // Para cada produto com regra fiscal, gera regras específicas por UF
    const produtos = await weberpConnection('regras_fiscais_produtos')
      .select('cod_produto', 'cod_regra_icms', 'cod_regra_pis_cofins', 'ncm')
      .where('ativo', true)
      .limit(5000); // Processa em lotes para evitar sobrecarga
    
    log(`Processando ${produtos.length} produtos...`);
    
    let processados = 0;
    let inseridos = 0;
    let atualizados = 0;
    
    for (const produto of produtos) {
      processados++;
      
      // Para cada UF, gera uma regra de cálculo específica
      for (const uf of listaUFs) {
        try {
          // Busca informações de ICMS para esta regra e UF
          const regraICMS = await weberpConnection('regras_icms')
            .where({ codigo: produto.cod_regra_icms, uf: uf })
            .first();
          
          if (!regraICMS) {
            // log(`Regra de ICMS não encontrada para produto ${produto.cod_produto}, regra ${produto.cod_regra_icms}, UF ${uf}`);
            continue;
          }
          
          // Busca informações de PIS/COFINS
          let aliqPis = 1.65;
          let aliqCofins = 7.60;
          let cstPis = '01';
          let cstCofins = '01';
          
          if (produto.cod_regra_pis_cofins) {
            // Para implementação futura: buscar alíquotas e CSTs específicos de PIS/COFINS
            // const regraPisCofins = await weberpConnection.raw(`...`);
          }
          
          // Determina a CST de ICMS e valores de acordo com o tipo de contribuinte
          const cstIcms = regraICMS.st_icms_contr || '00';
          const aliqIcms = regraICMS.aliq_icms_contr || 0;
          const redBcIcms = regraICMS.red_icms_contr || 0;
          
          // Verifica se já existe uma regra para este produto/UF
          const regraExistente = await weberpConnection('regras_fiscais_produto')
            .where({
              codigo_produto: produto.cod_produto,
              uf: uf
            })
            .first();
            
          const dadosRegra = {
            codigo_produto: produto.cod_produto,
            uf: uf,
            cst_icms: cstIcms,
            aliq_icms: aliqIcms,
            red_bc_icms: redBcIcms,
            aliq_pis: aliqPis,
            aliq_cofins: aliqCofins,
            cst_pis: cstPis,
            cst_cofins: cstCofins,
            codigo_ncm: produto.ncm,
            // Campos específicos de ST conforme disponíveis na regra
            margem_st: regraICMS.icms_st === 'S' ? 30.00 : 0, // Valor padrão ou conforme disponível
            aliq_icms_st: regraICMS.aliq_interna || 0,
            mvast: 0, // Valor a ser calculado ou obtido de outra tabela
            updated_at: weberpConnection.fn.now()
          };
          
          if (regraExistente) {
            // Atualiza regra existente
            await weberpConnection('regras_fiscais_produto')
              .where({
                codigo_produto: produto.cod_produto,
                uf: uf
              })
              .update(dadosRegra);
            atualizados++;
          } else {
            // Insere nova regra
            dadosRegra.created_at = weberpConnection.fn.now();
            await weberpConnection('regras_fiscais_produto').insert(dadosRegra);
            inseridos++;
          }
        } catch (error) {
          log(`ERRO ao processar regra fiscal para produto ${produto.cod_produto}, UF ${uf}: ${error.message}`);
        }
      }
      
      if (processados % 100 === 0) {
        log(`Progresso: ${processados}/${produtos.length} produtos processados.`);
      }
    }
    
    log(`Sincronização de regras fiscais de cálculo concluída com sucesso.`);
    log(`Total: ${processados} produtos processados, ${inseridos} regras inseridas, ${atualizados} regras atualizadas.`);
    return true;
  } catch (error) {
    log(`ERRO durante a sincronização de regras fiscais de cálculo: ${error.message}`);
    log(error.stack);
    return false;
  }
}

// Função principal para sincronizar todas as regras fiscais
async function executarSincronizacao() {
  log('=== INICIANDO SINCRONIZAÇÃO DE REGRAS FISCAIS DE PRODUTOS ===');
  
  try {
    // Sincronizar regras fiscais de produtos
    const sucessoRegrasFiscaisProdutos = await sincronizarRegrasFiscaisProdutos();
    
    // Sincronizar regras de cálculo específicas por produto/UF
    const sucessoRegrasFiscaisCalculo = await sincronizarRegrasFiscaisCalculoProduto();
    
    log('=== SINCRONIZAÇÃO FINALIZADA ===');
    log(`Regras Fiscais de Produtos: ${sucessoRegrasFiscaisProdutos ? 'SUCESSO' : 'FALHA'}`);
    log(`Regras Fiscais de Cálculo: ${sucessoRegrasFiscaisCalculo ? 'SUCESSO' : 'FALHA'}`);
    
    // Fechar conexões
    await erpConnection.destroy();
    log('Conexão com o banco do ERP fechada.');
    
    await weberpConnection.destroy();
    log('Conexão com o banco weberp fechada.');
    
    // Saindo com código de sucesso ou erro
    process.exit(sucessoRegrasFiscaisProdutos && sucessoRegrasFiscaisCalculo ? 0 : 1);
  } catch (error) {
    log(`ERRO FATAL durante a sincronização: ${error.message}`);
    log(error.stack);
    
    // Fechar conexões mesmo em caso de erro
    await erpConnection.destroy();
    await weberpConnection.destroy();
    
    process.exit(1);
  }
}

// Executar sincronização
executarSincronizacao(); 