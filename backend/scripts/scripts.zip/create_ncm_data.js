/**
 * Script para adicionar dados fiscais para NCMs
 * Este script adiciona registros na tabela class_fiscal_dados para resolver
 * o problema do cálculo de ICMS para produtos importados
 * 
 * Execute com: node scripts/create_ncm_data.js
 */

const knex = require('../database/connection');

// Lista de estados brasileiros
const estados = [
  { uf: 'AC', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'AL', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'AM', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'AP', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'BA', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'CE', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'DF', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'ES', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'GO', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'MA', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'MG', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'MS', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'MT', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'PA', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'PB', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'PE', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'PI', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'PR', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'RJ', aliq_interna: 20, aliq_importado: 27 }, // RJ tem alíquota maior
  { uf: 'RN', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'RO', aliq_interna: 17.5, aliq_importado: 24.5 },
  { uf: 'RR', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'RS', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'SC', aliq_interna: 17, aliq_importado: 24 },
  { uf: 'SE', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'SP', aliq_interna: 18, aliq_importado: 25 },
  { uf: 'TO', aliq_interna: 18, aliq_importado: 25 }
];

async function createNCMdata() {
  try {
    console.log('Adicionando dados fiscais para NCMs...');

    // 0. Verificar estrutura da tabela
    console.log('Verificando estrutura da tabela class_fiscal_dados...');
    const tableInfo = await knex('class_fiscal_dados').columnInfo();
    console.log('Colunas da tabela:', Object.keys(tableInfo));
    
    // Verificar se a tabela tem a coluna cod_class_fiscal
    const hasCodClassFiscal = Object.keys(tableInfo).includes('cod_class_fiscal');
    console.log(`Tabela possui coluna cod_class_fiscal: ${hasCodClassFiscal}`);

    // 1. Obter os NCMs dos produtos no sistema que não têm registros na tabela class_fiscal_dados
    const produtos = await knex('produtos')
      .select('class_fiscal')
      .whereNotNull('class_fiscal')
      .groupBy('class_fiscal');
    
    const ncms = produtos.map(p => p.class_fiscal);
    console.log(`Encontrados ${ncms.length} códigos NCM distintos nos produtos.`);

    // 2. Verificar quais NCMs já existem na tabela class_fiscal_dados
    const ncmsExistentes = await knex('class_fiscal_dados')
      .select('cod_ncm')
      .whereIn('cod_ncm', ncms)
      .groupBy('cod_ncm');
    
    const ncmsExistentesArray = ncmsExistentes.map(n => n.cod_ncm);
    console.log(`Destes, ${ncmsExistentesArray.length} NCMs já possuem dados fiscais.`);

    // 3. Filtrar NCMs que precisam ser adicionados
    const ncmsFaltantes = ncms.filter(ncm => !ncmsExistentesArray.includes(ncm));
    console.log(`Serão adicionados dados fiscais para ${ncmsFaltantes.length} NCMs.`);

    // Verificar se há NCMs faltantes
    if (ncmsFaltantes.length === 0) {
      console.log('Não há NCMs faltantes para adicionar. Verificando dados para produtos importados...');
    }

    // 4. Adicionar registros especiais para os dois produtos de teste
    const ncmsTeste = ['85444900', '85369010']; // NCMs dos produtos testados
    
    // 5. Para cada NCM faltante, criar registros para todos os estados
    const registros = [];
    
    // Função para gerar um valor numérico para o cod_class_fiscal
    const generateClassFiscalCode = (ncm) => {
      // Simplesmente converte o NCM para um número e adiciona um prefixo
      try {
        return 9000000 + parseInt(ncm.replace(/\D/g, ''));
      } catch (e) {
        return 9999999; // Valor padrão se não conseguir converter
      }
    };

    for (const ncm of [...ncmsFaltantes, ...ncmsTeste]) {
      for (const estado of estados) {
        const record = {
          cod_ncm: ncm,
          uf: estado.uf,
          aliq_fcp: 0.00,
          aliq_fcpst: 0.00,
          aliq_pst: 0.00,
          iva: 40.00, // IVA padrão
          aliq_interna: estado.aliq_interna,
          iva_diferenciado: 0.00,
          cest: '',
          iva_importado: 60.00, // IVA maior para produtos importados
          aliq_importado: estado.aliq_importado, // Alíquota diferenciada para importados
          created_at: knex.fn.now(),
          updated_at: knex.fn.now()
        };
        
        // Adicionar cod_class_fiscal se a coluna existir
        if (hasCodClassFiscal) {
          record.cod_class_fiscal = generateClassFiscalCode(ncm);
        }
        
        registros.push(record);
      }
    }

    // 6. Inserir em lotes para evitar problemas de performance
    if (registros.length > 0) {
      // Remover registros existentes para NCMs de teste para evitar duplicidades
      console.log(`Removendo registros existentes para NCMs de teste: ${ncmsTeste.join(', ')}`);
      await knex('class_fiscal_dados')
        .whereIn('cod_ncm', ncmsTeste)
        .delete();
      
      console.log(`Inserindo ${registros.length} registros na tabela class_fiscal_dados...`);
      
      // Inserir em lotes menores para evitar problemas com o número de parâmetros
      const BATCH_SIZE = 10;
      for (let i = 0; i < registros.length; i += BATCH_SIZE) {
        const batch = registros.slice(i, i + BATCH_SIZE);
        await knex('class_fiscal_dados').insert(batch);
        console.log(`Inseridos ${Math.min(i + BATCH_SIZE, registros.length)} de ${registros.length} registros...`);
      }
      
      console.log('Registros inseridos com sucesso!');
    }

    // 7. Verificar se os registros foram inseridos corretamente
    const countAfter = await knex('class_fiscal_dados').count('* as count').first();
    console.log(`Total de registros na tabela class_fiscal_dados: ${countAfter.count}`);

    // 8. Verificar especificamente os NCMs dos produtos de teste
    for (const ncm of ncmsTeste) {
      const count = await knex('class_fiscal_dados')
        .where('cod_ncm', ncm)
        .count('* as count')
        .first();
      
      console.log(`Registros para NCM ${ncm}: ${count.count}`);
      
      // Exibir alguns exemplos
      const exemplos = await knex('class_fiscal_dados')
        .where('cod_ncm', ncm)
        .select('uf', 'aliq_interna', 'aliq_importado')
        .limit(3);
      
      console.log(`Exemplos para NCM ${ncm}:`, exemplos);
    }

    console.log('Script concluído com sucesso!');
  } catch (error) {
    console.error('Erro:', error);
  } finally {
    await knex.destroy();
  }
}

// Executar o script
createNCMdata(); 