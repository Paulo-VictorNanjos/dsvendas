/**
 * Script para testar o cálculo de ICMS-ST no backend
 * 
 * Este script implementa a mesma lógica utilizada no frontend para validar
 * o cálculo de ICMS-ST em diferentes cenários
 * 
 * Uso:
 * node scripts/testar_calculo_st.js
 */

// Função para calcular o ICMS-ST
function calcularIcmsST(params) {
  const {
    valorBruto,
    valorIpi = 0,
    aliqIcms = 0,
    aliqInterna = 0,
    iva = 0,
    redIcms = 0,
    aliqFcpSt = 0,
    temReducaoIcmsProprio = false
  } = params;

  // Calcular base de ICMS com redução (se houver)
  const baseIcms = redIcms > 0 
    ? valorBruto * (1 - (redIcms / 100)) 
    : valorBruto;

  // Calcular ICMS próprio
  const valorIcms = baseIcms * (aliqIcms / 100);
  
  // Calcular base ICMS-ST
  // Se a redução for apenas para ICMS próprio, a base do ST usa o valor bruto
  const valorBase = temReducaoIcmsProprio ? valorBruto : baseIcms;
  // Base ST = (valorBase + IPI) * (1 + IVA/100)
  const baseIcmsSt = ((valorBase + valorIpi) * (1 + (iva / 100)));
  
  // Calcular ICMS-ST: (Base ST * Alíquota Interna) - ICMS próprio
  let valorIcmsSt = (baseIcmsSt * (aliqInterna / 100)) - valorIcms;
  
  // Se o valor for negativo, definir como zero
  if (valorIcmsSt < 0) valorIcmsSt = 0;
  
  // Calcular FCP-ST se aplicável
  const valorFcpSt = aliqFcpSt > 0 ? baseIcmsSt * (aliqFcpSt / 100) : 0;
  
  return {
    baseIcms,
    baseIcmsSt,
    valorIcms,
    valorIcmsSt,
    valorFcpSt,
    valorTotalSt: valorIcmsSt + valorFcpSt
  };
}

// Função para formatar valor monetário
const formatarValor = (valor) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(valor);
};

// Função para formatar porcentagem
const formatarPorcentagem = (valor) => {
  return `${valor.toFixed(2)}%`;
};

// Cenários de teste
const cenarios = [
  {
    nome: "Produto padrão com ST",
    valorBruto: 1000,
    valorIpi: 50,
    aliqIcms: 12,
    aliqInterna: 18,
    iva: 40,
    redIcms: 0,
    aliqFcpSt: 2,
    temReducaoIcmsProprio: false
  },
  {
    nome: "Produto com ST e redução de BC",
    valorBruto: 1000,
    valorIpi: 50,
    aliqIcms: 12,
    aliqInterna: 18,
    iva: 40,
    redIcms: 20,
    aliqFcpSt: 2,
    temReducaoIcmsProprio: false
  },
  {
    nome: "Produto com redução somente no ICMS próprio",
    valorBruto: 1000,
    valorIpi: 50,
    aliqIcms: 12,
    aliqInterna: 18,
    iva: 40,
    redIcms: 20,
    aliqFcpSt: 2,
    temReducaoIcmsProprio: true
  },
  {
    nome: "Produto com IVA elevado",
    valorBruto: 1000,
    valorIpi: 50,
    aliqIcms: 12,
    aliqInterna: 18,
    iva: 100,
    redIcms: 0,
    aliqFcpSt: 2,
    temReducaoIcmsProprio: false
  },
  {
    nome: "Produto sem ST - Mesmo estado",
    valorBruto: 1000,
    valorIpi: 50,
    aliqIcms: 18,
    aliqInterna: 18,
    iva: 0,
    redIcms: 0,
    aliqFcpSt: 0,
    temReducaoIcmsProprio: false
  }
];

// Executar testes
console.log("\n==== TESTES DE CÁLCULO DE ICMS-ST (BACKEND) ====\n");

cenarios.forEach((cenario, index) => {
  console.log(`\n[Cenário ${index + 1}] ${cenario.nome}\n`);
  console.log("Parâmetros:");
  console.log(`  Valor Bruto: ${formatarValor(cenario.valorBruto)}`);
  console.log(`  Valor IPI: ${formatarValor(cenario.valorIpi)}`);
  console.log(`  Alíquota ICMS: ${formatarPorcentagem(cenario.aliqIcms)}`);
  console.log(`  Alíquota Interna: ${formatarPorcentagem(cenario.aliqInterna)}`);
  console.log(`  IVA (MVA): ${formatarPorcentagem(cenario.iva)}`);
  console.log(`  Redução BC: ${formatarPorcentagem(cenario.redIcms)}`);
  console.log(`  Alíquota FCP-ST: ${formatarPorcentagem(cenario.aliqFcpSt)}`);
  console.log(`  Redução somente ICMS próprio: ${cenario.temReducaoIcmsProprio ? 'Sim' : 'Não'}`);
  
  // Calcular ST
  const resultado = calcularIcmsST(cenario);
  
  console.log("\nResultados:");
  console.log(`  Base ICMS: ${formatarValor(resultado.baseIcms)}`);
  console.log(`  Valor ICMS: ${formatarValor(resultado.valorIcms)}`);
  console.log(`  Base ICMS-ST: ${formatarValor(resultado.baseIcmsSt)}`);
  console.log(`  Valor ICMS-ST: ${formatarValor(resultado.valorIcmsSt)}`);
  console.log(`  Valor FCP-ST: ${formatarValor(resultado.valorFcpSt)}`);
  console.log(`  TOTAL ST: ${formatarValor(resultado.valorTotalSt)}`);
  
  // Imposto total
  const impostoTotal = resultado.valorIcms + resultado.valorIcmsSt + resultado.valorFcpSt;
  const percentualEfetivo = (impostoTotal / cenario.valorBruto) * 100;
  
  console.log(`\n  Imposto Total: ${formatarValor(impostoTotal)} (${formatarPorcentagem(percentualEfetivo)} do valor bruto)`);
});

console.log("\n==== FIM DOS TESTES ====\n"); 