# Solução para Sincronização de Regras Fiscais

## Problema Identificado

Durante a implementação do sistema de sincronização de regras fiscais entre o banco de dados ERP (DS ERP) e o sistema web, foram encontrados os seguintes problemas:

1. **Incompatibilidade de tipos de dados**: Na consulta de JOIN entre `regras_fiscais_produtos` e `produtos`, estava ocorrendo um erro de tipos incompatíveis entre `character varying` e `integer` nas colunas usadas para junção.

2. **Problemas com códigos complexos**: Alguns produtos possuem códigos como `89/C11` que não são facilmente manipuláveis sem ajustes no esquema da tabela.

## Solução Implementada

### 1. Verificação da Estrutura do Banco ERP

Criamos um script (`verifica_colunas_erp.js`) para analisar a estrutura da tabela `regras_fiscais_produtos` no banco ERP e identificar os tipos de dados de cada coluna:

```
- cod_empresa: integer
- cod_regra_icms: integer
- cod_regra_pis_cofins: integer
- cod_produto: character varying
```

### 2. Abordagem de Sincronização Simplificada

Como a consulta complexa com JOINs estava gerando erros de tipo, desenvolvemos um script (`adaptar_consulta_regras_fiscais.js`) que:

1. Extrai diretamente os dados da tabela `regras_fiscais_produtos` do ERP sem usar JOINs
2. Limpa a tabela local antes de inserir os novos dados
3. Insere os dados em lotes para melhorar a performance

Este script foi executado com sucesso e transferiu 4410 regras fiscais do banco ERP para o banco local.

### 3. Ajuste das Tabelas Locais

Implementamos scripts para ajustar a estrutura das tabelas locais:

1. `criar_tabelas_fiscais.js` - Cria as tabelas necessárias se não existirem
2. `adicionar_colunas_regras_fiscais.js` - Adiciona colunas necessárias como `cod_regra_pis_cofins` e `ncm`
3. `criar_tabelas_regras_fiscais_produto.js` - Cria uma tabela para regras fiscais de produtos com tamanho adequado para códigos complexos

### 4. Script de Correção Completa

Foi implementado um script abrangente (`fix_erp_regras_fiscais.js`) que realiza:

1. Verificação da estrutura do banco ERP
2. Ajuste das tabelas locais para receberem os dados
3. Importação em lotes das regras fiscais
4. Validação dos dados importados

Este script foi executado com sucesso, importando todas as 4410 regras fiscais do ERP para o sistema web.

## Verificação de Funcionamento

A importação foi verificada confirmando que:

1. As regras fiscais foram inseridas corretamente na tabela `regras_fiscais_produtos`
2. Os códigos complexos como `89/C11` foram importados corretamente
3. As colunas `cod_regra_icms` e `cod_regra_pis_cofins` estão presentes e com os valores corretos

## Como Executar a Sincronização

Para executar a sincronização completa, siga um destes métodos:

### Método 1: Executar via Interface Web

Acesse a interface de sincronização na aplicação web (disponível para administradores) e selecione "Sincronizar Regras Fiscais".

### Método 2: Executar via Scripts (recomendado para resolução de problemas)

Execute os scripts na seguinte ordem:

1. `node scripts/criar_tabelas_fiscais.js` - Cria as tabelas necessárias
2. `node scripts/adicionar_colunas_regras_fiscais.js` - Adiciona colunas necessárias
3. `node scripts/adaptar_consulta_regras_fiscais.js` - Importa as regras fiscais do ERP
4. `node scripts/sincronizar_regras_fiscais_produtos.js` - Sincroniza as regras de cálculo

Ou, execute o script de correção completa:

```
node scripts/fix_erp_regras_fiscais.js
```

## Problemas Resolvidos

1. ✅ Erro de incompatibilidade de tipos nos JOINs
2. ✅ Suporte para códigos de produtos complexos como `89/C11`
3. ✅ Sincronização das colunas `cod_regra_icms` e `cod_regra_pis_cofins`
4. ✅ Importação completa de 4410 regras fiscais do banco ERP

## Próximos Passos

1. Monitorar a sincronização para garantir que continue funcionando corretamente
2. Implementar verificações adicionais para validar as regras fiscais importadas
3. Considerar a implementação de um sistema de log mais detalhado para rastrear mudanças nas regras fiscais 