/**
 * Script para criar a tabela regras_fiscais_produto no banco dsvendas
 * Este script verifica se a tabela já existe e, caso contrário, cria-a com as colunas necessárias
 */

require('dotenv').config();
const knex = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para criar tabela regras_fiscais_produto
async function criarTabelaRegrasFiscaisProduto() {
  log('=== CRIANDO TABELA REGRAS_FISCAIS_PRODUTO ===');
  
  try {
    // Verificar se a tabela já existe
    const existeTabela = await knex.schema.hasTable('regras_fiscais_produto');
    
    if (existeTabela) {
      log('Tabela regras_fiscais_produto já existe. Verificando tamanho das colunas...');
      
      // Verificar se é necessário alterar o tamanho das colunas
      await knex.schema.alterTable('regras_fiscais_produto', (table) => {
        // Alterar tamanho da coluna codigo_produto para VARCHAR(20)
        table.string('codigo_produto', 20).alter();
        // Alterar tamanho das colunas de CST para VARCHAR(3)
        table.string('cst_icms', 3).alter();
        table.string('cst_pis', 3).alter();
        table.string('cst_cofins', 3).alter();
      });
      
      log('Tamanho das colunas da tabela regras_fiscais_produto ajustado com sucesso.');
    } else {
      log('Tabela regras_fiscais_produto não existe. Criando...');
      
      await knex.schema.createTable('regras_fiscais_produto', (table) => {
        table.increments('id').primary();
        table.string('codigo_produto', 20).notNullable().index();
        table.string('uf', 2).notNullable().index();
        table.string('cst_icms', 3);
        table.decimal('aliq_icms', 15, 4).defaultTo(0);
        table.decimal('red_bc_icms', 15, 4).defaultTo(0);
        table.decimal('aliq_pis', 15, 4).defaultTo(0);
        table.decimal('aliq_cofins', 15, 4).defaultTo(0);
        table.string('cst_pis', 3);
        table.string('cst_cofins', 3);
        table.string('codigo_ncm', 10);
        table.decimal('margem_st', 15, 4).defaultTo(0);
        table.decimal('aliq_icms_st', 15, 4).defaultTo(0);
        table.decimal('mvast', 15, 4).defaultTo(0);
        table.timestamp('created_at').defaultTo(knex.fn.now());
        table.timestamp('updated_at').defaultTo(knex.fn.now());
        
        // Adicionar índice composto para garantir unicidade por produto/UF
        table.unique(['codigo_produto', 'uf']);
      });
      
      log('Tabela regras_fiscais_produto criada com sucesso!');
    }
    
    log('=== CRIAÇÃO/AJUSTE DA TABELA FINALIZADO ===');
    return true;
  } catch (error) {
    log(`ERRO durante a criação/ajuste da tabela: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexão com o banco de dados
    await knex.destroy();
  }
}

// Executar a função
criarTabelaRegrasFiscaisProduto()
  .then(success => {
    if (success) {
      log('Tabela regras_fiscais_produto criada/ajustada com sucesso!');
      process.exit(0);
    } else {
      log('Houve problemas na criação/ajuste da tabela.');
      process.exit(1);
    }
  })
  .catch(error => {
    log(`Erro fatal: ${error.message}`);
    process.exit(1);
  }); 