/**
 * Script para criar as tabelas fiscais no banco weberp usando SQL direto
 */

const knex = require('knex');

// Configuração da conexão com o banco de dados weberp
const weberpConnection = knex({
  client: 'pg',
  connection: {
    host: 'localhost',
    user: 'postgres',
    password: 'ds_due339',
    database: 'weberp',
    port: 5434
  },
  pool: {
    min: 2,
    max: 10
  }
});

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// SQL para criar tabela regras_icms
const sqlCriarTabelaRegrasIcms = `
CREATE TABLE IF NOT EXISTS regras_icms (
  codigo INTEGER NOT NULL,
  uf VARCHAR(2) NOT NULL,
  st_icms VARCHAR(2),
  aliq_icms DECIMAL(10, 2) DEFAULT 0,
  red_icms DECIMAL(10, 2) DEFAULT 0,
  cod_convenio INTEGER DEFAULT 0,
  st_icms_contr VARCHAR(2),
  aliq_icms_contr DECIMAL(10, 2) DEFAULT 0,
  red_icms_contr DECIMAL(10, 2) DEFAULT 0,
  cod_convenio_contr INTEGER DEFAULT 0,
  icms_st VARCHAR(1) DEFAULT 'N',
  cod_aliquota INTEGER DEFAULT 0,
  aliq_interna DECIMAL(10, 2) DEFAULT 0,
  aliq_ecf VARCHAR(10),
  aliq_dif_icms_contr DECIMAL(10, 2) DEFAULT 0,
  aliq_dif_icms_cons DECIMAL(10, 2) DEFAULT 0,
  reducao_somente_icms_proprio VARCHAR(1) DEFAULT 'N',
  cod_cbnef VARCHAR(10),
  st_icms_contr_reg_sn VARCHAR(2),
  aliq_icms_contr_reg_sn DECIMAL(10, 2) DEFAULT 0,
  red_icms_contr_reg_sn DECIMAL(10, 2) DEFAULT 0,
  aliq_dif_icms_contr_reg_sn DECIMAL(10, 2) DEFAULT 0,
  cod_convenio_contr_reg_sn INTEGER DEFAULT 0,
  icms_st_reg_sn VARCHAR(1) DEFAULT 'N',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (codigo, uf)
);
`;

// SQL para criar tabela class_fiscal_dados
const sqlCriarTabelaClassFiscalDados = `
CREATE TABLE IF NOT EXISTS class_fiscal_dados (
  cod_class_fiscal INTEGER NOT NULL,
  cod_ncm VARCHAR(10),
  uf VARCHAR(2) NOT NULL,
  aliq_fcp DECIMAL(10, 2) DEFAULT 0,
  aliq_fcpst DECIMAL(10, 2) DEFAULT 0,
  aliq_pst DECIMAL(10, 2) DEFAULT 0,
  iva DECIMAL(10, 2) DEFAULT 0,
  aliq_interna DECIMAL(10, 2) DEFAULT 0,
  iva_diferenciado DECIMAL(10, 2) DEFAULT 0,
  cest VARCHAR(10),
  iva_importado DECIMAL(10, 2) DEFAULT 0,
  aliq_importado DECIMAL(10, 2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (cod_class_fiscal, uf)
);
`;

// SQL para criar tabela regras_fiscais_produto
const sqlCriarTabelaRegrasFiscaisProduto = `
CREATE TABLE IF NOT EXISTS regras_fiscais_produto (
  id SERIAL PRIMARY KEY,
  codigo_produto VARCHAR(255) NOT NULL,
  uf VARCHAR(2) NOT NULL,
  cst_icms VARCHAR(2),
  aliq_icms DECIMAL(10, 2) DEFAULT 0,
  red_bc_icms DECIMAL(10, 2) DEFAULT 0,
  aliq_ipi DECIMAL(10, 2) DEFAULT 0,
  aliq_pis DECIMAL(10, 2) DEFAULT 0,
  aliq_cofins DECIMAL(10, 2) DEFAULT 0,
  cst_pis VARCHAR(2),
  cst_cofins VARCHAR(2),
  cfop VARCHAR(4),
  margem_st DECIMAL(10, 2) DEFAULT 0,
  aliq_icms_st DECIMAL(10, 2) DEFAULT 0,
  mvast DECIMAL(10, 2) DEFAULT 0,
  preco_pauta DECIMAL(10, 2) DEFAULT 0,
  codigo_ncm VARCHAR(10),
  aliq_fcpst DECIMAL(10, 2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_regras_fiscais_produto_codigo_uf ON regras_fiscais_produto (codigo_produto, uf);
`;

// Função para criar tabelas fiscais
async function criarTabelasFiscais() {
  log('=== CRIANDO TABELAS FISCAIS NO BANCO WEBERP ===');
  
  try {
    // Verificar conexão com o banco de dados
    try {
      await weberpConnection.raw('SELECT 1');
      log('Conexão com o banco weberp estabelecida com sucesso');
    } catch (error) {
      log(`ERRO: Conexão com o banco de dados weberp falhou: ${error.message}`);
      return false;
    }
    
    // Criar tabela regras_icms
    log('Criando tabela regras_icms...');
    await weberpConnection.raw(sqlCriarTabelaRegrasIcms);
    log('Tabela regras_icms criada com sucesso!');
    
    // Criar tabela class_fiscal_dados
    log('Criando tabela class_fiscal_dados...');
    await weberpConnection.raw(sqlCriarTabelaClassFiscalDados);
    log('Tabela class_fiscal_dados criada com sucesso!');
    
    // Criar tabela regras_fiscais_produto
    log('Criando tabela regras_fiscais_produto...');
    await weberpConnection.raw(sqlCriarTabelaRegrasFiscaisProduto);
    log('Tabela regras_fiscais_produto criada com sucesso!');
    
    log('=== CRIAÇÃO DE TABELAS FISCAIS FINALIZADA ===');
    return true;
  } catch (error) {
    log(`ERRO durante a criação das tabelas fiscais: ${error.message}`);
    log(error.stack);
    return false;
  } finally {
    // Fechar conexão com o banco de dados
    await weberpConnection.destroy();
    log('Conexão com o banco de dados fechada');
  }
}

// Executar a função
criarTabelasFiscais()
  .then(success => {
    if (success) {
      log('Todas as tabelas foram criadas com sucesso!');
      process.exit(0);
    } else {
      log('Houve problemas na criação das tabelas.');
      process.exit(1);
    }
  })
  .catch(error => {
    log(`Erro fatal: ${error.message}`);
    process.exit(1);
  }); 