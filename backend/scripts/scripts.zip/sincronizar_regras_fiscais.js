/**
 * Script para sincronizar regras fiscais do ERP para o banco de dados local
 * 
 * Este script deve ser executado periodicamente para garantir que as regras fiscais
 * estejam sincronizadas entre o ERP e o sistema web.
 * 
 * Pode ser agendado como uma tarefa cron para execução automática:
 * - No Linux: crontab -e
 *   0 1 * * * node /path/to/sincronizar_regras_fiscais.js >> /path/to/logs/sync_$(date +\%Y\%m\%d).log 2>&1
 * 
 * - No Windows: Agendador de Tarefas com execução de:
 *   node C:\\path\\to\\sincronizar_regras_fiscais.js
 */

require('dotenv').config();
const { db, erp_db } = require('../config/db_connections');
const knex = require('../database');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para sincronizar regras ICMS
async function sincronizarRegrasIcms() {
  log('Iniciando sincronização de regras ICMS...');
  
  try {
    // Verificar se temos conexão com o banco de dados do ERP
    if (!erp_db) {
      log('ERRO: Conexão com o banco de dados do ERP não está disponível.');
      log('Verifique as variáveis de ambiente ERP_DB_*');
      return false;
    }
    
    // Buscar todas as regras ICMS do banco do ERP
    const regras = await erp_db.raw(`
      SELECT 
        r.codigo, 
        r.acrescimo_icms, 
        i.uf, 
        i.st_icms, 
        i.aliq_icms, 
        i.red_icms,
        i.cod_convenio, 
        i.st_icms_contr, 
        i.aliq_icms_contr, 
        i.red_icms_contr,
        i.cod_convenio_contr, 
        i.icms_st, 
        i.cod_aliquota, 
        i.aliq_interna, 
        i.aliq_ecf,
        i.aliq_dif_icms_contr, 
        i.aliq_dif_icms_cons, 
        i.reducao_somente_icms_proprio,
        i.cod_cbnef, 
        i.st_icms_contr_reg_sn, 
        i.aliq_icms_contr_reg_sn,
        i.red_icms_contr_reg_sn, 
        i.aliq_dif_icms_contr_reg_sn,
        i.cod_convenio_contr_reg_sn, 
        i.icms_st_reg_sn
      FROM 
        regras_icms_cadastro r
      JOIN 
        regras_icms_itens i ON r.codigo = i.cod_regra_icms
      WHERE
        r.dt_exc IS NULL
    `);
    
    if (!regras || !regras.rows || regras.rows.length === 0) {
      log('Nenhuma regra ICMS encontrada no banco do ERP.');
      return false;
    }
    
    log(`Encontradas ${regras.rows.length} regras ICMS no banco do ERP.`);
    
    // Não limpar a tabela, usar estratégia de UPSERT (atualizar se existir, inserir se não existir)
    // log('Tabela local regras_icms limpa com sucesso.');
    
    // Preparar dados para inserção/atualização
    const dadosParaInserir = regras.rows.map(regra => ({
      codigo: regra.codigo,
      uf: regra.uf,
      st_icms: regra.st_icms || '',
      aliq_icms: parseFloat(regra.aliq_icms || 0),
      red_icms: parseFloat(regra.red_icms || 0),
      cod_convenio: regra.cod_convenio,
      st_icms_contr: regra.st_icms_contr || '',
      aliq_icms_contr: parseFloat(regra.aliq_icms_contr || 0),
      red_icms_contr: parseFloat(regra.red_icms_contr || 0),
      cod_convenio_contr: regra.cod_convenio_contr,
      icms_st: regra.icms_st || 'N',
      cod_aliquota: regra.cod_aliquota,
      aliq_interna: parseFloat(regra.aliq_interna || 0),
      aliq_ecf: regra.aliq_ecf || '',
      aliq_dif_icms_contr: parseFloat(regra.aliq_dif_icms_contr || 0),
      aliq_dif_icms_cons: parseFloat(regra.aliq_dif_icms_cons || 0),
      reducao_somente_icms_proprio: regra.reducao_somente_icms_proprio || 'N',
      cod_cbnef: regra.cod_cbnef,
      st_icms_contr_reg_sn: regra.st_icms_contr_reg_sn || '',
      aliq_icms_contr_reg_sn: parseFloat(regra.aliq_icms_contr_reg_sn || 0),
      red_icms_contr_reg_sn: parseFloat(regra.red_icms_contr_reg_sn || 0),
      aliq_dif_icms_contr_reg_sn: parseFloat(regra.aliq_dif_icms_contr_reg_sn || 0),
      cod_convenio_contr_reg_sn: regra.cod_convenio_contr_reg_sn,
      icms_st_reg_sn: regra.icms_st_reg_sn || 'N'
    }));
    
    // Inserir em lotes menores para melhor performance
    const tamanhoLote = 10;
    let inseridos = 0;
    let atualizados = 0;
    
    for (let i = 0; i < dadosParaInserir.length; i += tamanhoLote) {
      const loteAtual = dadosParaInserir.slice(i, i + tamanhoLote);
      
      // Processar cada item individualmente para registrar estatísticas
      for (const item of loteAtual) {
        try {
          // Verificar se já existe o registro
          const existente = await knex('regras_icms')
            .where({
              codigo: item.codigo,
              uf: item.uf
            })
            .first();
            
          if (existente) {
            // Atualizar registro existente
            await knex('regras_icms')
              .where({
                codigo: item.codigo,
                uf: item.uf
              })
              .update(item);
            atualizados++;
          } else {
            // Inserir novo registro
            await knex('regras_icms').insert(item);
            inseridos++;
          }
        } catch (error) {
          log(`ERRO ao processar regra ICMS (código ${item.codigo}, UF ${item.uf}): ${error.message}`);
        }
      }
      
      log(`Processado lote ${Math.ceil((i + 1) / tamanhoLote)} de ${Math.ceil(dadosParaInserir.length / tamanhoLote)}`);
    }
    
    log(`Sincronização de regras ICMS concluída com sucesso. Total: ${inseridos} inseridas, ${atualizados} atualizadas.`);
    return true;
  } catch (error) {
    log(`ERRO durante a sincronização de regras ICMS: ${error.message}`);
    log(error.stack);
    return false;
  }
}

// Função para sincronizar dados de classificação fiscal (NCM, IVA, etc)
async function sincronizarClassificacaoFiscal() {
  log('Iniciando sincronização de classificação fiscal...');
  
  try {
    // Verificar se temos conexão com o banco de dados do ERP
    if (!erp_db) {
      log('ERRO: Conexão com o banco de dados do ERP não está disponível.');
      log('Verifique as variáveis de ambiente ERP_DB_*');
      return false;
    }
    
    // Buscar todas as classificações fiscais do banco do ERP
    const classificacoes = await erp_db.raw(`
      SELECT 
        cf.codigo AS cod_class_fiscal,
        cf.cod_ncm,
        dados.uf,
        dados.aliq_fcp,
        dados.aliq_fcpst,
        dados.aliq_pst,
        dados.iva,
        dados.aliq_interna,
        dados.iva_diferenciado,
        dados.cest,
        dados.iva_importado,
        dados.aliq_importado
      FROM 
        class_fiscal cf
      LEFT JOIN (
        SELECT 
          cod_class_fiscal, 
          uf, 
          aliq_fcp, 
          aliq_fcpst, 
          aliq_pst, 
          0::numeric AS iva, 
          0::numeric AS aliq_interna, 
          0::numeric AS iva_diferenciado, 
          ''::character varying AS cest, 
          0::numeric AS iva_importado, 
          0::numeric AS aliq_importado
        FROM 
          class_fiscal_fcp
        UNION 
        SELECT 
          cod_class_fiscal, 
          uf, 
          0::numeric AS aliq_fcp, 
          0::numeric AS aliq_fcpst, 
          0::numeric AS aliq_pst, 
          iva, 
          aliq_interna, 
          iva_diferenciado, 
          cest, 
          iva_importado, 
          aliq_importado
        FROM 
          public.class_fiscal_tributacoes
      ) dados ON cf.codigo = dados.cod_class_fiscal
      WHERE
        cf.dt_exc IS NULL
    `);
    
    if (!classificacoes || !classificacoes.rows || classificacoes.rows.length === 0) {
      log('Nenhuma classificação fiscal encontrada no banco do ERP.');
      return false;
    }
    
    log(`Encontradas ${classificacoes.rows.length} classificações fiscais no banco do ERP.`);
    
    // Não limpar a tabela, usar estratégia UPSERT
    // log('Tabela local class_fiscal_dados limpa com sucesso.');
    
    // Preparar dados para inserção em lote
    const dadosParaInserir = classificacoes.rows.map(cf => ({
      cod_class_fiscal: cf.cod_class_fiscal,
      cod_ncm: cf.cod_ncm,
      uf: cf.uf,
      aliq_fcp: parseFloat(cf.aliq_fcp || 0),
      aliq_fcpst: parseFloat(cf.aliq_fcpst || 0),
      aliq_pst: parseFloat(cf.aliq_pst || 0),
      iva: parseFloat(cf.iva || 0),
      aliq_interna: parseFloat(cf.aliq_interna || 0),
      iva_diferenciado: parseFloat(cf.iva_diferenciado || 0),
      cest: cf.cest || '',
      iva_importado: parseFloat(cf.iva_importado || 0),
      aliq_importado: parseFloat(cf.aliq_importado || 0)
    }));
    
    // Inserir em lotes menores para melhor performance
    const tamanhoLote = 10;
    let inseridos = 0;
    let atualizados = 0;
    
    for (let i = 0; i < dadosParaInserir.length; i += tamanhoLote) {
      const loteAtual = dadosParaInserir.slice(i, i + tamanhoLote);
      
      // Processar cada item individualmente para registrar estatísticas
      for (const item of loteAtual) {
        try {
          // Verificar se já existe o registro
          const existente = await knex('class_fiscal_dados')
            .where({
              cod_class_fiscal: item.cod_class_fiscal,
              uf: item.uf
            })
            .first();
            
          if (existente) {
            // Atualizar registro existente
            await knex('class_fiscal_dados')
              .where({
                cod_class_fiscal: item.cod_class_fiscal,
                uf: item.uf
              })
              .update(item);
            atualizados++;
          } else {
            // Inserir novo registro
            await knex('class_fiscal_dados').insert(item);
            inseridos++;
          }
        } catch (error) {
          log(`ERRO ao processar classificação fiscal (código ${item.cod_class_fiscal}, UF ${item.uf}): ${error.message}`);
        }
      }
      
      log(`Processado lote ${Math.ceil((i + 1) / tamanhoLote)} de ${Math.ceil(dadosParaInserir.length / tamanhoLote)}`);
    }
    
    log(`Sincronização de classificação fiscal concluída com sucesso. Total: ${inseridos} inseridas, ${atualizados} atualizadas.`);
    return true;
  } catch (error) {
    log(`ERRO durante a sincronização de classificação fiscal: ${error.message}`);
    log(error.stack);
    return false;
  }
}

// Função principal que executa todas as sincronizações
async function executarSincronizacao() {
  log('=== INICIANDO SINCRONIZAÇÃO DE DADOS FISCAIS ===');
  
  try {
    // Sincronizar regras ICMS
    const sucessoRegrasIcms = await sincronizarRegrasIcms();
    
    // Sincronizar classificação fiscal
    const sucessoClassificacaoFiscal = await sincronizarClassificacaoFiscal();
    
    log('=== SINCRONIZAÇÃO FINALIZADA ===');
    log(`Regras ICMS: ${sucessoRegrasIcms ? 'SUCESSO' : 'FALHA'}`);
    log(`Classificação Fiscal: ${sucessoClassificacaoFiscal ? 'SUCESSO' : 'FALHA'}`);
    
    // Fechar conexões
    if (erp_db) {
      await erp_db.destroy();
      log('Conexão com o banco do ERP fechada.');
    }
    
    await knex.destroy();
    log('Conexão com o banco local fechada.');
    
    // Saindo com código de sucesso ou erro
    process.exit(sucessoRegrasIcms && sucessoClassificacaoFiscal ? 0 : 1);
  } catch (error) {
    log(`ERRO FATAL durante a sincronização: ${error.message}`);
    log(error.stack);
    
    // Fechar conexões mesmo em caso de erro
    if (erp_db) {
      await erp_db.destroy();
    }
    
    await knex.destroy();
    
    process.exit(1);
  }
}

// Executar sincronização
executarSincronizacao(); 