/**
 * Script para verificar as colunas da tabela regras_fiscais_produtos no banco ERP
 */

require('dotenv').config();
const erpConnection = require('../database/erpConnection');

async function verificarColunas() {
  try {
    console.log('Verificando colunas da tabela regras_fiscais_produtos no banco ERP...');
    
    const result = await erpConnection.raw(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'regras_fiscais_produtos'
    `);
    
    console.log('Colunas da tabela regras_fiscais_produtos no ERP:');
    if (result && result.rows) {
      result.rows.forEach(row => {
        console.log(`- ${row.column_name}: ${row.data_type}`);
      });
    } else {
      console.log('Não foi possível obter informações sobre as colunas.');
    }
    
    const produtos = await erpConnection.raw(`
      SELECT cod_produto, cod_regra_icms, cod_regra_pis_cofins 
      FROM regras_fiscais_produtos 
      LIMIT 5
    `);
    
    console.log('\nExemplos de registros:');
    if (produtos && produtos.rows) {
      produtos.rows.forEach(produto => {
        console.log(`- Produto: ${produto.cod_produto}, ICMS: ${produto.cod_regra_icms}, PIS/COFINS: ${produto.cod_regra_pis_cofins}`);
      });
    } else {
      console.log('Não foi possível obter exemplos de registros.');
    }
    
  } catch (error) {
    console.error('Erro ao verificar colunas:', error);
  } finally {
    await erpConnection.destroy();
  }
}

// Executar a função
verificarColunas(); 