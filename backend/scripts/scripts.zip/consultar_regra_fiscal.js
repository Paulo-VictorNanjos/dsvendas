/**
 * Script para consultar regras fiscais de um produto específico
 * Incluindo verificação de Substituição Tributária (ST)
 */

require('dotenv').config();
const connection = require('../database/connection');
const axios = require('axios');

// Produto a ser consultado
const codigoProduto = process.argv[2] || '89/C11';
// UF para consulta de ST
const uf = process.argv[3] || 'SP';

async function consultarRegrasFiscais(codigo, uf) {
  console.log(`Consultando regras fiscais para o produto: ${codigo} na UF: ${uf}`);
  
  try {
    // Consultar tabela regras_fiscais_produtos
    const regrasProdutos = await connection('regras_fiscais_produtos')
      .where('cod_produto', codigo)
      .first();
    
    if (!regrasProdutos) {
      console.log(`Produto ${codigo} não encontrado na tabela regras_fiscais_produtos.`);
      return;
    }
    
    console.log('\n=== REGRA FISCAL DO PRODUTO ===');
    console.log(JSON.stringify(regrasProdutos, null, 2));
    
    // Consultar regras detalhadas se tiver código de regra ICMS
    if (regrasProdutos.cod_regra_icms) {
      const regrasICMS = await connection('regras_icms')
        .where('codigo', regrasProdutos.cod_regra_icms)
        .select('*');
      
      console.log('\n=== REGRAS DE ICMS APLICÁVEIS ===');
      console.log(JSON.stringify(regrasICMS, null, 2));
      
      // Verificar regras por UF
      const regrasPorUF = await connection('regras_fiscais_produto')
        .where('codigo_produto', codigo)
        .select('*')
        .limit(5);
      
      console.log('\n=== REGRAS POR UF (até 5 registros) ===');
      console.log(JSON.stringify(regrasPorUF, null, 2));
      
      // Verificar diretamente se o produto tem ST através da API
      try {
        console.log('\n=== VERIFICAÇÃO DE ST PELA API ===');
        // URL local da API
        const apiUrl = `http://localhost:3333/api/fiscal/verificar-st/${codigo}/${uf}`;
        
        // Fazendo a requisição com axios
        console.log(`Consultando: ${apiUrl}`);
        const response = await axios.get(apiUrl);
        
        console.log('\n=== RESULTADO DA VERIFICAÇÃO DE ST ===');
        console.log(JSON.stringify(response.data, null, 2));
        
        // Destacar se tem ST ou não
        if (response.data.temST) {
          console.log('\n>>> PRODUTO TEM SUBSTITUIÇÃO TRIBUTÁRIA (ST) <<<');
        } else {
          console.log('\n>>> PRODUTO NÃO TEM SUBSTITUIÇÃO TRIBUTÁRIA (ST) <<<');
        }
      } catch (apiError) {
        console.error('Erro ao consultar a API de verificação de ST:', apiError.message);
      }
    }
  } catch (error) {
    console.error('Erro ao consultar regras fiscais:', error);
  } finally {
    await connection.destroy();
  }
}

// Executar consulta
consultarRegrasFiscais(codigoProduto, uf);