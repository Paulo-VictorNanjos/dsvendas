/**
 * Script para testar a verificação de Substituição Tributária (ST) em produtos
 * 
 * Este script testa a funcionalidade de verificação de ST para diversos produtos e UFs,
 * ajudando a validar a implementação da nova API /fiscal/verificar-st/:codigo/:uf
 * 
 * Uso:
 * node testar_verificacao_st.js
 */

require('dotenv').config();
const axios = require('axios');
const colors = require('colors');

// Configuração
const API_URL = process.env.API_URL || 'http://localhost:3001/api';
const PRODUTOS_TESTE = ['10001', '10002', '10003', '20001']; // Códigos de produtos para testar
const UFS_TESTE = ['SP', 'MG', 'RJ', 'PR', 'RS']; // UFs para testar

// Função para verificar ST
async function verificarST(codigoProduto, uf) {
  try {
    console.log(`Verificando ST para produto ${codigoProduto} na UF ${uf}...`);
    const response = await axios.get(`${API_URL}/fiscal/verificar-st/${codigoProduto}/${uf}`);
    
    if (response.data && response.data.success) {
      const { temST, codRegraIcms, detalhes } = response.data;
      
      // Formatar saída com cores
      const status = temST 
        ? colors.red.bold('COM ST') 
        : colors.green('Sem ST');
      
      console.log(`Produto ${codigoProduto} - UF ${uf}: ${status} (Regra ICMS: ${codRegraIcms || 'N/A'})`);
      
      // Mostrar detalhes adicionais se disponíveis
      if (detalhes) {
        console.log('  Detalhes:');
        console.log(`    CST ICMS: ${detalhes.cstIcms}`);
        console.log(`    Alíquota ICMS: ${detalhes.aliqIcms}%`);
        
        if (detalhes.redIcms > 0) {
          console.log(`    Redução BC: ${detalhes.redIcms}%`);
        }
        
        if (temST && detalhes.margemSt > 0) {
          console.log(`    Margem ST (MVA): ${detalhes.margemSt}%`);
        }
        
        if (temST && detalhes.aliqIcmsSt > 0) {
          console.log(`    Alíquota ICMS ST: ${detalhes.aliqIcmsSt}%`);
        }
      }
      
      return { codigoProduto, uf, temST, detalhes };
    } else {
      console.log(colors.yellow(`Resposta inválida para produto ${codigoProduto} - UF ${uf}: ${JSON.stringify(response.data)}`));
      return { codigoProduto, uf, error: 'Resposta inválida' };
    }
  } catch (error) {
    console.error(colors.red(`Erro ao verificar ST para produto ${codigoProduto} - UF ${uf}:`), error.message);
    return { codigoProduto, uf, error: error.message };
  }
}

// Função principal para executar testes
async function executarTestes() {
  console.log(colors.cyan.bold('=== TESTE DE VERIFICAÇÃO DE SUBSTITUIÇÃO TRIBUTÁRIA ==='));
  console.log(`API: ${API_URL}`);
  console.log('');
  
  const resultados = [];
  let countST = 0;
  let countSemST = 0;
  let countErros = 0;
  
  // Testar cada produto em cada UF
  for (const produto of PRODUTOS_TESTE) {
    for (const uf of UFS_TESTE) {
      const resultado = await verificarST(produto, uf);
      resultados.push(resultado);
      
      // Contabilizar resultados
      if (resultado.error) {
        countErros++;
      } else if (resultado.temST) {
        countST++;
      } else {
        countSemST++;
      }
      
      // Pequena pausa para não sobrecarregar a API
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    console.log(''); // Linha em branco entre produtos
  }
  
  // Resumo dos testes
  console.log(colors.cyan.bold('=== RESUMO DOS TESTES ==='));
  console.log(`Total de verificações: ${resultados.length}`);
  console.log(`Produtos com ST: ${colors.red.bold(countST)}`);
  console.log(`Produtos sem ST: ${colors.green(countSemST)}`);
  console.log(`Erros: ${colors.yellow(countErros)}`);
}

// Executar testes
executarTestes().catch(error => {
  console.error(colors.red('Erro fatal durante execução dos testes:'), error);
  process.exit(1);
}); 