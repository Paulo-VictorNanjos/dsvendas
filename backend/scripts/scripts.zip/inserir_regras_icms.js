/**
 * Script para inserir regras ICMS padrão no banco de dados
 * 
 * Este script garante que existam regras ICMS básicas para os principais estados,
 * evitando problemas de cálculo de impostos quando as regras não estão cadastradas.
 * 
 * Para executar: node inserir_regras_icms.js
 */

const knex = require('../database');

async function inserirRegrasIcms() {
  try {
    console.log('Iniciando inserção de regras ICMS padrão...');
    
    // Verificar se já existem regras para o código 1
    const regrasExistentes = await knex('regras_icms')
      .where({ codigo: 1 })
      .select();
    
    console.log(`Encontradas ${regrasExistentes.length} regras existentes para o código 1`);
    
    // Lista de UFs para verificar/inserir
    const ufs = ['SP', 'RJ', 'MG', 'PR', 'RS', 'SC', 'ES', 'BA', 'PE', 'CE', 'GO', 'DF'];
    
    // Mapear UFs existentes para verificação rápida
    const ufsExistentes = new Set(regrasExistentes.map(regra => regra.uf));
    console.log('UFs existentes:', Array.from(ufsExistentes).join(', '));
    
    // Criar regras para UFs que não existem
    const regrasParaInserir = [];
    
    for (const uf of ufs) {
      if (!ufsExistentes.has(uf)) {
        console.log(`Preparando regra ICMS para UF: ${uf}`);
        
        // Regra ICMS padrão
        regrasParaInserir.push({
          codigo: 1,
          uf: uf,
          st_icms: '00',
          aliq_icms: uf === 'SP' ? 18 : 17,
          red_icms: 0,
          st_icms_contr: '00',
          aliq_icms_contr: uf === 'SP' ? 18 : 17,
          red_icms_contr: 0,
          icms_st: 'N'
        });
      }
    }
    
    if (regrasParaInserir.length > 0) {
      console.log(`Inserindo ${regrasParaInserir.length} novas regras ICMS...`);
      
      // Inserir as regras
      await knex('regras_icms').insert(regrasParaInserir);
      
      console.log('Regras ICMS inseridas com sucesso!');
    } else {
      console.log('Todas as regras ICMS já estão cadastradas.');
    }
    
    // Verificar novamente para confirmar
    const regrasAposInsercao = await knex('regras_icms')
      .where({ codigo: 1 })
      .select();
    
    console.log(`Total de regras ICMS após inserção: ${regrasAposInsercao.length}`);
    console.log('UFs cadastradas:', regrasAposInsercao.map(r => r.uf).join(', '));
    
    console.log('Processo concluído!');
  } catch (error) {
    console.error('Erro ao inserir regras ICMS:', error);
  } finally {
    // Fechar conexão com o banco
    knex.destroy();
  }
}

// Executar a função principal
inserirRegrasIcms(); 