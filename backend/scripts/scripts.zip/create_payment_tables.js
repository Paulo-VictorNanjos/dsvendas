const knex = require('../database/connection');

async function createPaymentTables() {
  console.log('Verificando e criando tabelas de pagamento...');
  
  try {
    // Verificar se as tabelas existem
    const formasTableExists = await knex.schema.hasTable('formas_pagto');
    const formTableExists = await knex.schema.hasTable('form_pagto');
    const condTableExists = await knex.schema.hasTable('cond_pagto');

    console.log(`Tabela 'formas_pagto' existe: ${formasTableExists}`);
    console.log(`Tabela 'form_pagto' existe: ${formTableExists}`);
    console.log(`Tabela 'cond_pagto' existe: ${condTableExists}`);

    // Criar tabela de formas de pagamento se não existir
    if (!formasTableExists && !formTableExists) {
      console.log('Criando tabela de formas de pagamento...');
      await knex.schema.createTable('formas_pagto', table => {
        table.string('codigo').primary();
        table.string('descricao').notNullable();
        table.integer('cod_empresa').defaultTo(1);
        table.timestamps(true, true);
      });
      console.log('Tabela formas_pagto criada com sucesso!');
    }

    // Criar tabela de condições de pagamento se não existir
    if (!condTableExists) {
      console.log('Criando tabela de condições de pagamento...');
      await knex.schema.createTable('cond_pagto', table => {
        table.string('codigo').primary();
        table.string('descricao').notNullable();
        table.integer('parcelas').defaultTo(1);
        table.integer('cod_empresa').defaultTo(1);
        table.timestamps(true, true);
      });
      console.log('Tabela cond_pagto criada com sucesso!');
    }

    // Determinar qual tabela usar para formas de pagamento
    const formasTable = formTableExists ? 'form_pagto' : 'formas_pagto';
    
    // Verificar se já existem dados
    const formasCount = await knex(formasTable).count('* as count').first();
    console.log(`Registros em ${formasTable}: ${formasCount.count}`);
    
    // Inserir formas de pagamento padrão se não houver registros
    if (parseInt(formasCount.count) === 0) {
      console.log('Inserindo formas de pagamento padrão...');
      const formasPadrao = [
        { codigo: '1', descricao: 'DINHEIRO', cod_empresa: 1 },
        { codigo: '4', descricao: 'CARTAO CREDITO', cod_empresa: 1 },
        { codigo: '5', descricao: 'CARTAO DEBITO', cod_empresa: 1 },
        { codigo: '7', descricao: 'BOLETO BANCARIO', cod_empresa: 1 },
        { codigo: '12', descricao: 'PIX', cod_empresa: 1 }
      ];
      
      try {
        await knex(formasTable).insert(formasPadrao);
        console.log(`${formasPadrao.length} formas de pagamento inseridas!`);
      } catch (error) {
        console.error(`Erro ao inserir formas de pagamento: ${error.message}`);
        
        // Tentar inserir uma por uma para identificar o problema
        for (const forma of formasPadrao) {
          try {
            await knex(formasTable).insert(forma);
            console.log(`Forma ${forma.codigo} - ${forma.descricao} inserida com sucesso`);
          } catch (innerError) {
            console.error(`Erro ao inserir forma ${forma.codigo}: ${innerError.message}`);
          }
        }
      }
    }
    
    if (condTableExists) {
      const condicoesCount = await knex('cond_pagto').count('* as count').first();
      console.log(`Registros em cond_pagto: ${condicoesCount.count}`);
      
      // Inserir condições de pagamento padrão se não houver registros
      if (parseInt(condicoesCount.count) === 0) {
        console.log('Inserindo condições de pagamento padrão...');
        const condicoesPadrao = [
          { codigo: '1', descricao: 'A VISTA', parcelas: 1, cod_empresa: 1 },
          { codigo: '3', descricao: '30 DIAS', parcelas: 1, cod_empresa: 1 },
          { codigo: '4', descricao: '30/60 DIAS', parcelas: 2, cod_empresa: 1 },
          { codigo: '5', descricao: '30/60/90 DIAS', parcelas: 3, cod_empresa: 1 },
          { codigo: '6', descricao: '07/14/21 DIAS', parcelas: 3, cod_empresa: 1 },
          { codigo: '7', descricao: '30/45/60/75/90 DIAS', parcelas: 5, cod_empresa: 1 }
        ];
        
        try {
          await knex('cond_pagto').insert(condicoesPadrao);
          console.log(`${condicoesPadrao.length} condições de pagamento inseridas!`);
        } catch (error) {
          console.error(`Erro ao inserir condições de pagamento: ${error.message}`);
          
          // Tentar inserir uma por uma para identificar o problema
          for (const condicao of condicoesPadrao) {
            try {
              await knex('cond_pagto').insert(condicao);
              console.log(`Condição ${condicao.codigo} - ${condicao.descricao} inserida com sucesso`);
            } catch (innerError) {
              console.error(`Erro ao inserir condição ${condicao.codigo}: ${innerError.message}`);
            }
          }
        }
      }
    }
    
    console.log('Verificação e criação de tabelas concluída!');
    return true;
  } catch (error) {
    console.error('Erro ao criar/verificar tabelas:', error);
    throw error;
  }
}

// Executar a função e fechar a conexão ao terminar
createPaymentTables()
  .then(() => {
    console.log('Script executado com sucesso!');
    process.exit(0);
  })
  .catch(error => {
    console.error('Erro ao executar script:', error);
    process.exit(1);
  }); 