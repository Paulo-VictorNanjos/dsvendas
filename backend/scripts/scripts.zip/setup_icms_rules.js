/**
 * Script para configurar regras de ICMS básicas para cada estado brasileiro
 * Execute com: node scripts/setup_icms_rules.js
 */
const knex = require('../database/connection');

// Alíquotas interestaduais padrão
const interestadualRules = [
  { origem: 'SP', destino: 'SP', aliquota: 18 },
  { origem: 'SP', destino: 'MG', aliquota: 12 },
  { origem: 'SP', destino: 'RJ', aliquota: 12 },
  { origem: 'SP', destino: 'ES', aliquota: 12 },
  // Sul e Sudeste para Sul e Sudeste: 12%
  { origem: 'RJ', destino: 'SP', aliquota: 12 },
  { origem: 'MG', destino: 'SP', aliquota: 12 },
  { origem: 'PR', destino: 'SP', aliquota: 12 },
  { origem: 'SC', destino: 'SP', aliquota: 12 },
  { origem: 'RS', destino: 'SP', aliquota: 12 },
  
  // Sul e Sudeste para demais estados: 7%
  { origem: 'SP', destino: 'AC', aliquota: 7 },
  { origem: 'SP', destino: 'AL', aliquota: 7 },
  { origem: 'SP', destino: 'AM', aliquota: 7 },
  { origem: 'SP', destino: 'AP', aliquota: 7 },
  { origem: 'SP', destino: 'BA', aliquota: 7 },
  { origem: 'SP', destino: 'CE', aliquota: 7 },
  { origem: 'SP', destino: 'DF', aliquota: 7 },
  { origem: 'SP', destino: 'GO', aliquota: 7 },
  { origem: 'SP', destino: 'MA', aliquota: 7 },
  { origem: 'SP', destino: 'MT', aliquota: 7 },
  { origem: 'SP', destino: 'MS', aliquota: 7 },
  { origem: 'SP', destino: 'PA', aliquota: 7 },
  { origem: 'SP', destino: 'PB', aliquota: 7 },
  { origem: 'SP', destino: 'PE', aliquota: 7 },
  { origem: 'SP', destino: 'PI', aliquota: 7 },
  { origem: 'SP', destino: 'RN', aliquota: 7 },
  { origem: 'SP', destino: 'RO', aliquota: 7 },
  { origem: 'SP', destino: 'RR', aliquota: 7 },
  { origem: 'SP', destino: 'SE', aliquota: 7 },
  { origem: 'SP', destino: 'TO', aliquota: 7 }
];

// Lista de estados brasileiros com suas alíquotas internas (simplificação)
const estados = [
  { uf: 'AC', nome: 'Acre', aliq_interna: 17 },
  { uf: 'AL', nome: 'Alagoas', aliq_interna: 17 },
  { uf: 'AM', nome: 'Amazonas', aliq_interna: 18 },
  { uf: 'AP', nome: 'Amapá', aliq_interna: 18 },
  { uf: 'BA', nome: 'Bahia', aliq_interna: 18 },
  { uf: 'CE', nome: 'Ceará', aliq_interna: 18 },
  { uf: 'DF', nome: 'Distrito Federal', aliq_interna: 18 },
  { uf: 'ES', nome: 'Espírito Santo', aliq_interna: 17 },
  { uf: 'GO', nome: 'Goiás', aliq_interna: 17 },
  { uf: 'MA', nome: 'Maranhão', aliq_interna: 18 },
  { uf: 'MG', nome: 'Minas Gerais', aliq_interna: 18 },
  { uf: 'MS', nome: 'Mato Grosso do Sul', aliq_interna: 17 },
  { uf: 'MT', nome: 'Mato Grosso', aliq_interna: 17 },
  { uf: 'PA', nome: 'Pará', aliq_interna: 17 },
  { uf: 'PB', nome: 'Paraíba', aliq_interna: 18 },
  { uf: 'PE', nome: 'Pernambuco', aliq_interna: 18 },
  { uf: 'PI', nome: 'Piauí', aliq_interna: 18 },
  { uf: 'PR', nome: 'Paraná', aliq_interna: 18 },
  { uf: 'RJ', nome: 'Rio de Janeiro', aliq_interna: 20 },
  { uf: 'RN', nome: 'Rio Grande do Norte', aliq_interna: 18 },
  { uf: 'RO', nome: 'Rondônia', aliq_interna: 17.5 },
  { uf: 'RR', nome: 'Roraima', aliq_interna: 17 },
  { uf: 'RS', nome: 'Rio Grande do Sul', aliq_interna: 18 },
  { uf: 'SC', nome: 'Santa Catarina', aliq_interna: 17 },
  { uf: 'SE', nome: 'Sergipe', aliq_interna: 18 },
  { uf: 'SP', nome: 'São Paulo', aliq_interna: 18 },
  { uf: 'TO', nome: 'Tocantins', aliq_interna: 18 }
];

async function setupICMSRules() {
  try {
    console.log('[INFO] Configurando regras ICMS para todos os estados...');
    
    // 1. Verificar se a tabela de estados existe e tem dados
    const hasEstados = await knex.schema.hasTable('estados');
    
    if (hasEstados) {
      // Verificar se já tem estados cadastrados
      const countEstados = await knex('estados').count('* as count').first();
      
      if (!countEstados || countEstados.count === 0) {
        console.log('[INFO] Inserindo estados...');
        
        // Inserir todos os estados
        await knex('estados').insert(
          estados.map(estado => ({
            uf: estado.uf,
            nome: estado.nome,
            ativo: true
          }))
        );
        
        console.log('[INFO] Estados inseridos com sucesso.');
      }
    }
    
    // 2. Verificar se a tabela de regras ICMS existe
    const hasRegrasIcms = await knex.schema.hasTable('regras_icms');
    
    if (!hasRegrasIcms) {
      console.log('[ERRO] Tabela regras_icms não encontrada. Execute as migrações primeiro.');
      return;
    }
    
    // 3. Verificar se já existem regras ICMS
    const countRegras = await knex('regras_icms').count('* as count').first();
    
    if (countRegras && countRegras.count > 0) {
      console.log(`[INFO] Já existem ${countRegras.count} regras ICMS cadastradas.`);
    } else {
      console.log('[INFO] Inserindo regras ICMS padrão para todos os estados...');
      
      // Inserir regra ICMS 1 para todos os estados
      const regrasIcms = [];
      
      for (const estado of estados) {
        regrasIcms.push({
          codigo: 1, // Regra padrão
          uf: estado.uf,
          st_icms: '00',
          aliq_icms: estado.aliq_interna,
          red_icms: 0,
          st_icms_contr: '00',
          aliq_icms_contr: estado.aliq_interna,
          red_icms_contr: 0,
          icms_st: 'N',
          aliq_interna: estado.aliq_interna
        });
      }
      
      // Inserir todas as regras
      await knex('regras_icms').insert(regrasIcms);
      
      console.log('[INFO] Regras ICMS inseridas com sucesso.');
    }
    
    // 4. Verificar se a tabela de alíquotas interestaduais existe
    const hasAliqInt = await knex.schema.hasTable('icms_aliq_interna');
    
    if (!hasAliqInt) {
      console.log('[INFO] Criando tabela para alíquotas interestaduais...');
      
      // Criar tabela de alíquotas interestaduais
      await knex.schema.createTable('icms_aliq_interna', table => {
        table.increments('id').primary();
        table.string('uf_origem', 2).notNullable();
        table.string('uf_destino', 2).notNullable();
        table.decimal('aliquota', 10, 2).notNullable();
        table.boolean('ativo').defaultTo(true);
        table.timestamp('dt_inc').defaultTo(knex.fn.now());
        table.timestamp('dt_alt').nullable();
        
        // Índices
        table.unique(['uf_origem', 'uf_destino']);
      });
      
      console.log('[INFO] Tabela de alíquotas interestaduais criada com sucesso.');
    }
    
    // 5. Inserir alíquotas interestaduais
    const countAliqInt = await knex('icms_aliq_interna').count('* as count').first();
    
    if (countAliqInt && countAliqInt.count > 0) {
      console.log(`[INFO] Já existem ${countAliqInt.count} alíquotas interestaduais cadastradas.`);
    } else {
      console.log('[INFO] Inserindo alíquotas interestaduais...');
      
      // Inserir todas as alíquotas
      await knex('icms_aliq_interna').insert(
        interestadualRules.map(rule => ({
          uf_origem: rule.origem,
          uf_destino: rule.destino,
          aliquota: rule.aliquota,
          ativo: true
        }))
      );
      
      console.log('[INFO] Alíquotas interestaduais inseridas com sucesso.');
    }
    
    // 6. Verificar se a tabela de FCP existe
    const hasFcp = await knex.schema.hasTable('fcp');
    
    if (!hasFcp) {
      console.log('[INFO] Criando tabela para FCP...');
      
      // Criar tabela de FCP
      await knex.schema.createTable('fcp', table => {
        table.increments('id').primary();
        table.string('uf', 2).notNullable().unique();
        table.string('possui_fcp', 1).defaultTo('N');
        table.decimal('aliquota', 10, 2).defaultTo(0);
        table.boolean('ativo').defaultTo(true);
        table.timestamp('dt_inc').defaultTo(knex.fn.now());
        table.timestamp('dt_alt').nullable();
      });
      
      console.log('[INFO] Tabela FCP criada com sucesso.');
      
      // Inserir dados padrão para FCP
      const fcpData = estados.map(estado => ({
        uf: estado.uf,
        possui_fcp: estado.uf === 'SP' || estado.uf === 'MG' ? 'S' : 'N',
        aliquota: estado.uf === 'SP' ? 2 : (estado.uf === 'MG' ? 2 : 0)
      }));
      
      await knex('fcp').insert(fcpData);
      
      console.log('[INFO] Dados FCP inseridos com sucesso.');
    }
    
    console.log('[INFO] Configuração de regras ICMS concluída com sucesso!');
    
  } catch (error) {
    console.error('[ERRO] Falha ao configurar regras ICMS:', error);
  } finally {
    // Fechar conexão com o banco
    await knex.destroy();
  }
}

// Executar a função principal
setupICMSRules(); 