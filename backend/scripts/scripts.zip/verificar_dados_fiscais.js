/**
 * Script para verificar os dados fiscais sincronizados no banco de dados local
 * 
 * Este script exibe as contagens de registros nas tabelas de dados fiscais
 * e algumas amostras de dados para verificar se a sincronização foi bem-sucedida.
 */

require('dotenv').config();
const knex = require('../database/connection');

// Função para registrar logs
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Função para verificar dados fiscais
async function verificarDadosFiscais() {
  log('=== VERIFICANDO DADOS FISCAIS ===');
  
  try {
    // Verificar tabela regras_icms
    const countRegrasIcms = await knex('regras_icms').count('* as count').first();
    log(`Total de registros na tabela regras_icms: ${countRegrasIcms.count}`);
    
    if (parseInt(countRegrasIcms.count) > 0) {
      // Mostrar algumas regras como exemplo
      const regrasIcms = await knex('regras_icms').select('*').limit(3);
      log('Exemplos de regras ICMS:');
      regrasIcms.forEach(regra => {
        log(`  Regra ${regra.codigo}, UF: ${regra.uf}, ST: ${regra.st_icms}, Alíquota: ${regra.aliq_icms}%`);
      });
    }
    
    // Verificar tabela class_fiscal_dados
    const countClassFiscal = await knex('class_fiscal_dados').count('* as count').first();
    log(`Total de registros na tabela class_fiscal_dados: ${countClassFiscal.count}`);
    
    if (parseInt(countClassFiscal.count) > 0) {
      // Mostrar algumas classificações como exemplo
      const classFiscal = await knex('class_fiscal_dados').select('*').limit(3);
      log('Exemplos de classificações fiscais:');
      classFiscal.forEach(cf => {
        log(`  Classificação ${cf.cod_class_fiscal}, NCM: ${cf.cod_ncm}, UF: ${cf.uf}, IVA: ${cf.iva}%`);
      });
    }
    
    // Verificar tabela regras_fiscais_produtos
    const countRegrasProdutos = await knex('regras_fiscais_produtos').count('* as count').first();
    log(`Total de registros na tabela regras_fiscais_produtos: ${countRegrasProdutos.count}`);
    
    if (parseInt(countRegrasProdutos.count) > 0) {
      // Mostrar algumas regras de produtos como exemplo
      const regrasProdutos = await knex('regras_fiscais_produtos').select('*').limit(3);
      log('Exemplos de regras fiscais de produtos:');
      regrasProdutos.forEach(regra => {
        log(`  Produto ${regra.cod_produto}, Regra ICMS: ${regra.cod_regra_icms}, Classificação: ${regra.class_fiscal}`);
      });
    }
    
    log('=== VERIFICAÇÃO CONCLUÍDA ===');
    
    // Fechar conexão
    await knex.destroy();
    log('Conexão com o banco local fechada.');
    
    process.exit(0);
  } catch (error) {
    log(`ERRO durante a verificação: ${error.message}`);
    log(error.stack);
    
    await knex.destroy();
    process.exit(1);
  }
}

// Executar verificação
verificarDadosFiscais(); 