/**
 * Script para testar o cálculo de ICMS
 * Execute com: node scripts/test-icms.js
 */
const knex = require('../database/connection');
const productFiscalRulesService = require('../services/productFiscalRulesService');

async function testarCalculo() {
  try {
    console.log('=== TESTE DE CÁLCULO DE ICMS ===');
    
    // Teste com produto nacional (78/C)
    const produtoNacional = '78/C';
    const quantidade = 1;
    const valorUnitario = 100;
    const clienteSP = { uf: 'SP', contribuinte: 'S' };
    const clienteMG = { uf: 'MG', contribuinte: 'S' };
    
    console.log(`\n1. Calculando ICMS para produto NACIONAL ${produtoNacional}`);
    console.log(`   - Quantidade: ${quantidade}`);
    console.log(`   - Valor unitário: R$ ${valorUnitario.toFixed(2)}`);
    console.log(`   - UF cliente: ${clienteSP.uf}`);
    
    // Buscando informações do produto
    const produto = await knex('produtos').where('codigo', produtoNacional).first();
    console.log(`\nInformações do produto ${produtoNacional}:`);
    console.log(`   - Descrição: ${produto.descricao}`);
    console.log(`   - NCM: ${produto.class_fiscal}`);
    console.log(`   - Origem: ${produto.cod_origem_prod}`);
    console.log(`   - Regra ICMS: ${produto.cod_regra_icms}`);
    console.log(`   - Alíquota ICMS: ${produto.aliq_icms}%`);
    
    // Calcular ICMS para cliente SP
    console.log('\nResultado para cliente SP:');
    const resultadoSP = await productFiscalRulesService.calculateIcms(produtoNacional, quantidade, valorUnitario, clienteSP);
    console.log(JSON.stringify(resultadoSP, null, 2));
    
    // Calcular ICMS para cliente MG
    console.log('\nResultado para cliente MG:');
    const resultadoMG = await productFiscalRulesService.calculateIcms(produtoNacional, quantidade, valorUnitario, clienteMG);
    console.log(JSON.stringify(resultadoMG, null, 2));
    
    // Teste com produto importado (135/D)
    const produtoImportado = '135/D';
    
    console.log(`\n\n2. Calculando ICMS para produto IMPORTADO ${produtoImportado}`);
    console.log(`   - Quantidade: ${quantidade}`);
    console.log(`   - Valor unitário: R$ ${valorUnitario.toFixed(2)}`);
    console.log(`   - UF cliente: ${clienteSP.uf}`);
    
    // Buscando informações do produto
    const produtoImp = await knex('produtos').where('codigo', produtoImportado).first();
    console.log(`\nInformações do produto ${produtoImportado}:`);
    console.log(`   - Descrição: ${produtoImp.descricao}`);
    console.log(`   - NCM: ${produtoImp.class_fiscal}`);
    console.log(`   - Origem: ${produtoImp.cod_origem_prod}`);
    console.log(`   - Regra ICMS: ${produtoImp.cod_regra_icms}`);
    console.log(`   - Alíquota ICMS: ${produtoImp.aliq_icms}%`);
    
    // Calcular ICMS para cliente SP
    console.log('\nResultado para cliente SP:');
    const resultadoSP_Imp = await productFiscalRulesService.calculateIcms(produtoImportado, quantidade, valorUnitario, clienteSP);
    console.log(JSON.stringify(resultadoSP_Imp, null, 2));
    
    // Calcular ICMS para cliente MG
    console.log('\nResultado para cliente MG:');
    const resultadoMG_Imp = await productFiscalRulesService.calculateIcms(produtoImportado, quantidade, valorUnitario, clienteMG);
    console.log(JSON.stringify(resultadoMG_Imp, null, 2));
    
  } catch (error) {
    console.error('Erro:', error);
  } finally {
    await knex.destroy();
  }
}

// Executar o teste
testarCalculo(); 