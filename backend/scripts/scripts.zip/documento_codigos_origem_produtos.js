/**
 * Script para documentar e verificar os códigos de origem de produtos no sistema
 * 
 * Os códigos de origem são usados para cálculos fiscais, especialmente para ICMS,
 * determinando se um produto é nacional ou importado e qual alíquota deve ser aplicada.
 */
require('dotenv').config();
const knex = require('../database/connection');
const logger = require('../utils/logger');

// Definição dos códigos de origem conforme legislação brasileira
const CODIGOS_ORIGEM = [
  { codigo: '0', descricao: 'Nacional', nacional: true, importado: false },
  { codigo: '1', descricao: 'Estrangeira - Importação direta', nacional: false, importado: true },
  { codigo: '2', descricao: 'Estrangeira - Adquirida no mercado interno', nacional: false, importado: true },
  { codigo: '3', descricao: 'Nacional - Mercadoria com conteúdo de importação superior a 40%', nacional: true, importado: true },
  { codigo: '4', descricao: 'Nacional - Produção conforme processos básicos', nacional: true, importado: false },
  { codigo: '5', descricao: 'Nacional - Mercadoria com conteúdo de importação inferior ou igual a 40%', nacional: true, importado: false },
  { codigo: '6', descricao: 'Estrangeira - Importação direta sem similar nacional', nacional: false, importado: true },
  { codigo: '7', descricao: 'Estrangeira - Adquirida no mercado interno sem similar nacional', nacional: false, importado: true },
  { codigo: '8', descricao: 'Nacional - Mercadoria com conteúdo de importação superior a 70%', nacional: true, importado: true }
];

// Verifica se a tabela origem_prod existe e, caso não exista, cria-a
async function verificarTabelaOrigemProd() {
  try {
    const tabelaExiste = await knex.schema.hasTable('origem_prod');
    
    if (!tabelaExiste) {
      logger.info('Criando tabela origem_prod...');
      
      await knex.schema.createTable('origem_prod', table => {
        table.string('codigo', 1).primary();
        table.string('descricao', 150).notNullable();
        table.boolean('nacional').defaultTo(true);
        table.boolean('importado').defaultTo(false);
        table.timestamps(true, true);
      });
      
      logger.info('Tabela origem_prod criada com sucesso!');
      return false;
    }
    
    return true;
  } catch (error) {
    logger.error('Erro ao verificar/criar tabela origem_prod:', error);
    throw error;
  }
}

// Insere os códigos de origem na tabela
async function inserirCodigosOrigem() {
  try {
    const registrosExistentes = await knex('origem_prod').count('* as total').first();
    
    if (registrosExistentes.total === 0) {
      logger.info('Inserindo códigos de origem...');
      
      // Insere todos os códigos de origem
      await knex('origem_prod').insert(CODIGOS_ORIGEM);
      
      logger.info(`${CODIGOS_ORIGEM.length} códigos de origem inseridos com sucesso!`);
    } else {
      logger.info(`Tabela origem_prod já contém ${registrosExistentes.total} registros. Verificando consistência...`);
      
      // Verifica e atualiza registros existentes
      for (const origem of CODIGOS_ORIGEM) {
        const registro = await knex('origem_prod').where('codigo', origem.codigo).first();
        
        if (registro) {
          // Atualiza apenas se necessário
          if (
            registro.descricao !== origem.descricao ||
            registro.nacional !== origem.nacional ||
            registro.importado !== origem.importado
          ) {
            await knex('origem_prod')
              .where('codigo', origem.codigo)
              .update({
                descricao: origem.descricao,
                nacional: origem.nacional,
                importado: origem.importado,
                updated_at: knex.fn.now()
              });
              
            logger.info(`Registro origem ${origem.codigo} atualizado.`);
          }
        } else {
          // Insere registro que não existe
          await knex('origem_prod').insert(origem);
          logger.info(`Registro origem ${origem.codigo} inserido.`);
        }
      }
    }
  } catch (error) {
    logger.error('Erro ao inserir/atualizar códigos de origem:', error);
    throw error;
  }
}

// Verifica produtos com código de origem inválido ou nulo
async function verificarProdutosComOrigemInvalida() {
  try {
    // Produtos com código de origem nulo
    const produtosSemOrigem = await knex('produtos')
      .whereNull('cod_origem_prod')
      .orWhere('cod_origem_prod', '')
      .select('codigo', 'nome', 'cod_origem_prod');
      
    if (produtosSemOrigem.length > 0) {
      logger.warn(`Encontrados ${produtosSemOrigem.length} produtos sem código de origem.`);
      
      // Atualizando para o código padrão (0 - Nacional)
      await knex('produtos')
        .whereNull('cod_origem_prod')
        .orWhere('cod_origem_prod', '')
        .update({
          cod_origem_prod: '0',
          updated_at: knex.fn.now()
        });
        
      logger.info(`${produtosSemOrigem.length} produtos atualizados com código de origem padrão (0 - Nacional).`);
    }
    
    // Produtos com código de origem inválido
    const codigosValidos = CODIGOS_ORIGEM.map(origem => origem.codigo);
    
    const produtosComOrigemInvalida = await knex('produtos')
      .whereNotIn('cod_origem_prod', codigosValidos)
      .whereNotNull('cod_origem_prod')
      .where('cod_origem_prod', '!=', '')
      .select('codigo', 'nome', 'cod_origem_prod');
      
    if (produtosComOrigemInvalida.length > 0) {
      logger.warn(`Encontrados ${produtosComOrigemInvalida.length} produtos com código de origem inválido.`);
      
      // Atualizando para o código padrão (0 - Nacional)
      await knex('produtos')
        .whereNotIn('cod_origem_prod', codigosValidos)
        .whereNotNull('cod_origem_prod')
        .where('cod_origem_prod', '!=', '')
        .update({
          cod_origem_prod: '0',
          updated_at: knex.fn.now()
        });
        
      logger.info(`${produtosComOrigemInvalida.length} produtos com código de origem inválido atualizados para código padrão (0 - Nacional).`);
    }
  } catch (error) {
    logger.error('Erro ao verificar produtos com origem inválida:', error);
    throw error;
  }
}

// Gera relatório de produtos por origem
async function gerarRelatorioProdutosPorOrigem() {
  try {
    logger.info('Gerando relatório de produtos por origem...');
    
    const resultado = await knex('produtos')
      .join('origem_prod', 'produtos.cod_origem_prod', 'origem_prod.codigo')
      .groupBy('produtos.cod_origem_prod', 'origem_prod.descricao')
      .select(
        'produtos.cod_origem_prod as codigo',
        'origem_prod.descricao as descricao',
        knex.raw('COUNT(*) as total_produtos')
      )
      .orderBy('produtos.cod_origem_prod');
      
    logger.info('===== RELATÓRIO DE PRODUTOS POR ORIGEM =====');
    resultado.forEach(item => {
      logger.info(`Origem ${item.codigo} - ${item.descricao}: ${item.total_produtos} produtos`);
    });
    logger.info('============================================');
    
    return resultado;
  } catch (error) {
    logger.error('Erro ao gerar relatório de produtos por origem:', error);
    throw error;
  }
}

// Função principal
async function main() {
  try {
    logger.info('Iniciando verificação de códigos de origem...');
    
    // Verifica/cria tabela
    const tabelaExistente = await verificarTabelaOrigemProd();
    
    // Insere/atualiza códigos
    await inserirCodigosOrigem();
    
    // Verifica produtos com origem inválida
    await verificarProdutosComOrigemInvalida();
    
    // Gera relatório
    await gerarRelatorioProdutosPorOrigem();
    
    logger.info('Verificação de códigos de origem concluída com sucesso!');
  } catch (error) {
    logger.error('Erro durante verificação de códigos de origem:', error);
  } finally {
    // Fecha conexão
    await knex.destroy();
  }
}

// Executa função principal
main(); 